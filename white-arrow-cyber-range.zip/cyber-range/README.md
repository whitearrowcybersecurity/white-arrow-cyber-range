# White Arrow Cyber Range (Phase 1)

Paid (₹300) internship exam on a simulated Linux terminal: register → pay → 30-question scenario
("Operation Night Watch") → final flag → internship letter PDF with public verification.

- `backend/` FastAPI + SQLAlchemy + Alembic (Postgres in prod, SQLite in tests)
- `frontend/` Next.js 14 + Tailwind + xterm.js
- `docs/` ARCHITECTURE, SETUP, DEPLOY, PAYMENTS, SECURITY, API (+ `openapi.json`)

Quick start: `cp .env.example .env && docker compose up --build`, open http://localhost:3000.
Demo logins (seeded in dev only): `admin@example.test`, `instructor@example.test`, `student@example.test`
with password `DemoPassw0rd!`. See `docs/SETUP.md`.

## Verified status
| Check | Result |
|---|---|
| Backend tests (`pytest`) | 57 passed on SQLite and on Postgres 16; concurrency race test passes on Postgres |
| Workflows A–G | covered by `tests/test_workflows.py` |
| Scenario solvability | `tests/test_scenario_solvable.py` solves all 30 questions through the real engine and API |
| Browser e2e (Playwright, mock payments) | register → checkout → verified → start → terminal → wrong/right answer → hint → AI tutor → locked final → reload persistence → admin payments + audit chain |

## Not verified / out of scope (be aware)
- **Razorpay live mode is untested**: no keys or network were available. Webhook/Payment Link shapes follow Razorpay's docs. Run a test-mode payment with your own keys before launch.
- Anthropic AI provider is untested live (the default `local` tutor is tested).
- Terminal is a simulated shell only; no real container labs (Phase 2).
- Roles are a code-defined column, not separate roles/permissions tables. No Redis (rate limits are in-process: single API instance).
- `modules` table exists but is unused; assigning scenarios to individual students is not implemented.
