"""Hash-chained audit log: each row commits to the previous row's hash."""
import hashlib
import json

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import AuditLog, utcnow


def _digest(prev: str, row: AuditLog) -> str:
    body = json.dumps({
        "actor_id": row.actor_id, "actor_role": row.actor_role, "action": row.action,
        "entity_type": row.entity_type, "entity_id": row.entity_id, "detail": row.detail,
        "ip": row.ip, "created_at": row.created_at.isoformat(),
    }, sort_keys=True, default=str)
    return hashlib.sha256((prev + body).encode()).hexdigest()


def audit(db: Session, action: str, *, actor=None, entity_type: str | None = None,
          entity_id: str | None = None, detail: dict | None = None, ip: str | None = None) -> AuditLog:
    last = db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(1)).scalar_one_or_none()
    row = AuditLog(actor_id=getattr(actor, "id", None), actor_role=getattr(actor, "role", None),
                   action=action, entity_type=entity_type, entity_id=entity_id,
                   detail=detail or {}, ip=ip, created_at=utcnow())
    row.prev_hash = last.hash if last else ""
    row.hash = _digest(row.prev_hash, row)
    db.add(row)
    db.flush()
    return row


def verify_chain(db: Session) -> dict:
    prev = ""
    n = 0
    for row in db.execute(select(AuditLog).order_by(AuditLog.id)).scalars():
        n += 1
        if row.prev_hash != prev or row.hash != _digest(prev, row):
            return {"ok": False, "broken_at": row.id, "checked": n}
        prev = row.hash
    return {"ok": True, "checked": n}
