"""Runtime configuration. Everything secret comes from the environment only."""
import os
from dataclasses import dataclass, field

_DEV_SECRET = "dev-secret-change-me"
_DEV_FLAG_KEY = "dev-flag-key-change-me"


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


@dataclass
class Settings:
    env: str = "development"
    database_url: str = "sqlite:///./cyberrange.db"
    secret_key: str = _DEV_SECRET          # signs session JWTs
    flag_key: str = _DEV_FLAG_KEY          # HMAC key for per-session flags
    cookie_secure: bool = False
    cors_origins: list = field(default_factory=lambda: ["http://localhost:3000"])
    frontend_url: str = "http://localhost:3000"
    backend_url: str = "http://localhost:8000"

    # payments
    payment_provider: str = "mock"         # mock | razorpay
    razorpay_key_id: str = ""
    razorpay_key_secret: str = ""
    razorpay_webhook_secret: str = ""
    default_exam_fee_paise: int = 30000    # Rs 300

    # AI
    ai_provider: str = "local"             # local | anthropic
    anthropic_api_key: str = ""
    ai_model: str = ""

    # initial super admin (created by seed if set)
    bootstrap_admin_email: str = ""
    bootstrap_admin_password: str = ""

    def validate(self) -> None:
        problems = []
        if self.env == "production":
            if self.secret_key == _DEV_SECRET or len(self.secret_key) < 32:
                problems.append("SECRET_KEY must be set to a random value of 32+ chars")
            if self.flag_key == _DEV_FLAG_KEY or len(self.flag_key) < 32:
                problems.append("FLAG_KEY must be set to a random value of 32+ chars")
            if not self.cookie_secure:
                problems.append("COOKIE_SECURE must be true in production")
            if self.payment_provider == "mock":
                problems.append("PAYMENT_PROVIDER=mock is not allowed in production")
        if self.payment_provider == "razorpay":
            for k in ("razorpay_key_id", "razorpay_key_secret", "razorpay_webhook_secret"):
                if not getattr(self, k):
                    problems.append(f"{k.upper()} is required when PAYMENT_PROVIDER=razorpay")
        if self.ai_provider == "anthropic" and not (self.anthropic_api_key and self.ai_model):
            problems.append("ANTHROPIC_API_KEY and AI_MODEL are required when AI_PROVIDER=anthropic")
        if problems:
            raise RuntimeError("Invalid configuration: " + "; ".join(problems))


def load_settings() -> Settings:
    s = Settings(
        env=_env("APP_ENV", "development"),
        database_url=_env("DATABASE_URL", "sqlite:///./cyberrange.db"),
        secret_key=_env("SECRET_KEY", _DEV_SECRET),
        flag_key=_env("FLAG_KEY", _DEV_FLAG_KEY),
        cookie_secure=_env("COOKIE_SECURE", "false").lower() == "true",
        cors_origins=[o.strip() for o in _env("CORS_ORIGINS", "http://localhost:3000").split(",") if o.strip()],
        frontend_url=_env("FRONTEND_URL", "http://localhost:3000"),
        backend_url=_env("BACKEND_URL", "http://localhost:8000"),
        payment_provider=_env("PAYMENT_PROVIDER", "mock"),
        razorpay_key_id=_env("RAZORPAY_KEY_ID"),
        razorpay_key_secret=_env("RAZORPAY_KEY_SECRET"),
        razorpay_webhook_secret=_env("RAZORPAY_WEBHOOK_SECRET"),
        default_exam_fee_paise=int(_env("DEFAULT_EXAM_FEE_PAISE", "30000")),
        ai_provider=_env("AI_PROVIDER", "local"),
        anthropic_api_key=_env("ANTHROPIC_API_KEY"),
        ai_model=_env("AI_MODEL"),
        bootstrap_admin_email=_env("BOOTSTRAP_ADMIN_EMAIL"),
        bootstrap_admin_password=_env("BOOTSTRAP_ADMIN_PASSWORD"),
    )
    return s


settings = load_settings()
