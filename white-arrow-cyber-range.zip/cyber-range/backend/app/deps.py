from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .db import get_db
from .models import User
from .security import SESSION_COOKIE, decode_session_token


def client_ip(request: Request) -> str:
    # Behind a reverse proxy, configure uvicorn --proxy-headers so request.client is the real address.
    return request.client.host if request.client else "unknown"


def user_from_token(db: Session, token: str | None) -> User | None:
    if not token:
        return None
    uid = decode_session_token(token)
    if not uid:
        return None
    user = db.get(User, uid)
    if not user or user.status != "active":
        return None
    return user


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    user = user_from_token(db, request.cookies.get(SESSION_COOKIE))
    if not user:
        raise HTTPException(401, "Authentication required")
    return user


def optional_user(request: Request, db: Session = Depends(get_db)) -> User | None:
    return user_from_token(db, request.cookies.get(SESSION_COOKIE))


def require_roles(*roles: str):
    def dep(user: User = Depends(current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(403, "Forbidden")
        return user
    return dep


student_only = require_roles("student")
staff_only = require_roles("instructor", "super_admin")
admin_only = require_roles("super_admin")
