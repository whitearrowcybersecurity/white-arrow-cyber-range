import asyncio
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from . import db as dbmod
from .config import settings
from .models import Base
from .routers import admin, auth, catalog, exam, letters, payments
from .security import CSRF_COOKIE, SESSION_COOKIE, consteq
from .services.exam import AccessError

CSRF_EXEMPT = ("/api/auth/login", "/api/auth/register", "/api/payments/webhook", "/api/dev/mock-pay/")


def _cleanup_once():
    db = dbmod.session()
    try:
        admin.expire_stale_sessions(db)
        db.commit()
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.validate()
    dbmod.configure()
    if settings.payment_provider == "mock":
        settings.razorpay_key_secret = settings.razorpay_key_secret or "mock-key-secret"
        settings.razorpay_webhook_secret = settings.razorpay_webhook_secret or "mock-webhook-secret"
    if settings.env != "production" and os.environ.get("AUTO_CREATE_TABLES", "true").lower() == "true":
        Base.metadata.create_all(dbmod.engine)       # production uses `alembic upgrade head`

    async def janitor():
        while True:
            await asyncio.sleep(300)
            try:
                await run_in_threadpool(_cleanup_once)
            except Exception:
                pass
    task = asyncio.create_task(janitor())
    yield
    task.cancel()


def create_app() -> FastAPI:
    app = FastAPI(title="White Arrow Cyber Range API", version="1.0.0", lifespan=lifespan,
                  docs_url=None if settings.env == "production" else "/docs",
                  redoc_url=None, openapi_url=None if settings.env == "production" else "/openapi.json")
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True,
                       allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"], allow_headers=["Content-Type", "X-CSRF-Token"])

    @app.middleware("http")
    async def guard(request: Request, call_next):
        path = request.url.path
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and path.startswith("/api/") \
                and not any(path.startswith(p) for p in CSRF_EXEMPT) and request.cookies.get(SESSION_COOKIE):
            hdr, ck = request.headers.get("x-csrf-token", ""), request.cookies.get(CSRF_COOKIE, "")
            origin = request.headers.get("origin")
            if not hdr or not ck or not consteq(hdr, ck) or (origin and origin not in set(settings.cors_origins) | {settings.backend_url}):
                return JSONResponse({"detail": "CSRF check failed"}, status_code=403)
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        if path.startswith("/api/"):
            resp.headers.setdefault("Cache-Control", "no-store")
            if not path.startswith("/api/docs"):
                resp.headers.setdefault("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
        return resp

    @app.exception_handler(AccessError)
    async def access_error(request: Request, exc: AccessError):
        return JSONResponse({"detail": exc.message, "code": exc.code, **exc.extra}, status_code=exc.status)

    for r in (auth.router, catalog.router, payments.router, exam.router, letters.router, admin.router):
        app.include_router(r)

    @app.get("/healthz")
    def healthz():
        return {"ok": True}

    return app


app = create_app()
