"""Database schema. Money is always integer paise. All timestamps are naive UTC."""
import uuid
from datetime import datetime, timezone

from sqlalchemy import (JSON, BigInteger, Boolean, DateTime, ForeignKey, Index, Integer,
                        String, Text, UniqueConstraint, event)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def uid() -> str:
    return str(uuid.uuid4())


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------- identity
class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="student")  # student|instructor|super_admin
    status: Mapped[str] = mapped_column(String(20), default="active")  # active|suspended
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class OperatorAssignment(Base):
    """Scopes an instructor to specific students and/or scenarios."""
    __tablename__ = "operator_assignments"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    instructor_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    student_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    scenario_id: Mapped[str | None] = mapped_column(ForeignKey("scenarios.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- content
class Track(Base):
    __tablename__ = "internship_tracks"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    title: Mapped[str] = mapped_column(String(200))
    summary: Mapped[str] = mapped_column(Text, default="")
    objectives: Mapped[list] = mapped_column(JSON, default=list)
    difficulty: Mapped[str] = mapped_column(String(30), default="beginner")
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    is_published: Mapped[bool] = mapped_column(Boolean, default=False)


class Module(Base):
    __tablename__ = "modules"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    track_id: Mapped[str] = mapped_column(ForeignKey("internship_tracks.id"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    summary: Mapped[str] = mapped_column(Text, default="")
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class LabTemplate(Base):
    """Describes how a lab is built. `key` selects a builder in app.terminal.labs."""
    __tablename__ = "lab_templates"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    key: Mapped[str] = mapped_column(String(80), unique=True)
    title: Mapped[str] = mapped_column(String(200))
    mode: Mapped[str] = mapped_column(String(20), default="simulated")  # simulated|container (Phase 2)
    spec: Mapped[dict] = mapped_column(JSON, default=dict)


class Scenario(Base):
    __tablename__ = "scenarios"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    track_id: Mapped[str] = mapped_column(ForeignKey("internship_tracks.id"), index=True)
    module_id: Mapped[str | None] = mapped_column(ForeignKey("modules.id"), nullable=True)
    lab_template_id: Mapped[str | None] = mapped_column(ForeignKey("lab_templates.id"), nullable=True)
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    title: Mapped[str] = mapped_column(String(200))
    public_description: Mapped[str] = mapped_column(Text, default="")
    objectives: Mapped[list] = mapped_column(JSON, default=list)
    difficulty: Mapped[str] = mapped_column(String(30), default="beginner")
    duration_minutes: Mapped[int] = mapped_column(Integer, default=180)
    eligibility_text: Mapped[str] = mapped_column(Text, default="")
    story: Mapped[str] = mapped_column(Text, default="")  # protected: only served after entitlement
    price_paise: Mapped[int | None] = mapped_column(Integer, nullable=True)  # null => platform default
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|published|unpublished
    owner_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    completion_policy: Mapped[dict] = mapped_column(JSON, default=dict)
    enabled_commands: Mapped[list] = mapped_column(JSON, default=list)
    published_version_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    track = relationship("Track")
    lab_template = relationship("LabTemplate")


class Question(Base):
    __tablename__ = "questions"
    __table_args__ = (UniqueConstraint("scenario_id", "key"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    scenario_id: Mapped[str] = mapped_column(ForeignKey("scenarios.id"), index=True)
    key: Mapped[str] = mapped_column(String(40))
    position: Mapped[int] = mapped_column(Integer)
    stage: Mapped[str] = mapped_column(String(120), default="")
    title: Mapped[str] = mapped_column(String(200))
    narrative: Mapped[str] = mapped_column(Text, default="")
    task: Mapped[str] = mapped_column(Text, default="")
    concept_notes: Mapped[str] = mapped_column(Text, default="")
    explanation: Mapped[str] = mapped_column(Text, default="")
    score: Mapped[int] = mapped_column(Integer, default=10)
    is_final: Mapped[bool] = mapped_column(Boolean, default=False)


class QuestionPrerequisite(Base):
    __tablename__ = "question_prerequisites"
    __table_args__ = (UniqueConstraint("question_id", "requires_question_id"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    question_id: Mapped[str] = mapped_column(ForeignKey("questions.id"), index=True)
    requires_question_id: Mapped[str] = mapped_column(ForeignKey("questions.id"))


class ValidationRule(Base):
    """Server-side only. Never serialised to student-facing responses."""
    __tablename__ = "validation_rules"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    question_id: Mapped[str] = mapped_column(ForeignKey("questions.id"), unique=True)
    spec: Mapped[dict] = mapped_column(JSON, default=dict)


class Hint(Base):
    __tablename__ = "hints"
    __table_args__ = (UniqueConstraint("question_id", "level"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    question_id: Mapped[str] = mapped_column(ForeignKey("questions.id"), index=True)
    level: Mapped[int] = mapped_column(Integer)
    text: Mapped[str] = mapped_column(Text)


class Flag(Base):
    """Flag definition only. The actual flag value is derived per lab session
    (HMAC with FLAG_KEY) and is never stored in this table."""
    __tablename__ = "flags"
    __table_args__ = (UniqueConstraint("scenario_id", "key"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    scenario_id: Mapped[str] = mapped_column(ForeignKey("scenarios.id"), index=True)
    key: Mapped[str] = mapped_column(String(40))
    label: Mapped[str] = mapped_column(String(200), default="")
    is_final: Mapped[bool] = mapped_column(Boolean, default=True)


class ScenarioVersion(Base):
    __tablename__ = "scenario_versions"
    __table_args__ = (UniqueConstraint("scenario_id", "version"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    scenario_id: Mapped[str] = mapped_column(ForeignKey("scenarios.id"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    content_hash: Mapped[str] = mapped_column(String(64))
    created_by: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- payments
class ExamOrder(Base):
    __tablename__ = "exam_orders"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)  # also the reference_id sent to the provider
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    scenario_id: Mapped[str] = mapped_column(ForeignKey("scenarios.id"), index=True)
    amount_paise: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    # created|pending|paid|failed|cancelled|expired|refunded|partially_refunded|review
    status: Mapped[str] = mapped_column(String(24), default="created", index=True)
    provider: Mapped[str] = mapped_column(String(20))
    provider_link_id: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    checkout_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    failure_reason: Mapped[str | None] = mapped_column(String(300), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    paid_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    receipt_number: Mapped[str | None] = mapped_column(String(40), unique=True, nullable=True)


class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    order_id: Mapped[str] = mapped_column(ForeignKey("exam_orders.id"), index=True)
    provider_payment_id: Mapped[str] = mapped_column(String(64), unique=True)  # replay/idempotency guard
    amount_paise: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    status: Mapped[str] = mapped_column(String(24))  # captured|failed|refunded|partially_refunded
    refunded_paise: Mapped[int] = mapped_column(Integer, default=0)
    method: Mapped[str | None] = mapped_column(String(30), nullable=True)
    source: Mapped[str] = mapped_column(String(20), default="webhook")  # webhook|callback|reconcile
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class PaymentEvent(Base):
    """One row per provider webhook delivery; unique event id = duplicate protection."""
    __tablename__ = "payment_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    provider_event_id: Mapped[str] = mapped_column(String(100), unique=True)
    event_type: Mapped[str] = mapped_column(String(60))
    outcome: Mapped[str] = mapped_column(String(40), default="received")
    payload_digest: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Entitlement(Base):
    __tablename__ = "exam_entitlements"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    scenario_id: Mapped[str] = mapped_column(ForeignKey("scenarios.id"), index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey("exam_orders.id"), unique=True)  # one entitlement per order
    status: Mapped[str] = mapped_column(String(20), default="active")  # active|revoked|exhausted
    attempts_allowed: Mapped[int] = mapped_column(Integer, default=1)
    attempts_used: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    revoked_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- exam runtime
class ExamAttempt(Base):
    __tablename__ = "exam_attempts"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    scenario_id: Mapped[str] = mapped_column(ForeignKey("scenarios.id"), index=True)
    version_id: Mapped[str] = mapped_column(ForeignKey("scenario_versions.id"))
    entitlement_id: Mapped[str] = mapped_column(ForeignKey("exam_entitlements.id"), index=True)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active|completed|expired|revoked
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class LabSession(Base):
    __tablename__ = "lab_sessions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    attempt_id: Mapped[str] = mapped_column(ForeignKey("exam_attempts.id"), unique=True)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active|expired|reset
    state: Mapped[dict] = mapped_column(JSON)
    resets: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_active_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)


class CommandLog(Base):
    __tablename__ = "terminal_events"
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True, autoincrement=True)
    lab_session_id: Mapped[str] = mapped_column(ForeignKey("lab_sessions.id"), index=True)
    command: Mapped[str] = mapped_column(String(600))
    output: Mapped[str] = mapped_column(Text, default="")
    exit_code: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Submission(Base):
    __tablename__ = "submissions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    attempt_id: Mapped[str] = mapped_column(ForeignKey("exam_attempts.id"), index=True)
    question_key: Mapped[str] = mapped_column(String(40))
    kind: Mapped[str] = mapped_column(String(10), default="answer")  # answer|check|flag
    value: Mapped[str] = mapped_column(String(500), default="")      # flags are stored as a digest only
    correct: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class StudentProgress(Base):
    __tablename__ = "student_progress"
    __table_args__ = (UniqueConstraint("attempt_id", "question_key"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    attempt_id: Mapped[str] = mapped_column(ForeignKey("exam_attempts.id"), index=True)
    question_key: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(20), default="in_progress")  # in_progress|completed
    submissions: Mapped[int] = mapped_column(Integer, default=0)
    hints_used: Mapped[int] = mapped_column(Integer, default=0)
    score_awarded: Mapped[int] = mapped_column(Integer, default=0)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class AIUsageRecord(Base):
    __tablename__ = "ai_usage_records"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    attempt_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    question_key: Mapped[str | None] = mapped_column(String(40), nullable=True)
    provider: Mapped[str] = mapped_column(String(20))
    prompt_chars: Mapped[int] = mapped_column(Integer, default=0)
    response_chars: Mapped[int] = mapped_column(Integer, default=0)
    redactions: Mapped[int] = mapped_column(Integer, default=0)  # answers/flags scrubbed from output
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)


# ---------------------------------------------------------------- completion & letters
class CompletionRecord(Base):
    """Immutable: updates/deletes are blocked by ORM event listeners below."""
    __tablename__ = "completion_records"
    __table_args__ = (UniqueConstraint("user_id", "scenario_id"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    scenario_id: Mapped[str] = mapped_column(ForeignKey("scenarios.id"), index=True)
    attempt_id: Mapped[str] = mapped_column(ForeignKey("exam_attempts.id"), unique=True)
    entitlement_id: Mapped[str] = mapped_column(ForeignKey("exam_entitlements.id"))
    lab_session_id: Mapped[str] = mapped_column(ForeignKey("lab_sessions.id"))
    version_id: Mapped[str] = mapped_column(String(36))
    score: Mapped[int] = mapped_column(Integer)
    max_score: Mapped[int] = mapped_column(Integer)
    questions_completed: Mapped[int] = mapped_column(Integer)
    questions_total: Mapped[int] = mapped_column(Integer)
    completed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    record_hash: Mapped[str] = mapped_column(String(64))


class InternshipLetter(Base):
    __tablename__ = "internship_letters"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    completion_id: Mapped[str] = mapped_column(ForeignKey("completion_records.id"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    certificate_number: Mapped[str] = mapped_column(String(60), unique=True)
    verification_id: Mapped[str] = mapped_column(String(40), unique=True)
    status: Mapped[str] = mapped_column(String(20), default="issued")  # issued|revoked|superseded
    issued_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    revoke_reason: Mapped[str | None] = mapped_column(String(300), nullable=True)
    supersedes_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    data: Mapped[dict] = mapped_column(JSON)  # frozen content used to render the PDF


class CertificateVerificationRecord(Base):
    __tablename__ = "certificate_verification_records"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    letter_id: Mapped[str] = mapped_column(ForeignKey("internship_letters.id"), unique=True)
    verification_id: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    public_payload: Mapped[dict] = mapped_column(JSON)
    view_count: Mapped[int] = mapped_column(Integer, default=0)
    last_viewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


# ---------------------------------------------------------------- platform
class AuditLog(Base):
    """Append-only, hash-chained."""
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True, autoincrement=True)
    actor_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    actor_role: Mapped[str | None] = mapped_column(String(20), nullable=True)
    action: Mapped[str] = mapped_column(String(60), index=True)
    entity_type: Mapped[str | None] = mapped_column(String(40), nullable=True)
    entity_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    prev_hash: Mapped[str] = mapped_column(String(64), default="")
    hash: Mapped[str] = mapped_column(String(64), default="")


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)
    updated_by: Mapped[str | None] = mapped_column(String(36), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


Index("ix_orders_user_scenario", ExamOrder.user_id, ExamOrder.scenario_id)


# ---- immutability guards (defence in depth; student APIs expose no mutation anyway)
class ImmutableRecordError(Exception):
    pass


@event.listens_for(CompletionRecord, "before_update")
def _block_completion_update(mapper, connection, target):
    raise ImmutableRecordError("completion_records are immutable")


@event.listens_for(CompletionRecord, "before_delete")
def _block_completion_delete(mapper, connection, target):
    raise ImmutableRecordError("completion_records are immutable")


@event.listens_for(AuditLog, "before_update")
def _block_audit_update(mapper, connection, target):
    raise ImmutableRecordError("audit_logs are append-only")


@event.listens_for(AuditLog, "before_delete")
def _block_audit_delete(mapper, connection, target):
    raise ImmutableRecordError("audit_logs are append-only")
