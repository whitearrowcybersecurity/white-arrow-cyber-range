"""Sliding-window rate limiter (in-process).

Good enough for a single API worker. For multiple workers, back this with Redis
(same interface) — see docs/SECURITY.md.
"""
import threading
import time
from collections import defaultdict, deque

from fastapi import HTTPException


class RateLimiter:
    def __init__(self):
        self._hits: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str, limit: int, window_s: int) -> bool:
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > window_s:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            return True

    def enforce(self, key: str, limit: int, window_s: int, detail: str = "Too many requests"):
        if not self.check(key, limit, window_s):
            raise HTTPException(status_code=429, detail=detail)

    def reset(self):
        with self._lock:
            self._hits.clear()


limiter = RateLimiter()
