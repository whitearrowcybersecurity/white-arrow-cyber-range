"""Instructor / super-admin API. Every route is role-gated; instructors are additionally scoped."""
import csv
import io
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..audit import audit, verify_chain
from ..db import get_db
from ..deps import admin_only, client_ip, staff_only
from ..models import (AIUsageRecord, AuditLog, CompletionRecord, Entitlement, ExamAttempt, ExamOrder, Hint,
                      InternshipLetter, LabSession, OperatorAssignment, Payment, Question, QuestionPrerequisite,
                      Scenario, ScenarioVersion, StudentProgress, User, ValidationRule, utcnow)
from ..security import hash_password
from ..services import exam as exam_svc
from ..services import letters as L
from ..services import payments as pay
from ..services import scenarios as scn
from ..services.platform_settings import EDITABLE, all_settings, set_setting

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ---------------------------------------------------------------- scoping
def scoped_scenario_ids(db: Session, actor: User) -> set[str] | None:
    """None = unrestricted (super admin)."""
    if actor.role == "super_admin":
        return None
    owned = {r for (r,) in db.execute(select(Scenario.id).where(Scenario.owner_id == actor.id))}
    assigned = {r.scenario_id for r in db.execute(select(OperatorAssignment).where(
        OperatorAssignment.instructor_id == actor.id, OperatorAssignment.scenario_id.is_not(None))).scalars()}
    return owned | assigned


def scoped_student_ids(db: Session, actor: User) -> set[str] | None:
    if actor.role == "super_admin":
        return None
    direct = {r.student_id for r in db.execute(select(OperatorAssignment).where(
        OperatorAssignment.instructor_id == actor.id, OperatorAssignment.student_id.is_not(None))).scalars()}
    scen = scoped_scenario_ids(db, actor)
    via = set()
    if scen:
        via = {u for (u,) in db.execute(select(ExamAttempt.user_id).where(ExamAttempt.scenario_id.in_(scen)))}
        via |= {u for (u,) in db.execute(select(Entitlement.user_id).where(Entitlement.scenario_id.in_(scen)))}
    return direct | via


def can_view_student(db: Session, actor: User, student_id: str) -> bool:
    ids = scoped_student_ids(db, actor)
    return ids is None or student_id in ids


def _page(q, page: int, size: int):
    return q.offset((page - 1) * size).limit(size)


def _csv_cell(v):
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s     # neutralise spreadsheet formula injection


def _csv(rows: list[list], header: list[str], name: str) -> Response:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(header)
    for r in rows:
        w.writerow([_csv_cell(c) for c in r])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ---------------------------------------------------------------- overview
@router.get("/overview")
def overview(actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    sids = scoped_student_ids(db, actor)
    scen = scoped_scenario_ids(db, actor)
    def count(model, *conds):
        return db.scalar(select(func.count()).select_from(model).where(*conds)) or 0
    comp_conds = [] if scen is None else [CompletionRecord.scenario_id.in_(scen or {""})]
    att_conds = [ExamAttempt.status == "active"] + ([] if scen is None else [ExamAttempt.scenario_id.in_(scen or {""})])
    out = {"students": count(User, User.role == "student") if sids is None else len(sids),
           "active_attempts": count(ExamAttempt, *att_conds), "completions": count(CompletionRecord, *comp_conds)}
    if actor.role == "super_admin":
        out["paid_orders"] = count(ExamOrder, ExamOrder.status == "paid")
        out["revenue_paise"] = db.scalar(select(func.coalesce(func.sum(Payment.amount_paise - Payment.refunded_paise), 0)).where(Payment.status.in_(["captured", "partially_refunded"]))) or 0
        out["review_orders"] = count(ExamOrder, ExamOrder.status == "review")
        out["ai_requests_24h"] = count(AIUsageRecord, AIUsageRecord.created_at > utcnow() - timedelta(hours=24))
    return out


# ---------------------------------------------------------------- users
class UserIn(BaseModel):
    email: str = Field(max_length=254)
    display_name: str = Field(min_length=2, max_length=120)
    password: str = Field(min_length=10, max_length=200)
    role: str = Field(pattern="^(student|instructor|super_admin)$")


class UserPatch(BaseModel):
    status: str | None = Field(default=None, pattern="^(active|suspended)$")
    role: str | None = Field(default=None, pattern="^(student|instructor|super_admin)$")
    display_name: str | None = Field(default=None, min_length=2, max_length=120)


def _user_row(u: User) -> dict:
    return {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role, "status": u.status,
            "created_at": u.created_at.isoformat(), "last_login_at": u.last_login_at.isoformat() if u.last_login_at else None}


@router.get("/users")
def list_users(q: str = "", role: str | None = None, page: int = Query(1, ge=1), size: int = Query(25, ge=1, le=100),
               actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    stmt = select(User)
    ids = scoped_student_ids(db, actor)
    if ids is not None:
        stmt = stmt.where(User.id.in_(ids or {""}))
    if role:
        stmt = stmt.where(User.role == role)
    if q:
        like = f"%{q.strip()[:60]}%"
        stmt = stmt.where(or_(User.email.ilike(like), User.display_name.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.execute(_page(stmt.order_by(User.created_at.desc()), page, size)).scalars().all()
    return {"total": total, "page": page, "items": [_user_row(u) for u in rows]}


@router.post("/users", status_code=201)
def create_user(body: UserIn, request: Request, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    email = body.email.strip().lower()
    if db.execute(select(User).where(User.email == email)).scalar_one_or_none():
        raise HTTPException(409, "Email already registered")
    u = User(email=email, display_name=" ".join(body.display_name.split()), password_hash=hash_password(body.password), role=body.role)
    db.add(u)
    db.flush()
    audit(db, "admin.user_create", actor=actor, entity_type="user", entity_id=u.id, detail={"role": u.role}, ip=client_ip(request))
    db.commit()
    return _user_row(u)


@router.patch("/users/{user_id}")
def patch_user(user_id: str, body: UserPatch, request: Request, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "Not found")
    if u.id == actor.id and (body.status == "suspended" or (body.role and body.role != "super_admin")):
        raise HTTPException(400, "You cannot demote or suspend yourself")
    changes = body.model_dump(exclude_none=True)
    for k, v in changes.items():
        setattr(u, k, v)
    audit(db, "admin.user_update", actor=actor, entity_type="user", entity_id=u.id, detail=changes, ip=client_ip(request))
    db.commit()
    return _user_row(u)


class AssignIn(BaseModel):
    instructor_id: str
    student_id: str | None = None
    scenario_id: str | None = None


@router.get("/assignments")
def list_assignments(actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    return [{"id": a.id, "instructor_id": a.instructor_id, "student_id": a.student_id, "scenario_id": a.scenario_id}
            for a in db.execute(select(OperatorAssignment)).scalars()]


@router.post("/assignments", status_code=201)
def create_assignment(body: AssignIn, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    if bool(body.student_id) == bool(body.scenario_id):
        raise HTTPException(422, "Provide exactly one of student_id or scenario_id")
    ins = db.get(User, body.instructor_id)
    if not ins or ins.role != "instructor":
        raise HTTPException(422, "instructor_id must be an instructor")
    a = OperatorAssignment(instructor_id=ins.id, student_id=body.student_id, scenario_id=body.scenario_id)
    db.add(a)
    db.flush()
    audit(db, "admin.assignment_create", actor=actor, entity_type="assignment", entity_id=a.id, detail=body.model_dump())
    db.commit()
    return {"id": a.id}


@router.delete("/assignments/{aid}")
def delete_assignment(aid: str, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    a = db.get(OperatorAssignment, aid)
    if not a:
        raise HTTPException(404, "Not found")
    db.delete(a)
    audit(db, "admin.assignment_delete", actor=actor, entity_type="assignment", entity_id=aid)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- settings
@router.get("/settings")
def get_settings(actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    return all_settings(db)


@router.put("/settings")
def put_settings(body: dict, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    for k, v in body.items():
        if k not in EDITABLE:
            raise HTTPException(422, f"Unknown setting {k}")
        try:
            set_setting(db, k, v, actor.id)
        except ValueError as e:
            raise HTTPException(422, str(e))
    audit(db, "admin.settings_update", actor=actor, entity_type="settings", detail={"keys": sorted(body)})
    db.commit()
    return all_settings(db)


# ---------------------------------------------------------------- scenarios
def _scenario_in_scope(db: Session, actor: User, scenario_id: str) -> Scenario:
    sc = db.get(Scenario, scenario_id)
    scope = scoped_scenario_ids(db, actor)
    if not sc or (scope is not None and sc.id not in scope):
        raise HTTPException(404, "Not found")
    return sc


def _scenario_row(sc: Scenario) -> dict:
    return {"id": sc.id, "slug": sc.slug, "title": sc.title, "status": sc.status, "track": sc.track.title,
            "price_paise": sc.price_paise, "owner_id": sc.owner_id, "completion_policy": sc.completion_policy}


@router.get("/scenarios")
def list_scenarios(actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    scope = scoped_scenario_ids(db, actor)
    stmt = select(Scenario)
    if scope is not None:
        stmt = stmt.where(Scenario.id.in_(scope or {""}))
    return [_scenario_row(s) for s in db.execute(stmt).scalars()]


@router.post("/scenarios/import", status_code=201)
def import_scenario(body: dict, actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    try:
        sc = scn.import_definition(db, body, owner_id=actor.id, actor=actor)
    except (scn.DefinitionError, KeyError, ValueError, TypeError) as e:
        db.rollback()
        raise HTTPException(422, f"Invalid scenario definition: {e}")
    db.commit()
    return _scenario_row(sc)


@router.get("/scenarios/{scenario_id}")
def get_scenario(scenario_id: str, actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    sc = _scenario_in_scope(db, actor, scenario_id)
    return {**_scenario_row(sc), "snapshot": scn.build_snapshot(db, sc)}      # includes validation: staff only


class ScenarioPatch(BaseModel):
    title: str | None = Field(default=None, max_length=200)
    public_description: str | None = None
    story: str | None = None
    completion_policy: dict | None = None
    price_paise: int | None = Field(default=None, ge=100, le=10_000_000)


@router.patch("/scenarios/{scenario_id}")
def patch_scenario(scenario_id: str, body: ScenarioPatch, actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    sc = _scenario_in_scope(db, actor, scenario_id)
    ch = body.model_dump(exclude_none=True)
    if "price_paise" in ch and actor.role != "super_admin":
        raise HTTPException(403, "Only a super admin can change pricing")
    if "completion_policy" in ch:
        from ..services.policy import evaluate_policy
        keys = [k for (k,) in db.execute(select(Question.key).where(Question.scenario_id == sc.id, Question.is_final.is_(False)).order_by(Question.position))]
        try:
            evaluate_policy(ch["completion_policy"], keys, set())
        except (ValueError, TypeError) as e:
            raise HTTPException(422, f"Invalid policy: {e}")
        for m in ch["completion_policy"].get("mandatory", []):
            if m not in keys:
                raise HTTPException(422, f"Unknown mandatory question {m}")
    for k, v in ch.items():
        setattr(sc, k, v)
    audit(db, "scenario.update", actor=actor, entity_type="scenario", entity_id=sc.id, detail={"fields": sorted(ch)})
    db.commit()
    return _scenario_row(sc)


class QuestionPatch(BaseModel):
    title: str | None = Field(default=None, max_length=200)
    narrative: str | None = None
    task: str | None = None
    concept_notes: str | None = None
    explanation: str | None = None
    score: int | None = Field(default=None, ge=0, le=1000)
    validation: dict | None = None
    hints: list[str] | None = None


@router.put("/scenarios/{scenario_id}/questions/{key}")
def patch_question(scenario_id: str, key: str, body: QuestionPatch, actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    sc = _scenario_in_scope(db, actor, scenario_id)
    q = db.execute(select(Question).where(Question.scenario_id == sc.id, Question.key == key)).scalar_one_or_none()
    if not q:
        raise HTTPException(404, "Not found")
    ch = body.model_dump(exclude_none=True)
    if "validation" in ch:
        probe = {"questions": [{"key": q.key, "is_final": q.is_final, "validation": ch["validation"], "hints": []}],
                 "flags": [{"key": "final"}], "lab_template": {"key": sc.lab_template.key}, "scenario": {"completion_policy": {"mode": "all"}}}
        try:
            scn.lint_definition(probe)
        except (scn.DefinitionError, KeyError, ValueError, TypeError) as e:
            raise HTTPException(422, f"Invalid validation rule: {e}")
        rule = db.execute(select(ValidationRule).where(ValidationRule.question_id == q.id)).scalar_one()
        rule.spec = ch.pop("validation")
    if "hints" in ch:
        db.query(Hint).filter(Hint.question_id == q.id).delete()
        for i, t in enumerate(ch.pop("hints"), 1):
            if t.strip():
                db.add(Hint(question_id=q.id, level=i, text=t))
    for k, v in ch.items():
        setattr(q, k, v)
    audit(db, "question.update", actor=actor, entity_type="question", entity_id=q.id, detail={"key": key})
    db.commit()
    return {"ok": True, "note": "Changes apply to new attempts after the scenario is (re)published."}


@router.post("/scenarios/{scenario_id}/publish")
def publish_scenario(scenario_id: str, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    sc = _scenario_in_scope(db, actor, scenario_id)
    try:
        ver = scn.publish(db, sc, actor)
    except scn.DefinitionError as e:
        raise HTTPException(422, str(e))
    db.commit()
    return {"status": sc.status, "version": ver.version}


@router.post("/scenarios/{scenario_id}/unpublish")
def unpublish_scenario(scenario_id: str, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    sc = _scenario_in_scope(db, actor, scenario_id)
    sc.status = "unpublished"
    audit(db, "scenario.unpublish", actor=actor, entity_type="scenario", entity_id=sc.id)
    db.commit()
    return {"status": sc.status}


# ---------------------------------------------------------------- progress, labs
@router.get("/progress")
def progress(scenario_id: str | None = None, q: str = "", page: int = Query(1, ge=1), size: int = Query(25, ge=1, le=100),
             actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    stmt = select(ExamAttempt, User, Scenario).join(User, User.id == ExamAttempt.user_id).join(Scenario, Scenario.id == ExamAttempt.scenario_id)
    scope = scoped_scenario_ids(db, actor)
    sids = scoped_student_ids(db, actor)
    if scope is not None:
        stmt = stmt.where(or_(ExamAttempt.scenario_id.in_(scope or {""}), ExamAttempt.user_id.in_(sids or {""})))
    if scenario_id:
        stmt = stmt.where(ExamAttempt.scenario_id == scenario_id)
    if q:
        like = f"%{q.strip()[:60]}%"
        stmt = stmt.where(or_(User.email.ilike(like), User.display_name.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.execute(_page(stmt.order_by(ExamAttempt.started_at.desc()), page, size)).all()
    items = []
    for att, usr, sc in rows:
        done = db.scalar(select(func.count()).select_from(StudentProgress).where(StudentProgress.attempt_id == att.id, StudentProgress.status == "completed")) or 0
        score = db.scalar(select(func.coalesce(func.sum(StudentProgress.score_awarded), 0)).where(StudentProgress.attempt_id == att.id)) or 0
        items.append({"attempt_id": att.id, "student": usr.display_name, "email": usr.email, "scenario": sc.title,
                      "status": att.status, "completed_questions": done, "score": score,
                      "started_at": att.started_at.isoformat(), "expires_at": att.expires_at.isoformat()})
    return {"total": total, "page": page, "items": items}


def _attempt_in_scope(db: Session, actor: User, attempt_id: str) -> ExamAttempt:
    att = db.get(ExamAttempt, attempt_id)
    if not att:
        raise HTTPException(404, "Not found")
    scope = scoped_scenario_ids(db, actor)
    if scope is not None and att.scenario_id not in scope and not can_view_student(db, actor, att.user_id):
        raise HTTPException(404, "Not found")
    return att


@router.post("/attempts/{attempt_id}/reset-lab")
def reset_lab(attempt_id: str, actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    att = _attempt_in_scope(db, actor, attempt_id)
    if att.status != "active":
        raise HTTPException(409, "Only active attempts can be reset")
    snap = db.get(ScenarioVersion, att.version_id).snapshot
    exam_svc.reset_lab(db, att, snap, actor)
    db.commit()
    return {"ok": True}


@router.post("/labs/expire-stale")
def expire_stale(actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    n = expire_stale_sessions(db)
    db.commit()
    return {"expired": n}


def expire_stale_sessions(db: Session) -> int:
    now = utcnow()
    n = 0
    for ls in db.execute(select(LabSession).where(LabSession.status == "active", LabSession.expires_at < now)).scalars():
        ls.status = "expired"
        n += 1
    for att in db.execute(select(ExamAttempt).where(ExamAttempt.status == "active", ExamAttempt.expires_at < now)).scalars():
        att.status = "expired"
    return n


# ---------------------------------------------------------------- payments, completions, letters, audit
@router.get("/payments")
def list_payments(status: str | None = None, page: int = Query(1, ge=1), size: int = Query(25, ge=1, le=100),
                  fmt: str = "json", actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    stmt = select(ExamOrder, User, Scenario).join(User, User.id == ExamOrder.user_id).join(Scenario, Scenario.id == ExamOrder.scenario_id)
    if status:
        stmt = stmt.where(ExamOrder.status == status)
    stmt = stmt.order_by(ExamOrder.created_at.desc())
    if fmt == "csv":
        rows = db.execute(stmt.limit(10000)).all()
        return _csv([[o.id, u.display_name, u.email, s.title, o.status, o.amount_paise, o.currency, o.receipt_number, o.created_at, o.paid_at]
                     for o, u, s in rows], ["order_id", "student", "email", "exam", "status", "amount_paise", "currency", "receipt", "created", "paid"], "payments.csv")
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.execute(_page(stmt, page, size)).all()
    return {"total": total, "items": [{"id": o.id, "student": u.display_name, "email": u.email, "exam": s.title, "status": o.status,
                                       "amount_paise": o.amount_paise, "receipt": o.receipt_number, "reason": o.failure_reason,
                                       "created_at": o.created_at.isoformat()} for o, u, s in rows]}


@router.post("/payments/reconcile")
def reconcile(actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    cutoff = utcnow() - timedelta(minutes=5)
    orders = db.execute(select(ExamOrder).where(ExamOrder.status.in_(["pending", "failed"]), ExamOrder.created_at < cutoff).limit(100)).scalars().all()
    results = {}
    for o in orders:
        results[o.id] = pay.reconcile_order(db, o)
    audit(db, "admin.reconcile", actor=actor, detail={"orders": len(orders)})
    db.commit()
    return results


@router.get("/completions")
def completions(fmt: str = "json", page: int = Query(1, ge=1), size: int = Query(25, ge=1, le=100),
                actor: User = Depends(staff_only), db: Session = Depends(get_db)):
    stmt = select(CompletionRecord, User, Scenario).join(User, User.id == CompletionRecord.user_id).join(Scenario, Scenario.id == CompletionRecord.scenario_id)
    scope = scoped_scenario_ids(db, actor)
    sids = scoped_student_ids(db, actor)
    if scope is not None:
        stmt = stmt.where(CompletionRecord.scenario_id.in_(scope or {""}) | CompletionRecord.user_id.in_(sids or {""}))
    stmt = stmt.order_by(CompletionRecord.completed_at.desc())
    if fmt == "csv":
        rows = db.execute(stmt.limit(10000)).all()
        return _csv([[u.display_name, u.email, s.title, c.score, c.max_score, c.completed_at] for c, u, s in rows],
                    ["name", "email", "exam", "score", "max_score", "completed_at"], "completions.csv")
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    out = []
    for c, u, s in db.execute(_page(stmt, page, size)).all():
        letter = db.execute(select(InternshipLetter).where(InternshipLetter.completion_id == c.id).order_by(InternshipLetter.issued_at.desc())).scalars().first()
        out.append({"id": c.id, "student": u.display_name, "email": u.email, "exam": s.title, "score": c.score, "max_score": c.max_score,
                    "completed_at": c.completed_at.isoformat(), "letter_id": letter.id if letter else None,
                    "letter_status": letter.status if letter else None, "certificate_number": letter.certificate_number if letter else None})
    return {"total": total, "items": out}


class ReasonIn(BaseModel):
    reason: str = Field(min_length=3, max_length=300)


@router.post("/letters/{letter_id}/revoke")
def revoke_letter(letter_id: str, body: ReasonIn, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    letter = db.get(InternshipLetter, letter_id)
    if not letter:
        raise HTTPException(404, "Not found")
    L.revoke(db, letter, body.reason, actor)
    db.commit()
    return {"status": letter.status}


@router.post("/letters/{letter_id}/reissue")
def reissue_letter(letter_id: str, body: ReasonIn, actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    letter = db.get(InternshipLetter, letter_id)
    if not letter:
        raise HTTPException(404, "Not found")
    if letter.status == "revoked":
        raise HTTPException(409, "Revoked letters cannot be reissued; investigate and issue a new decision")
    new = L.reissue(db, letter, actor)
    audit(db, "letter.reissue_reason", actor=actor, entity_type="letter", entity_id=new.id, detail={"reason": body.reason})
    db.commit()
    return {"id": new.id, "verification_id": new.verification_id, "certificate_number": new.certificate_number}


@router.get("/audit")
def audit_log(action: str | None = None, page: int = Query(1, ge=1), size: int = Query(50, ge=1, le=200),
              actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    stmt = select(AuditLog).order_by(AuditLog.id.desc())
    if action:
        stmt = stmt.where(AuditLog.action.like(f"{action[:40]}%"))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.execute(_page(stmt, page, size)).scalars().all()
    return {"total": total, "items": [{"id": r.id, "at": r.created_at.isoformat(), "actor_id": r.actor_id, "role": r.actor_role,
                                       "action": r.action, "entity": f"{r.entity_type}:{r.entity_id}", "detail": r.detail} for r in rows]}


@router.get("/audit/verify")
def audit_verify(actor: User = Depends(admin_only), db: Session = Depends(get_db)):
    return verify_chain(db)
