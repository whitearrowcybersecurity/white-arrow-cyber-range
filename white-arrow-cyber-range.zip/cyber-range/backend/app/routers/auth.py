import re
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit import audit
from ..config import settings
from ..db import get_db
from ..deps import client_ip, current_user
from ..models import User, utcnow
from ..ratelimit import limiter
from ..security import (CSRF_COOKIE, SESSION_COOKIE, SESSION_HOURS, create_session_token, hash_password,
                        new_csrf_token, verify_password)

router = APIRouter(prefix="/api/auth", tags=["auth"])
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s]{2,}$")


class RegisterIn(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(min_length=10, max_length=200)
    display_name: str = Field(min_length=2, max_length=120)


class LoginIn(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(max_length=200)


def user_public(u: User) -> dict:
    return {"id": u.id, "email": u.email, "display_name": u.display_name, "role": u.role}


def _set_session(resp: Response, user: User):
    resp.set_cookie(SESSION_COOKIE, create_session_token(user.id), httponly=True, secure=settings.cookie_secure,
                    samesite="lax", max_age=SESSION_HOURS * 3600, path="/")
    resp.set_cookie(CSRF_COOKIE, new_csrf_token(), httponly=False, secure=settings.cookie_secure,
                    samesite="lax", max_age=SESSION_HOURS * 3600, path="/")


@router.get("/csrf")
def csrf(response: Response):
    response.set_cookie(CSRF_COOKIE, new_csrf_token(), httponly=False, secure=settings.cookie_secure, samesite="lax", path="/")
    return {"ok": True}


@router.post("/register", status_code=201)
def register(body: RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)):
    limiter.enforce(f"reg:{client_ip(request)}", 10, 3600, "Too many registrations from this address")
    email = body.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(422, "Enter a valid email address")
    name = " ".join(body.display_name.split())
    if len(name) < 2:
        raise HTTPException(422, "Enter your full name (it appears on your letter)")
    if db.execute(select(User).where(User.email == email)).scalar_one_or_none():
        raise HTTPException(409, "An account with this email already exists")
    user = User(email=email, display_name=name, password_hash=hash_password(body.password), role="student")
    db.add(user)
    db.flush()
    audit(db, "user.register", actor=user, entity_type="user", entity_id=user.id, ip=client_ip(request))
    db.commit()
    _set_session(response, user)
    return user_public(user)


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    ip, email = client_ip(request), body.email.strip().lower()
    limiter.enforce(f"login-ip:{ip}", 30, 300, "Too many login attempts. Try again in a few minutes.")
    limiter.enforce(f"login:{email}", 8, 300, "Too many login attempts. Try again in a few minutes.")
    user = db.execute(select(User).where(User.email == email)).scalar_one_or_none()
    ok = verify_password(body.password, user.password_hash if user else None)
    if not user or not ok or user.status != "active":
        audit(db, "auth.login_failed", detail={"email": email[:100]}, ip=ip)
        db.commit()
        raise HTTPException(401, "Invalid email or password")
    user.last_login_at = utcnow()
    audit(db, "auth.login", actor=user, ip=ip)
    db.commit()
    _set_session(response, user)
    return user_public(user)


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")
    return {"ok": True}


@router.get("/me")
def me(user: User = Depends(current_user)):
    return user_public(user)
