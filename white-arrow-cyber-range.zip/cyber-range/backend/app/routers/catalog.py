from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import optional_user
from ..models import (CompletionRecord, Entitlement, ExamAttempt, ExamOrder, InternshipLetter, Scenario, Track, User)
from ..services.payments import price_for
from ..services.scenarios import public_preview

router = APIRouter(prefix="/api", tags=["catalog"])


def _scenario_card(db: Session, sc: Scenario) -> dict:
    d = public_preview(db, sc)
    d["price_paise"] = price_for(db, sc)
    d["currency"] = "INR"
    return d


@router.get("/tracks")
def tracks(db: Session = Depends(get_db)):
    out = []
    for t in db.execute(select(Track).where(Track.is_published.is_(True)).order_by(Track.sort_order)).scalars():
        scs = db.execute(select(Scenario).where(Scenario.track_id == t.id, Scenario.status == "published")).scalars().all()
        out.append({"slug": t.slug, "title": t.title, "summary": t.summary, "objectives": t.objectives,
                    "difficulty": t.difficulty, "scenarios": [_scenario_card(db, s) for s in scs]})
    return out


@router.get("/scenarios/{slug}")
def scenario_preview(slug: str, db: Session = Depends(get_db)):
    sc = db.execute(select(Scenario).where(Scenario.slug == slug, Scenario.status == "published")).scalar_one_or_none()
    if not sc:
        raise HTTPException(404, "Not found")
    return _scenario_card(db, sc)


@router.get("/me/exams")
def my_exams(user: User = Depends(optional_user), db: Session = Depends(get_db)):
    """Per-scenario state for the student dashboard: locked / paid / in_progress / completed / letter_issued."""
    if not user:
        raise HTTPException(401, "Authentication required")
    out = []
    for sc in db.execute(select(Scenario).where(Scenario.status == "published")).scalars():
        state, extra = "locked", {}
        comp = db.execute(select(CompletionRecord).where(CompletionRecord.user_id == user.id, CompletionRecord.scenario_id == sc.id)).scalar_one_or_none()
        att = db.execute(select(ExamAttempt).where(ExamAttempt.user_id == user.id, ExamAttempt.scenario_id == sc.id,
                                                   ExamAttempt.status == "active")).scalars().first()
        ent = db.execute(select(Entitlement).where(Entitlement.user_id == user.id, Entitlement.scenario_id == sc.id,
                                                   Entitlement.status == "active")).scalars().first()
        order = db.execute(select(ExamOrder).where(ExamOrder.user_id == user.id, ExamOrder.scenario_id == sc.id)
                           .order_by(ExamOrder.created_at.desc())).scalars().first()
        if comp:
            letter = db.execute(select(InternshipLetter).where(InternshipLetter.completion_id == comp.id,
                                                               InternshipLetter.status == "issued")).scalars().first()
            state = "letter_issued" if letter else "completed"
            extra = {"score": comp.score, "max_score": comp.max_score, "letter_id": letter.id if letter else None,
                     "verification_id": letter.verification_id if letter else None}
        elif att:
            state, extra = "in_progress", {"attempt_id": att.id}
        elif ent:
            state = "paid"
        elif order and order.status == "pending":
            state, extra = "payment_pending", {"order_id": order.id, "checkout_url": order.checkout_url}
        out.append({"scenario": _scenario_card(db, sc), "state": state, "order_status": order.status if order else None,
                    "order_id": order.id if order else None, **extra})
    return out
