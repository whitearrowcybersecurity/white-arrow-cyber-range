import json

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db, session
from ..deps import student_only, user_from_token
from ..models import Submission, User
from ..security import SESSION_COOKIE
from ..services import ai, exam
from ..services.exam import AccessError

router = APIRouter(tags=["exam"])


class AnswerIn(BaseModel):
    answer: str = Field(default="", max_length=200)


class FlagIn(BaseModel):
    flag: str = Field(max_length=200)


class CmdIn(BaseModel):
    command: str = Field(max_length=500)


class AiIn(BaseModel):
    message: str = Field(max_length=1500)


def _gate(db: Session, user: User, attempt_id: str, allow_finished=False):
    try:
        return exam.authorize_attempt(db, user, attempt_id, allow_finished=allow_finished)
    except AccessError:
        raise


@router.post("/api/exams/{scenario_id}/start")
def start(scenario_id: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt = exam.start_attempt(db, user, scenario_id)
    db.commit()
    return {"attempt_id": attempt.id, "expires_at": attempt.expires_at.isoformat()}


@router.get("/api/attempts/{attempt_id}")
def attempt_overview(attempt_id: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id, allow_finished=True)
    return exam.overview(db, attempt, snap)


@router.get("/api/attempts/{attempt_id}/questions/{key}")
def get_question(attempt_id: str, key: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id, allow_finished=True)
    return exam.question_detail(db, attempt, snap, key)


@router.post("/api/attempts/{attempt_id}/questions/{key}/answer")
def post_answer(attempt_id: str, key: str, body: AnswerIn, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id)
    res = exam.submit_answer(db, user, attempt, snap, key, body.answer)
    db.commit()
    res["overview"] = exam.overview(db, attempt, snap)
    return res


@router.post("/api/attempts/{attempt_id}/questions/{key}/hint")
def post_hint(attempt_id: str, key: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id)
    res = exam.reveal_hint(db, attempt, snap, key)
    db.commit()
    return res


@router.post("/api/attempts/{attempt_id}/questions/{key}/ai")
def post_ai(attempt_id: str, key: str, body: AiIn, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id)
    detail = exam.question_detail(db, attempt, snap, key)       # enforces locking
    q = exam._find_q(snap, key)
    res = ai.ask(db, user, attempt, q, detail["hints"], body.message)
    db.commit()
    return res


@router.get("/api/attempts/{attempt_id}/history")
def history(attempt_id: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id, allow_finished=True)
    rows = db.execute(select(Submission).where(Submission.attempt_id == attempt.id).order_by(Submission.created_at.desc()).limit(200)).scalars().all()
    return [{"question": r.question_key, "kind": r.kind, "correct": r.correct, "at": r.created_at.isoformat(),
             "value": r.value if r.kind == "answer" else ""} for r in rows]


@router.post("/api/attempts/{attempt_id}/terminal")
def terminal_rest(attempt_id: str, body: CmdIn, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id)
    res = exam.run_command(db, attempt, snap, body.command)
    db.commit()
    return res


@router.get("/api/attempts/{attempt_id}/terminal/prompt")
def terminal_prompt(attempt_id: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id)
    return {"prompt": exam.terminal_prompt(db, attempt, snap)}


@router.post("/api/attempts/{attempt_id}/final")
def final(attempt_id: str, body: FlagIn, user: User = Depends(student_only), db: Session = Depends(get_db)):
    attempt, ent, snap = _gate(db, user, attempt_id, allow_finished=True)
    res = exam.submit_final(db, user, attempt, ent, snap, body.flag)
    db.commit()
    return res


# ---- interactive terminal over WebSocket ---------------------------------------------------
def _allowed_origins() -> set[str]:
    return set(settings.cors_origins) | {settings.frontend_url, settings.backend_url}


def _ws_step(user_token: str, attempt_id: str, line: str | None):
    """One authorised unit of work. Re-checks identity, payment and entitlement on EVERY message."""
    db = session()
    try:
        user = user_from_token(db, user_token)
        if not user:
            raise AccessError(401, "unauthenticated", "Authentication required")
        attempt, ent, snap = exam.authorize_attempt(db, user, attempt_id)
        if line is None:
            out = {"type": "ready", "prompt": exam.terminal_prompt(db, attempt, snap)}
        else:
            out = {"type": "result", **exam.run_command(db, attempt, snap, line)}
        db.commit()
        return out
    finally:
        db.close()


@router.websocket("/ws/attempts/{attempt_id}/terminal")
async def terminal_ws(ws: WebSocket, attempt_id: str):
    origin = ws.headers.get("origin")
    if origin not in _allowed_origins():          # blocks cross-site WebSocket hijacking
        await ws.close(code=1008)
        return
    token = ws.cookies.get(SESSION_COOKIE)
    try:
        ready = await run_in_threadpool(_ws_step, token, attempt_id, None)
    except AccessError as e:
        await ws.close(code=1008, reason=e.code)
        return
    await ws.accept()
    await ws.send_json(ready)
    try:
        while True:
            raw = await ws.receive_text()
            if len(raw) > 700:
                await ws.send_json({"type": "error", "code": "too_long"})
                continue
            try:
                msg = json.loads(raw)
                line = str(msg["cmd"])
            except (ValueError, KeyError, TypeError):
                await ws.send_json({"type": "error", "code": "bad_message"})
                continue
            try:
                await ws.send_json(await run_in_threadpool(_ws_step, token, attempt_id, line))
            except AccessError as e:
                await ws.send_json({"type": "error", "code": e.code, "message": e.message})
                await ws.close(code=1008)
                return
            except HTTPException as e:               # rate limit
                await ws.send_json({"type": "error", "code": "rate_limited", "message": str(e.detail)})
    except WebSocketDisconnect:
        return
