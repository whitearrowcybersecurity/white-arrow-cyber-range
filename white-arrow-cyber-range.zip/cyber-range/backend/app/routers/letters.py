from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import client_ip, current_user
from ..models import InternshipLetter, User
from ..ratelimit import limiter
from ..services import letters as L

router = APIRouter(tags=["letters"])


@router.get("/api/me/letters")
def my_letters(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.execute(select(InternshipLetter).where(InternshipLetter.user_id == user.id).order_by(InternshipLetter.issued_at.desc())).scalars().all()
    return [{"id": r.id, "certificate_number": r.certificate_number, "verification_id": r.verification_id,
             "status": r.status, "issued_at": r.issued_at.isoformat(), "scenario": r.data["scenario_title"]} for r in rows]


@router.get("/api/letters/{letter_id}/pdf")
def download(letter_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    letter = db.get(InternshipLetter, letter_id)
    if not letter:
        raise HTTPException(404, "Not found")
    is_owner = letter.user_id == user.id
    if not is_owner:
        # staff may download within their scope (admin router has the scoped listing); students never see others'
        from .admin import can_view_student
        if user.role not in ("instructor", "super_admin") or not can_view_student(db, user, letter.user_id):
            raise HTTPException(404, "Not found")
    if letter.status != "issued" and user.role == "student":
        raise HTTPException(410, "This letter is no longer valid")
    return Response(L.letter_pdf(letter), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{letter.certificate_number}.pdf"'})


@router.get("/api/verify/{verification_id}")
def verify(verification_id: str, request: Request, db: Session = Depends(get_db)):
    limiter.enforce(f"verify:{client_ip(request)}", 30, 60, "Too many verification lookups")
    vid = verification_id.strip().upper()[:20]
    out = L.lookup_public(db, vid)
    db.commit()
    return out
