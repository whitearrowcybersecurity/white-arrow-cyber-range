import html
import json

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit import audit
from ..config import settings
from ..db import get_db
from ..deps import client_ip, student_only
from ..models import ExamOrder, Payment, Scenario, User
from ..ratelimit import limiter
from ..services import payments as pay
from ..services.pdf import render_receipt_pdf
from ..services.platform_settings import get_setting

router = APIRouter(tags=["payments"])


def order_public(o: ExamOrder, sc: Scenario | None = None) -> dict:
    return {"id": o.id, "scenario_id": o.scenario_id, "scenario": sc.title if sc else None, "status": o.status,
            "amount_paise": o.amount_paise, "currency": o.currency, "checkout_url": o.checkout_url if o.status == "pending" else None,
            "paid_at": o.paid_at.isoformat() if o.paid_at else None, "receipt_number": o.receipt_number}


@router.post("/api/exams/{scenario_id}/orders", status_code=201)
def create_order(scenario_id: str, request: Request, user: User = Depends(student_only), db: Session = Depends(get_db)):
    limiter.enforce(f"order:{user.id}", 10, 3600, "Too many checkout attempts. Try again later.")
    sc = db.get(Scenario, scenario_id)
    if not sc or sc.status != "published":
        raise HTTPException(404, "Not found")
    try:
        order = pay.create_order(db, user, sc)
    except pay.OrderError as e:
        db.commit()
        raise HTTPException(409 if e.code in ("already_entitled", "already_completed") else 502 if e.code == "provider_error" else 400, e.message)
    db.commit()
    return order_public(order, sc)


@router.get("/api/orders/{order_id}")
def get_order(order_id: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    o = db.get(ExamOrder, order_id)
    if not o or o.user_id != user.id:
        raise HTTPException(404, "Not found")
    return order_public(o, db.get(Scenario, o.scenario_id))


@router.get("/api/orders/{order_id}/receipt.pdf")
def receipt(order_id: str, user: User = Depends(student_only), db: Session = Depends(get_db)):
    o = db.get(ExamOrder, order_id)
    if not o or o.user_id != user.id or o.status not in ("paid", "partially_refunded", "refunded"):
        raise HTTPException(404, "Not found")
    p = db.execute(select(Payment).where(Payment.order_id == o.id, Payment.status != "failed")).scalars().first()
    sc = db.get(Scenario, o.scenario_id)
    pdf = render_receipt_pdf(receipt_number=o.receipt_number or "-", org_name=get_setting(db, "org_name"),
                             customer_name=user.display_name, customer_email=user.email,
                             item=f"Exam fee - {sc.title}", amount_paise=o.amount_paise, currency=o.currency,
                             paid_at=o.paid_at, payment_id=p.provider_payment_id if p else "-")
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="receipt-{o.receipt_number}.pdf"'})


# ---- provider -> us -------------------------------------------------------------------------
@router.get("/api/payments/callback")
def callback(request: Request, db: Session = Depends(get_db)):
    """Browser redirect from the provider. Never trusted on its own: see services.payments.handle_callback."""
    limiter.enforce(f"cb:{client_ip(request)}", 60, 60)
    order, result = pay.handle_callback(db, dict(request.query_params))
    db.commit()
    oid = order.id if order else ""
    return RedirectResponse(f"{settings.frontend_url}/payment/result?order={oid}&r={result}", status_code=303)


@router.post("/api/payments/webhook")
async def webhook(request: Request, db: Session = Depends(get_db)):
    raw = await request.body()
    if len(raw) > 200_000:
        raise HTTPException(413, "Payload too large")
    try:
        res = pay.handle_webhook(db, raw, request.headers.get("x-razorpay-signature"),
                                 request.headers.get("x-razorpay-event-id"))
    except PermissionError:
        audit(db, "webhook.bad_signature", ip=client_ip(request))
        db.commit()
        raise HTTPException(400, "Invalid signature")
    except ValueError:
        raise HTTPException(400, "Bad payload")
    db.commit()
    return res          # always 200 for verified deliveries so the provider stops retrying


# ---- test-mode checkout page (only when PAYMENT_PROVIDER=mock) --------------------------------
def _mock_only():
    if settings.payment_provider != "mock" or settings.env == "production":
        raise HTTPException(404, "Not found")


@router.get("/mock-pay/{link_id}", response_class=HTMLResponse)
def mock_pay_page(link_id: str, db: Session = Depends(get_db)):
    _mock_only()
    p = pay.get_provider()
    link = p.links.get(link_id)
    if not link:
        raise HTTPException(404, "Not found")
    amt = link["amount"] / 100
    lid = html.escape(link_id)
    return f"""<!doctype html><meta charset=utf-8><title>Test checkout</title>
<body style="font-family:system-ui;background:#0b1220;color:#e5edf5;display:grid;place-items:center;min-height:100vh;margin:0">
<div style="background:#111b2e;border:1px solid #1f2f4a;border-radius:12px;padding:28px;max-width:360px;text-align:center">
<p style="color:#14b8a6;font-weight:700;letter-spacing:.08em;font-size:12px">TEST MODE - NO REAL PAYMENT</p>
<h2 style="margin:6px 0">Pay &#8377;{amt:,.2f}</h2>
<form method=post action="/api/dev/mock-pay/{lid}/complete">
<button name=outcome value=paid style="width:100%;padding:12px;border:0;border-radius:8px;background:#14b8a6;color:#04201c;font-weight:700;cursor:pointer">Simulate successful payment</button>
<button name=outcome value=failed style="width:100%;margin-top:8px;padding:12px;border:1px solid #334766;border-radius:8px;background:transparent;color:#e5edf5;cursor:pointer">Simulate failed payment</button>
</form></div></body>"""


@router.post("/api/dev/mock-pay/{link_id}/complete")
async def mock_pay_complete(link_id: str, request: Request, db: Session = Depends(get_db)):
    """Simulates what Razorpay does: fire a signed webhook, then redirect the browser with a signed callback."""
    _mock_only()
    form = await request.form()
    outcome = "paid" if form.get("outcome") == "paid" else "failed"
    p = pay.get_provider()
    if link_id not in p.links:
        raise HTTPException(404, "Not found")
    sim = p.simulate(link_id, outcome)
    link = sim["link"]
    order = db.get(ExamOrder, link["reference_id"])
    secret = settings.razorpay_webhook_secret or "mock-webhook-secret"
    settings.razorpay_webhook_secret = secret
    if not settings.razorpay_key_secret:
        settings.razorpay_key_secret = "mock-key-secret"
    if outcome == "paid":
        body = {"event": "payment_link.paid", "payload": {
            "payment_link": {"entity": {"id": link_id, "reference_id": order.id, "status": "paid", "amount_paid": link["amount_paid"]}},
            "payment": {"entity": {"id": sim["payment_id"], "amount": sim["amount"], "currency": "INR", "status": "captured", "method": "upi"}}}}
    else:
        body = {"event": "payment.failed", "payload": {"payment": {"entity": {
            "id": sim["payment_id"], "amount": sim["amount"], "currency": "INR", "status": "failed",
            "notes": {"order_id": order.id}, "error_description": "Simulated failure"}}}}
    raw = json.dumps(body).encode()
    pay.handle_webhook(db, raw, pay.webhook_signature(secret, raw), None)
    db.commit()
    status = "paid" if outcome == "paid" else "created"
    params = {"razorpay_payment_id": sim["payment_id"], "razorpay_payment_link_id": link_id,
              "razorpay_payment_link_reference_id": order.id, "razorpay_payment_link_status": status}
    params["razorpay_signature"] = pay.callback_signature(settings.razorpay_key_secret, link_id, order.id, status, sim["payment_id"])
    from urllib.parse import urlencode
    return RedirectResponse(f"{settings.backend_url}/api/payments/callback?{urlencode(params)}", status_code=303)
