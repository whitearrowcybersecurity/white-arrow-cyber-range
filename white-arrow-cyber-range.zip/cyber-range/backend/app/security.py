"""Password hashing, session tokens, CSRF helpers."""
import hmac
import secrets
from datetime import datetime, timedelta, timezone

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from .config import settings

_ph = PasswordHasher()
SESSION_COOKIE = "wa_session"
CSRF_COOKIE = "wa_csrf"
SESSION_HOURS = 12

# Verified against when the account does not exist, so login timing doesn't reveal valid emails.
_DUMMY_HASH = _ph.hash("not-a-real-password")


def hash_password(pw: str) -> str:
    return _ph.hash(pw)


def verify_password(pw: str, hashed: str | None) -> bool:
    try:
        return _ph.verify(hashed or _DUMMY_HASH, pw) and hashed is not None
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def create_session_token(user_id: str) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode(
        {"sub": user_id, "iat": now, "exp": now + timedelta(hours=SESSION_HOURS), "typ": "session"},
        settings.secret_key, algorithm="HS256")


def decode_session_token(token: str) -> str | None:
    try:
        data = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        return data["sub"] if data.get("typ") == "session" else None
    except jwt.PyJWTError:
        return None


def new_csrf_token() -> str:
    return secrets.token_urlsafe(32)


def consteq(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())
