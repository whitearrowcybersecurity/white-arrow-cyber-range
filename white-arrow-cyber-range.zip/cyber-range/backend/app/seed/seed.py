"""Seed the database. Usage:  python -m app.seed.seed [--demo]

 * bootstraps a super admin from BOOTSTRAP_ADMIN_EMAIL / BOOTSTRAP_ADMIN_PASSWORD
 * imports and publishes the sample 30-question scenario (idempotent)
 * --demo additionally creates demo instructor + student accounts (development only)
"""
import sys

from sqlalchemy import select

from .. import db as dbmod
from ..config import settings
from ..models import Base, Scenario, User
from ..security import hash_password
from ..services import scenarios as scn
from .night_watch import DEFINITION


def strip_solutions(defn: dict) -> dict:
    d = dict(defn)
    d["questions"] = [{k: v for k, v in q.items() if k != "solution"} for q in defn["questions"]]
    return d


def seed(db, *, demo: bool = False) -> dict:
    out = {}
    if settings.bootstrap_admin_email and settings.bootstrap_admin_password:
        email = settings.bootstrap_admin_email.lower()
        if not db.execute(select(User).where(User.email == email)).scalar_one_or_none():
            db.add(User(email=email, display_name="Platform Admin", password_hash=hash_password(settings.bootstrap_admin_password), role="super_admin"))
            out["admin"] = email
    if demo:
        if settings.env == "production":
            raise SystemExit("--demo is not allowed in production")
        for email, name, role in (("admin@example.test", "Demo Admin", "super_admin"), ("instructor@example.test", "Demo Instructor", "instructor"),
                                  ("student@example.test", "Demo Student", "student")):
            if not db.execute(select(User).where(User.email == email)).scalar_one_or_none():
                db.add(User(email=email, display_name=name, password_hash=hash_password("DemoPassw0rd!"), role=role))
        out["demo_accounts"] = "admin@/instructor@/student@example.test  (password: DemoPassw0rd!)"
    db.flush()
    slug = DEFINITION["scenario"]["slug"]
    sc = db.execute(select(Scenario).where(Scenario.slug == slug)).scalar_one_or_none()
    if sc is None:
        owner = db.execute(select(User).where(User.role == "super_admin")).scalars().first()
        sc = scn.import_definition(db, strip_solutions(DEFINITION), owner_id=owner.id if owner else None, actor=owner)
        scn.publish(db, sc, owner)
        out["scenario"] = slug
    db.commit()
    return out


if __name__ == "__main__":
    settings.validate()
    dbmod.configure()
    Base.metadata.create_all(dbmod.engine)
    s = dbmod.session()
    try:
        print(seed(s, demo="--demo" in sys.argv))
    finally:
        s.close()
