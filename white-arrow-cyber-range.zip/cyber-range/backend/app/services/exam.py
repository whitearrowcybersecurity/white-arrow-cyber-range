"""Exam runtime: access control, attempts, questions, submissions, final objective, completion."""
import hashlib
import json
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..audit import audit
from ..models import (CommandLog, CompletionRecord, Entitlement, ExamAttempt, ExamOrder, LabSession, Payment,
                      Scenario, ScenarioVersion, StudentProgress, Submission, User, utcnow)
from ..ratelimit import limiter
from ..terminal.engine import Lab
from ..terminal.labs import hook_for, new_lab_state
from .letters import issue_letter
from .platform_settings import get_setting
from .payments import usable_entitlement
from .policy import evaluate_policy
from .validation import derive_flag, eval_condition, flag_digest, flag_matches, validate


class AccessError(Exception):
    def __init__(self, status: int, code: str, message: str, extra: dict | None = None):
        super().__init__(message)
        self.status, self.code, self.message, self.extra = status, code, message, extra or {}


# ---------------------------------------------------------------- access control
def _entitlement_payment_ok(db: Session, ent: Entitlement) -> bool:
    """Entitlement is only honoured while its order is paid and a captured payment still stands."""
    order = db.get(ExamOrder, ent.order_id)
    if not order or order.status not in ("paid", "partially_refunded"):
        return False
    pays = db.execute(select(Payment).where(Payment.order_id == order.id, Payment.status.in_(["captured", "partially_refunded"]))).scalars().all()
    return any(p.refunded_paise < p.amount_paise for p in pays)


def authorize_attempt(db: Session, user: User, attempt_id: str, *, allow_finished: bool = False) -> tuple[ExamAttempt, Entitlement, dict]:
    """The single gate in front of every protected exam route (REST and WebSocket)."""
    if user.status != "active" or user.role != "student":
        raise AccessError(403, "forbidden", "Not allowed")
    attempt = db.get(ExamAttempt, attempt_id)
    if not attempt or attempt.user_id != user.id:
        raise AccessError(404, "not_found", "Not found")  # same answer for 'missing' and 'someone else's'
    ent = db.get(Entitlement, attempt.entitlement_id)
    if allow_finished and attempt.status in ("completed",):
        return attempt, ent, db.get(ScenarioVersion, attempt.version_id).snapshot
    if not ent or ent.user_id != user.id or ent.scenario_id != attempt.scenario_id:
        raise AccessError(403, "no_entitlement", "No valid entitlement")
    if ent.status != "active" or not _entitlement_payment_ok(db, ent):
        if attempt.status == "active":
            attempt.status = "revoked"
            db.commit()
        raise AccessError(402, "payment_required", "Payment required")
    if attempt.status == "completed":
        raise AccessError(409, "completed", "This exam is already completed")
    if attempt.status != "active":
        raise AccessError(403, "attempt_closed", "This attempt is no longer active")
    if utcnow() >= attempt.expires_at:
        attempt.status = "expired"
        db.commit()
        raise AccessError(403, "attempt_expired", "This attempt has expired")
    return attempt, ent, db.get(ScenarioVersion, attempt.version_id).snapshot


def start_attempt(db: Session, user: User, scenario_id: str) -> ExamAttempt:
    if user.status != "active" or user.role != "student":
        raise AccessError(403, "forbidden", "Only students can take exams")
    sc = db.get(Scenario, scenario_id)
    if not sc or sc.status != "published" or not sc.published_version_id:
        raise AccessError(404, "not_found", "Not found")
    if db.execute(select(CompletionRecord).where(CompletionRecord.user_id == user.id, CompletionRecord.scenario_id == sc.id)).first():
        raise AccessError(409, "completed", "You have already completed this exam")
    # resume an in-progress attempt
    cur = db.execute(select(ExamAttempt).where(ExamAttempt.user_id == user.id, ExamAttempt.scenario_id == sc.id,
                                               ExamAttempt.status == "active")).scalars().first()
    if cur:
        authorize_attempt(db, user, cur.id)
        return cur
    ent = usable_entitlement(db, user.id, sc.id)
    if not ent or not _entitlement_payment_ok(db, ent):
        raise AccessError(402, "payment_required", "Payment required to start this exam")
    ent = db.execute(select(Entitlement).where(Entitlement.id == ent.id).with_for_update()).scalar_one()
    if ent.attempts_used >= ent.attempts_allowed:
        raise AccessError(403, "attempts_exhausted", "No attempts remaining on this entitlement")
    ver = db.get(ScenarioVersion, sc.published_version_id)
    hours = int(get_setting(db, "attempt_duration_hours"))
    now = utcnow()
    attempt = ExamAttempt(user_id=user.id, scenario_id=sc.id, version_id=ver.id, entitlement_id=ent.id, status="active",
                          started_at=now, expires_at=now + timedelta(hours=hours))
    db.add(attempt)
    db.flush()
    ent.attempts_used += 1
    db.add(LabSession(attempt_id=attempt.id, status="active", state=new_lab_state(ver.snapshot["lab"]["template_key"]),
                      created_at=now, last_active_at=now, expires_at=attempt.expires_at))
    audit(db, "attempt.start", actor=user, entity_type="attempt", entity_id=attempt.id, detail={"scenario": sc.slug})
    return attempt


# ---------------------------------------------------------------- progress helpers
def _progress_map(db: Session, attempt_id: str) -> dict[str, StudentProgress]:
    rows = db.execute(select(StudentProgress).where(StudentProgress.attempt_id == attempt_id)).scalars().all()
    return {r.question_key: r for r in rows}


def _completed(pm) -> set[str]:
    return {k for k, v in pm.items() if v.status == "completed"}


def _find_q(snap: dict, key: str) -> dict:
    for q in snap["questions"]:
        if q["key"] == key:
            return q
    raise AccessError(404, "not_found", "Question not found")


def policy_state(snap: dict, pm) -> "PolicyResult":
    preceding = [q["key"] for q in snap["questions"] if not q["is_final"]]
    return evaluate_policy(snap["policy"], preceding, _completed(pm))


def _q_status(q: dict, snap: dict, pm) -> str:
    done = _completed(pm)
    if q["key"] in done:
        return "completed"
    if q["is_final"]:
        return "available" if policy_state(snap, pm).eligible else "locked"
    return "available" if all(p in done for p in q["prerequisites"]) else "locked"


def overview(db: Session, attempt: ExamAttempt, snap: dict) -> dict:
    pm = _progress_map(db, attempt.id)
    pol = policy_state(snap, pm)
    qs = [{"key": q["key"], "position": q["position"], "stage": q["stage"], "title": q["title"], "score": q["score"],
           "is_final": q["is_final"], "status": _q_status(q, snap, pm)} for q in snap["questions"]]
    score = sum(p.score_awarded for p in pm.values())
    return {"attempt_id": attempt.id, "status": attempt.status, "scenario": snap["scenario"]["title"],
            "story": snap["scenario"]["story"], "expires_at": attempt.expires_at.isoformat(),
            "score": score, "max_score": sum(q["score"] for q in snap["questions"]),
            "completed": len(_completed(pm)), "total": len(snap["questions"]),
            "final_gate": pol.public(), "questions": qs}


def question_detail(db: Session, attempt: ExamAttempt, snap: dict, key: str) -> dict:
    q = _find_q(snap, key)
    pm = _progress_map(db, attempt.id)
    status = _q_status(q, snap, pm)
    if status == "locked":
        raise AccessError(403, "locked", "This question is locked", {"gate": policy_state(snap, pm).public()} if q["is_final"] else {})
    prog = pm.get(key)
    used = prog.hints_used if prog else 0
    out = {"key": q["key"], "position": q["position"], "stage": q["stage"], "title": q["title"], "narrative": q["narrative"],
           "task": q["task"], "concept_notes": q["concept_notes"], "score": q["score"], "is_final": q["is_final"],
           "status": status, "submissions": prog.submissions if prog else 0, "hints_total": len(q["hints"]),
           "hints_used": used, "hints": q["hints"][:used],
           "input": "flag" if q["validation"]["type"] == "flag" else ("answer" if q["validation"]["type"] == "answer" else "check")}
    if status == "completed":
        out["explanation"] = q["explanation"]
    return out


def reveal_hint(db: Session, attempt: ExamAttempt, snap: dict, key: str) -> dict:
    d = question_detail(db, attempt, snap, key)
    q = _find_q(snap, key)
    prog = _get_progress(db, attempt, key)
    if prog.hints_used >= len(q["hints"]):
        return {"hint": None, "hints_used": prog.hints_used, "hints_total": len(q["hints"])}
    prog.hints_used += 1
    return {"hint": q["hints"][prog.hints_used - 1], "level": prog.hints_used, "hints_used": prog.hints_used,
            "hints_total": len(q["hints"])}


def _get_progress(db: Session, attempt: ExamAttempt, key: str) -> StudentProgress:
    row = db.execute(select(StudentProgress).where(StudentProgress.attempt_id == attempt.id,
                                                   StudentProgress.question_key == key)).scalar_one_or_none()
    if not row:
        row = StudentProgress(attempt_id=attempt.id, question_key=key, status="in_progress")
        db.add(row)
        db.flush()
    return row


# ---------------------------------------------------------------- terminal
def lab_session(db: Session, attempt: ExamAttempt) -> LabSession:
    ls = db.execute(select(LabSession).where(LabSession.attempt_id == attempt.id)).scalar_one()
    if ls.status != "active" or utcnow() >= ls.expires_at:
        ls.status = "expired"
        db.commit()
        raise AccessError(403, "lab_expired", "This lab session has expired")
    return ls


def _lab(db: Session, ls: LabSession, snap: dict, attempt: ExamAttempt) -> Lab:
    key = snap["lab"]["template_key"]
    sid, scid = ls.id, attempt.scenario_id
    return Lab(ls.state, snap["lab"]["enabled_commands"], hook_for(key), {"flag": lambda: derive_flag(sid, scid, "final")})


def terminal_prompt(db: Session, attempt: ExamAttempt, snap: dict) -> str:
    ls = lab_session(db, attempt)
    import copy
    return _lab(db, copy.deepcopy(ls), snap, attempt).prompt()


def run_command(db: Session, attempt: ExamAttempt, snap: dict, line: str) -> dict:
    import copy
    limiter.enforce(f"term:{attempt.id}", 120, 60, "Slow down - too many commands")
    ls = lab_session(db, attempt)
    state = copy.deepcopy(ls.state)
    lab = Lab(state, snap["lab"]["enabled_commands"], hook_for(snap["lab"]["template_key"]),
              {"flag": lambda: derive_flag(ls.id, attempt.scenario_id, "final")})
    out, code = lab.run(line)
    ls.state = state                      # reassign so SQLAlchemy sees the JSON change
    ls.last_active_at = utcnow()
    n = db.query(CommandLog).filter(CommandLog.lab_session_id == ls.id).count()
    if n < 3000:
        db.add(CommandLog(lab_session_id=ls.id, command=line[:600], output=out[:4000], exit_code=code))
    return {"output": out, "exit_code": code, "prompt": lab.prompt()}


def reset_lab(db: Session, attempt: ExamAttempt, snap: dict, actor) -> LabSession:
    ls = db.execute(select(LabSession).where(LabSession.attempt_id == attempt.id)).scalar_one()
    ls.state = new_lab_state(snap["lab"]["template_key"])
    ls.resets += 1
    ls.status = "active"
    ls.last_active_at = utcnow()
    db.query(CommandLog).filter(CommandLog.lab_session_id == ls.id).delete()
    audit(db, "lab.reset", actor=actor, entity_type="lab_session", entity_id=ls.id, detail={"attempt": attempt.id})
    return ls


def _log(db: Session, ls: LabSession) -> list[dict]:
    rows = db.query(CommandLog).filter(CommandLog.lab_session_id == ls.id).order_by(CommandLog.id.desc()).limit(500).all()
    return [{"command": r.command, "output": r.output, "exit_code": r.exit_code} for r in rows]


# ---------------------------------------------------------------- submissions
def submit_answer(db: Session, user: User, attempt: ExamAttempt, snap: dict, key: str, answer: str) -> dict:
    q = _find_q(snap, key)
    if q["is_final"]:
        raise AccessError(400, "use_final", "Use the final flag submission")
    detail = question_detail(db, attempt, snap, key)          # enforces locking / prerequisites
    prog = _get_progress(db, attempt, key)
    if prog.status == "completed":
        return {"correct": True, "already_completed": True, "score_awarded": 0, "explanation": q["explanation"]}
    limiter.enforce(f"sub:{attempt.id}:{key}", 20, 60, "Too many submissions - wait a moment")
    ls = lab_session(db, attempt)
    rule = q["validation"]
    answer = (answer or "")[:200]
    ok = validate(rule, answer=answer, state=ls.state, log=_log(db, ls))
    prog.submissions += 1
    db.add(Submission(attempt_id=attempt.id, question_key=key, kind="answer" if rule["type"] == "answer" else "check",
                      value=answer if rule["type"] == "answer" else "", correct=ok))
    if not ok:
        return {"correct": False, "already_completed": False, "score_awarded": 0,
                "feedback": _wrong_feedback(rule)}
    prog.status = "completed"
    prog.score_awarded = q["score"]
    prog.completed_at = utcnow()
    audit(db, "question.complete", actor=user, entity_type="attempt", entity_id=attempt.id, detail={"q": key})
    return {"correct": True, "already_completed": False, "score_awarded": q["score"], "explanation": q["explanation"]}


def _wrong_feedback(rule: dict) -> str:
    if rule["type"] == "state":
        return "The lab is not in the required state yet. Re-check the task and your commands."
    if rule["type"] == "answer" and rule.get("and_state"):
        return "That doesn't match - make sure the lab state reflects your earlier fix, then re-run the check."
    return "Not quite. Re-read the task, check the terminal output, or reveal a hint."


def submit_final(db: Session, user: User, attempt: ExamAttempt, ent: Entitlement, snap: dict, flag: str) -> dict:
    limiter.enforce(f"flag:{attempt.id}", 8, 60, "Too many flag submissions - wait a minute")
    # idempotent: already completed
    done = db.execute(select(CompletionRecord).where(CompletionRecord.attempt_id == attempt.id)).scalar_one_or_none()
    if done:
        return {"correct": True, "already_completed": True, "completion_id": done.id}
    q = snap["questions"][-1]
    pm = _progress_map(db, attempt.id)
    pol = policy_state(snap, pm)
    if not pol.eligible:
        audit(db, "flag.rejected_not_eligible", actor=user, entity_type="attempt", entity_id=attempt.id, detail=pol.public())
        raise AccessError(403, "not_eligible", "Complete more of the exam before the final objective", {"gate": pol.public()})
    ls = lab_session(db, attempt)
    expected = derive_flag(ls.id, attempt.scenario_id, q["validation"]["flag"])
    submitted = (flag or "").strip()[:200]
    ok = flag_matches(submitted, expected)
    prog = _get_progress(db, attempt, q["key"])
    prog.submissions += 1
    db.add(Submission(attempt_id=attempt.id, question_key=q["key"], kind="flag", value=flag_digest(submitted), correct=ok))
    if not ok:
        audit(db, "flag.wrong", actor=user, entity_type="attempt", entity_id=attempt.id)
        return {"correct": False, "feedback": "That flag is not valid for this lab session."}
    # outcome must also hold in the real lab state (revalidated at submission time)
    if not all(eval_condition(ls.state, c) for c in q["validation"].get("require_state", [])):
        audit(db, "flag.state_mismatch", actor=user, entity_type="attempt", entity_id=attempt.id)
        return {"correct": False, "feedback": "The lab is no longer in the required hardened state."}

    now = utcnow()
    prog.status = "completed"
    prog.score_awarded = q["score"]
    prog.completed_at = now
    pm = _progress_map(db, attempt.id)
    score = sum(p.score_awarded for p in pm.values())
    max_score = sum(x["score"] for x in snap["questions"])
    completed = len(_completed(pm))
    payload = {"user": user.id, "scenario": attempt.scenario_id, "attempt": attempt.id, "lab": ls.id,
               "score": score, "max": max_score, "at": now.isoformat(), "version": attempt.version_id}
    rec = CompletionRecord(user_id=user.id, scenario_id=attempt.scenario_id, attempt_id=attempt.id,
                           entitlement_id=ent.id, lab_session_id=ls.id, version_id=attempt.version_id, score=score,
                           max_score=max_score, questions_completed=completed, questions_total=len(snap["questions"]),
                           completed_at=now, record_hash=hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest())
    db.add(rec)
    attempt.status = "completed"
    attempt.completed_at = now
    ls.status = "expired"
    db.flush()
    audit(db, "completion.recorded", actor=user, entity_type="completion", entity_id=rec.id,
          detail={"score": score, "max": max_score})
    letter = issue_letter(db, rec, user)
    return {"correct": True, "already_completed": False, "completion_id": rec.id, "letter_id": letter.id,
            "score": score, "max_score": max_score}
