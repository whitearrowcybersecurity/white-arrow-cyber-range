"""Internship letter issuance, verification, revocation, reissue."""
import hashlib
import json
import secrets
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..audit import audit
from ..config import settings
from ..models import (CertificateVerificationRecord, CompletionRecord, InternshipLetter, Scenario, User, utcnow)
from .platform_settings import get_setting
from .pdf import render_letter_pdf

_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def new_verification_id() -> str:
    g = ["".join(secrets.choice(_ALPHABET) for _ in range(4)) for _ in range(3)]
    return "WA-" + "-".join(g)


def mask_name(name: str) -> str:
    return " ".join(w[0] + "*" * (len(w) - 1) for w in name.split() if w)


def verify_url(vid: str) -> str:
    return f"{settings.frontend_url}/verify/{vid}"


def issue_letter(db: Session, completion: CompletionRecord, user: User, *, supersedes: InternshipLetter | None = None,
                 actor=None) -> InternshipLetter:
    if supersedes is None:
        existing = db.execute(select(InternshipLetter).where(InternshipLetter.completion_id == completion.id,
                                                              InternshipLetter.status == "issued")).scalar_one_or_none()
        if existing:
            return existing  # never issue a duplicate without explicit admin reissue
    sc = db.get(Scenario, completion.scenario_id)
    fmt = get_setting(db, "date_format")
    now = utcnow()
    for _ in range(8):
        seq = (db.scalar(select(func.count()).select_from(InternshipLetter)) or 0) + 1 + _
        number = get_setting(db, "certificate_number_format").format(year=now.year, seq=seq)
        vid = new_verification_id()
        data = {
            "holder_name": user.display_name, "scenario_title": sc.title, "track_title": sc.track.title,
            "org_name": get_setting(db, "org_name"), "internship_title": get_setting(db, "internship_title"),
            "signatory_name": get_setting(db, "signatory_name"), "signatory_title": get_setting(db, "signatory_title"),
            "issued_on": now.strftime(fmt), "completed_on": completion.completed_at.strftime(fmt),
            "include_score": bool(get_setting(db, "include_score")),
            "score": completion.score, "max_score": completion.max_score,
            "certificate_number": number, "verification_id": vid,
        }
        letter = InternshipLetter(completion_id=completion.id, user_id=user.id, certificate_number=number,
                                  verification_id=vid, status="issued", issued_at=now, data=data,
                                  supersedes_id=supersedes.id if supersedes else None)
        try:
            with db.begin_nested():
                db.add(letter)
                db.flush()
                holder = user.display_name if get_setting(db, "verify_show_full_name") else mask_name(user.display_name)
                db.add(CertificateVerificationRecord(
                    letter_id=letter.id, verification_id=vid,
                    public_payload={"holder": holder, "organization": data["org_name"], "track": data["track_title"],
                                    "scenario": data["scenario_title"], "completed_on": data["completed_on"],
                                    "issued_on": data["issued_on"]}))
        except IntegrityError:
            continue
        audit(db, "letter.issue", actor=actor or user, entity_type="letter", entity_id=letter.id,
              detail={"number": number, "reissue": bool(supersedes)})
        return letter
    raise RuntimeError("could not allocate a unique certificate number")


def letter_pdf(letter: InternshipLetter) -> bytes:
    return render_letter_pdf(letter.data, letter.status, verify_url(letter.verification_id))


def lookup_public(db: Session, vid: str) -> dict:
    """Minimum necessary disclosure. Unknown IDs and malformed IDs look identical."""
    rec = db.execute(select(CertificateVerificationRecord).where(CertificateVerificationRecord.verification_id == vid)).scalar_one_or_none()
    if not rec:
        return {"valid": False}
    letter = db.get(InternshipLetter, rec.letter_id)
    rec.view_count += 1
    rec.last_viewed_at = utcnow()
    out = {"valid": letter.status == "issued", "status": letter.status, **rec.public_payload}
    return out


def revoke(db: Session, letter: InternshipLetter, reason: str, actor) -> None:
    if letter.status == "revoked":
        return
    letter.status = "revoked"
    letter.revoked_at = utcnow()
    letter.revoke_reason = reason[:300]
    audit(db, "letter.revoke", actor=actor, entity_type="letter", entity_id=letter.id, detail={"reason": reason[:200]})


def reissue(db: Session, letter: InternshipLetter, actor) -> InternshipLetter:
    completion = db.get(CompletionRecord, letter.completion_id)
    user = db.get(User, letter.user_id)
    if letter.status == "issued":
        letter.status = "superseded"
    new = issue_letter(db, completion, user, supersedes=letter, actor=actor)
    audit(db, "letter.reissue", actor=actor, entity_type="letter", entity_id=new.id, detail={"supersedes": letter.id})
    return new
