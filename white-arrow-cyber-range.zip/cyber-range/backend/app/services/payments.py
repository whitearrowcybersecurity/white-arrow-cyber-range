"""Payments: Razorpay Payment Links (same flow as the PHP-SecureCode Academy site) with the gaps closed.

What the reference site did, and what changes here:
  * It trusted the browser redirect (signed) and granted access to *whoever was logged in*.
    -> Here the order is created server-side, bound to the student, and access is granted to
       the order's owner only, after signature + server-side re-fetch + amount check.
  * It had no webhook, so a student closing the tab after paying lost access.
    -> Here the signed webhook is the primary confirmation; the redirect is a fast path.
  * Replay was blocked by a UNIQUE column on the user row.
    -> Here payments.provider_payment_id and payment_events.provider_event_id are UNIQUE and
       every handler is idempotent.
  * Amount was never compared to what was owed.
    -> Amount and currency are checked against the order (stored in integer paise).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from dataclasses import dataclass
from datetime import timedelta

import httpx
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..audit import audit
from ..config import settings
from ..models import (CompletionRecord, Entitlement, ExamAttempt, ExamOrder, Payment, PaymentEvent,
                      Scenario, User, utcnow)
from .platform_settings import get_setting


class ProviderError(Exception):
    pass


class OrderError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code, self.message = code, message


@dataclass
class LinkInfo:
    link_id: str
    short_url: str


# ---------------------------------------------------------------- signatures
def callback_signature(secret: str, link_id: str, reference_id: str, status: str, payment_id: str) -> str:
    """Razorpay Payment Link redirect signature: HMAC-SHA256 over id|reference|status|payment_id."""
    msg = f"{link_id}|{reference_id}|{status}|{payment_id}"
    return hmac.new(secret.encode(), msg.encode(), hashlib.sha256).hexdigest()


def verify_callback_signature(link_id, reference_id, status, payment_id, signature) -> bool:
    if not (link_id and payment_id and status and signature):
        return False
    expected = callback_signature(settings.razorpay_key_secret, link_id, reference_id or "", status, payment_id)
    return hmac.compare_digest(expected, signature)


def webhook_signature(secret: str, raw_body: bytes) -> str:
    return hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()


def verify_webhook_signature(raw_body: bytes, signature: str | None) -> bool:
    if not signature or not settings.razorpay_webhook_secret:
        return False
    return hmac.compare_digest(webhook_signature(settings.razorpay_webhook_secret, raw_body), signature)


# ---------------------------------------------------------------- providers
class MockProvider:
    """Test-mode provider: no network. Used for local dev and the automated tests."""
    name = "mock"

    def __init__(self):
        self.links: dict[str, dict] = {}

    def create_payment_link(self, *, reference_id, amount_paise, description, callback_url, customer) -> LinkInfo:
        link_id = "plink_mock_" + secrets.token_hex(8)
        self.links[link_id] = {"id": link_id, "status": "created", "amount": amount_paise, "amount_paid": 0,
                               "reference_id": reference_id, "currency": "INR", "payments": []}
        return LinkInfo(link_id, f"{settings.backend_url}/mock-pay/{link_id}")

    def fetch_payment_link(self, link_id: str) -> dict:
        if link_id not in self.links:
            raise ProviderError("link not found")
        return json.loads(json.dumps(self.links[link_id]))

    def simulate(self, link_id: str, outcome: str, amount: int | None = None) -> dict:
        link = self.links[link_id]
        pid = "pay_mock_" + secrets.token_hex(7)
        amt = link["amount"] if amount is None else amount
        if outcome == "paid":
            link["status"] = "paid" if amt >= link["amount"] else "partially_paid"
            link["amount_paid"] += amt
            link["payments"].append({"payment_id": pid, "amount": amt, "status": "captured"})
        else:
            link["payments"].append({"payment_id": pid, "amount": amt, "status": "failed"})
        return {"payment_id": pid, "amount": amt, "link": json.loads(json.dumps(link))}

    def cancel(self, link_id: str):
        self.links[link_id]["status"] = "cancelled"


class RazorpayProvider:
    name = "razorpay"
    base = "https://api.razorpay.com/v1"

    def _client(self):
        return httpx.Client(auth=(settings.razorpay_key_id, settings.razorpay_key_secret), timeout=15)

    def create_payment_link(self, *, reference_id, amount_paise, description, callback_url, customer) -> LinkInfo:
        payload = {"amount": amount_paise, "currency": "INR", "accept_partial": False, "description": description,
                   "reference_id": reference_id, "callback_url": callback_url, "callback_method": "get",
                   "customer": customer, "notify": {"sms": False, "email": False}, "reminder_enable": False,
                   "notes": {"order_id": reference_id}}
        try:
            with self._client() as c:
                r = c.post(f"{self.base}/payment_links", json=payload)
        except httpx.HTTPError as e:
            raise ProviderError(f"could not reach Razorpay: {e.__class__.__name__}") from e
        data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        if r.status_code != 200 or not data.get("short_url"):
            raise ProviderError((data.get("error") or {}).get("description", "Razorpay rejected the request"))
        return LinkInfo(data["id"], data["short_url"])

    def fetch_payment_link(self, link_id: str) -> dict:
        try:
            with self._client() as c:
                r = c.get(f"{self.base}/payment_links/{link_id}")
        except httpx.HTTPError as e:
            raise ProviderError(f"could not reach Razorpay: {e.__class__.__name__}") from e
        if r.status_code != 200:
            raise ProviderError(f"Razorpay returned {r.status_code}")
        return r.json()


_provider = None


def get_provider():
    global _provider
    if _provider is None or _provider.name != settings.payment_provider:
        _provider = MockProvider() if settings.payment_provider == "mock" else RazorpayProvider()
    return _provider


def set_provider(p):  # tests
    global _provider
    _provider = p


# ---------------------------------------------------------------- orders
def price_for(db: Session, sc: Scenario) -> int:
    return sc.price_paise if sc.price_paise is not None else int(get_setting(db, "exam_fee_paise"))


def usable_entitlement(db: Session, user_id: str, scenario_id: str) -> Entitlement | None:
    now = utcnow()
    ents = db.execute(select(Entitlement).where(Entitlement.user_id == user_id, Entitlement.scenario_id == scenario_id,
                                                Entitlement.status == "active")).scalars().all()
    for e in ents:
        if (e.expires_at is None or e.expires_at > now) and e.attempts_used < e.attempts_allowed:
            return e
        if e.attempts_used >= e.attempts_allowed:
            # still usable if an attempt is in progress
            active = db.execute(select(ExamAttempt).where(ExamAttempt.entitlement_id == e.id, ExamAttempt.status == "active")).first()
            if active:
                return e
    return None


def create_order(db: Session, user: User, sc: Scenario) -> ExamOrder:
    if user.role != "student":
        raise OrderError("not_student", "Only student accounts can purchase exams")
    if sc.status != "published":
        raise OrderError("unavailable", "This exam is not available")
    if db.execute(select(CompletionRecord).where(CompletionRecord.user_id == user.id, CompletionRecord.scenario_id == sc.id)).first():
        raise OrderError("already_completed", "You have already completed this exam")
    if usable_entitlement(db, user.id, sc.id):
        raise OrderError("already_entitled", "You already have access to this exam")
    amount = price_for(db, sc)
    if amount <= 0:
        raise OrderError("bad_price", "This exam has no valid price configured")

    # reuse a recent unpaid order instead of spamming the provider with links
    cutoff = utcnow() - timedelta(hours=2)
    existing = db.execute(select(ExamOrder).where(
        ExamOrder.user_id == user.id, ExamOrder.scenario_id == sc.id, ExamOrder.status == "pending",
        ExamOrder.created_at > cutoff, ExamOrder.amount_paise == amount)).scalars().first()
    if existing and existing.checkout_url:
        return existing

    order = ExamOrder(user_id=user.id, scenario_id=sc.id, amount_paise=amount, currency="INR",
                      status="created", provider=settings.payment_provider)
    db.add(order)
    db.flush()
    provider = get_provider()
    try:
        link = provider.create_payment_link(
            reference_id=order.id, amount_paise=amount, description=f"White Arrow Cyber Range - {sc.title}",
            callback_url=f"{settings.backend_url}/api/payments/callback",
            customer={"name": user.display_name[:50], "email": user.email})
    except ProviderError as e:
        order.status = "failed"
        order.failure_reason = f"provider_error: {e}"[:300]
        audit(db, "order.create_failed", actor=user, entity_type="order", entity_id=order.id, detail={"error": str(e)})
        db.commit()
        raise OrderError("provider_error", "Could not start checkout right now. Please try again shortly.") from e
    order.provider_link_id = link.link_id
    order.checkout_url = link.short_url
    order.status = "pending"
    audit(db, "order.create", actor=user, entity_type="order", entity_id=order.id,
          detail={"scenario": sc.slug, "amount_paise": amount})
    return order


# ---------------------------------------------------------------- state transitions (all idempotent)
def _grant_entitlement(db: Session, order: ExamOrder) -> Entitlement:
    days = int(get_setting(db, "entitlement_validity_days"))
    ent = Entitlement(user_id=order.user_id, scenario_id=order.scenario_id, order_id=order.id, status="active",
                      attempts_allowed=int(get_setting(db, "attempts_per_entitlement")),
                      expires_at=utcnow() + timedelta(days=days) if days else None)
    db.add(ent)
    return ent


def process_captured(db: Session, order: ExamOrder, payment_id: str, amount: int, currency: str,
                     source: str, method: str | None = None) -> str:
    """Returns: granted | duplicate | extra_capture | amount_mismatch | ignored"""
    existing = db.execute(select(Payment).where(Payment.provider_payment_id == payment_id)).scalar_one_or_none()
    if existing:
        if existing.order_id != order.id:
            audit(db, "payment.cross_order_replay", entity_type="payment", entity_id=existing.id,
                  detail={"attempted_order": order.id})
        return "duplicate"
    if order.status in ("refunded", "partially_refunded"):
        return "ignored"
    if amount != order.amount_paise or currency != order.currency:
        try:
            with db.begin_nested():
                db.add(Payment(order_id=order.id, provider_payment_id=payment_id, amount_paise=amount, currency=currency,
                               status="captured", source=source, method=method))
                if order.status != "paid":
                    order.status = "review"
                    order.failure_reason = f"amount_mismatch: expected {order.amount_paise} {order.currency}, got {amount} {currency}"
                audit(db, "payment.amount_mismatch", entity_type="order", entity_id=order.id,
                      detail={"expected": order.amount_paise, "got": amount, "currency": currency, "payment_id": payment_id})
        except IntegrityError:
            return "duplicate"
        return "amount_mismatch"
    try:
        with db.begin_nested():
            db.add(Payment(order_id=order.id, provider_payment_id=payment_id, amount_paise=amount, currency=currency,
                           status="captured", source=source, method=method))
            if order.status == "paid":
                audit(db, "payment.extra_capture", entity_type="order", entity_id=order.id, detail={"payment_id": payment_id})
                return "extra_capture"
            order.status = "paid"
            order.paid_at = utcnow()
            order.failure_reason = None
            order.receipt_number = f"WA-RC-{order.paid_at:%Y%m}-{order.id[:8].upper()}"
            _grant_entitlement(db, order)
            audit(db, "payment.verified", entity_type="order", entity_id=order.id,
                  detail={"payment_id": payment_id, "amount_paise": amount, "source": source})
    except IntegrityError:
        return "duplicate"  # lost a race with another worker: the other one granted access
    return "granted"


def process_failed(db: Session, order: ExamOrder, payment_id: str | None, reason: str) -> str:
    if order.status == "paid" or order.status in ("refunded", "partially_refunded"):
        return "ignored"
    if payment_id:
        try:
            with db.begin_nested():
                db.add(Payment(order_id=order.id, provider_payment_id=payment_id, amount_paise=order.amount_paise,
                               currency=order.currency, status="failed", source="webhook"))
        except IntegrityError:
            return "duplicate"
    order.status = "failed"
    order.failure_reason = reason[:300]
    audit(db, "payment.failed", entity_type="order", entity_id=order.id, detail={"payment_id": payment_id, "reason": reason[:200]})
    return "recorded"


def process_terminal_state(db: Session, order: ExamOrder, state: str) -> str:
    if order.status in ("created", "pending", "failed"):
        order.status = state
        audit(db, f"order.{state}", entity_type="order", entity_id=order.id)
        return "recorded"
    return "ignored"


def revoke_for_refund(db: Session, order: ExamOrder) -> None:
    """Refund policy (documented in docs/PAYMENTS.md):
       * full refund before completion  -> entitlement revoked, active attempts/labs closed
       * full refund after completion   -> completion record and letter are NOT deleted automatically
                                           (immutable); flagged in the audit log for admin review."""
    ent = db.execute(select(Entitlement).where(Entitlement.order_id == order.id)).scalar_one_or_none()
    if not ent:
        return
    ent.status = "revoked"
    ent.revoked_reason = "refunded"
    for att in db.execute(select(ExamAttempt).where(ExamAttempt.entitlement_id == ent.id, ExamAttempt.status == "active")).scalars():
        att.status = "revoked"
    done = db.execute(select(CompletionRecord).where(CompletionRecord.entitlement_id == ent.id)).scalar_one_or_none()
    if done:
        audit(db, "refund.after_completion", entity_type="completion", entity_id=done.id,
              detail={"order": order.id, "action": "admin review required for letter"})


def process_refund(db: Session, provider_payment_id: str, refund_amount: int, refund_id: str) -> str:
    pay = db.execute(select(Payment).where(Payment.provider_payment_id == provider_payment_id)).scalar_one_or_none()
    if not pay:
        return "unknown_payment"
    order = db.get(ExamOrder, pay.order_id)
    pay.refunded_paise = min(pay.amount_paise, pay.refunded_paise + refund_amount)
    if pay.refunded_paise >= pay.amount_paise:
        pay.status = "refunded"
        order.status = "refunded"
        revoke_for_refund(db, order)
        audit(db, "payment.refunded", entity_type="order", entity_id=order.id, detail={"refund_id": refund_id})
        return "refunded"
    pay.status = "partially_refunded"
    if order.status == "paid":
        order.status = "partially_refunded"
    audit(db, "payment.partially_refunded", entity_type="order", entity_id=order.id,
          detail={"refund_id": refund_id, "refunded_paise": pay.refunded_paise, "action": "admin review"})
    return "partially_refunded"


# ---------------------------------------------------------------- inbound: redirect callback
def handle_callback(db: Session, params: dict) -> tuple[ExamOrder | None, str]:
    """Browser redirect from the provider. Signature-verified, then re-confirmed server-side.
    Returns (order, result) where result in paid|pending|failed|invalid."""
    link_id = params.get("razorpay_payment_link_id", "")
    ref = params.get("razorpay_payment_link_reference_id", "")
    status = params.get("razorpay_payment_link_status", "")
    pid = params.get("razorpay_payment_id", "")
    sig = params.get("razorpay_signature", "")
    if not verify_callback_signature(link_id, ref, status, pid, sig):
        return None, "invalid"
    order = db.get(ExamOrder, ref)
    if not order or order.provider_link_id != link_id:
        return None, "invalid"
    if status != "paid":
        return order, "failed" if status in ("cancelled", "expired") else "pending"
    if order.status == "paid":
        return order, "paid"
    try:
        link = get_provider().fetch_payment_link(link_id)
    except ProviderError:
        return order, "pending"  # webhook / reconcile will finish the job; never grant on the redirect alone
    if link.get("status") != "paid" or int(link.get("amount_paid", 0)) != order.amount_paise \
            or link.get("reference_id") != order.id:
        return order, "pending"
    payments = link.get("payments") or []
    if payments and not any(p.get("payment_id") == pid and p.get("status") in ("captured", "authorized") for p in payments):
        return order, "pending"
    outcome = process_captured(db, order, pid, order.amount_paise, order.currency, "callback")
    return order, "paid" if outcome in ("granted", "duplicate", "extra_capture") and order.status == "paid" else "pending"


# ---------------------------------------------------------------- inbound: webhook
def handle_webhook(db: Session, raw: bytes, signature: str | None, event_id: str | None) -> dict:
    if not verify_webhook_signature(raw, signature):
        raise PermissionError("bad signature")
    try:
        body = json.loads(raw)
    except ValueError:
        raise ValueError("bad json")
    digest = hashlib.sha256(raw).hexdigest()
    eid = event_id or "sha256:" + digest   # identical re-deliveries are still de-duplicated
    ev = PaymentEvent(provider_event_id=eid, event_type=str(body.get("event", ""))[:60], payload_digest=digest)
    try:
        with db.begin_nested():
            db.add(ev)
    except IntegrityError:
        return {"status": "duplicate"}
    outcome = _dispatch_event(db, body)
    ev.outcome = outcome[:40]
    return {"status": outcome}


def _entity(body, kind):
    return (((body.get("payload") or {}).get(kind) or {}).get("entity")) or {}


def _dispatch_event(db: Session, body: dict) -> str:
    et = body.get("event", "")
    if et == "payment_link.paid":
        link, pay = _entity(body, "payment_link"), _entity(body, "payment")
        order = db.get(ExamOrder, link.get("reference_id", ""))
        if not order or order.provider_link_id != link.get("id") or not pay.get("id"):
            return "unmatched"
        if link.get("status") != "paid" or pay.get("status") not in ("captured", "authorized"):
            return "ignored"
        return process_captured(db, order, pay["id"], int(pay.get("amount", -1)), str(pay.get("currency", "")).upper(),
                                "webhook", pay.get("method"))
    if et == "payment.failed":
        pay = _entity(body, "payment")
        oid = (pay.get("notes") or {}).get("order_id") if isinstance(pay.get("notes"), dict) else None
        order = db.get(ExamOrder, oid) if oid else None
        if not order:
            return "unmatched"
        return process_failed(db, order, pay.get("id"), (pay.get("error_description") or "payment failed"))
    if et in ("payment_link.cancelled", "payment_link.expired"):
        link = _entity(body, "payment_link")
        order = db.get(ExamOrder, link.get("reference_id", ""))
        if not order or order.provider_link_id != link.get("id"):
            return "unmatched"
        return process_terminal_state(db, order, "cancelled" if et.endswith("cancelled") else "expired")
    if et == "refund.processed":
        ref = _entity(body, "refund")
        if not ref.get("payment_id"):
            return "unmatched"
        return process_refund(db, ref["payment_id"], int(ref.get("amount", 0)), ref.get("id", ""))
    return "ignored"


# ---------------------------------------------------------------- reconciliation
def reconcile_order(db: Session, order: ExamOrder) -> str:
    if not order.provider_link_id or order.status not in ("pending", "failed", "created"):
        return "skipped"
    try:
        link = get_provider().fetch_payment_link(order.provider_link_id)
    except ProviderError as e:
        return f"provider_error: {e}"
    st = link.get("status")
    if st == "paid":
        cap = [p for p in (link.get("payments") or []) if p.get("status") in ("captured", "authorized")]
        if not cap:
            return "paid_but_no_payment_id"
        return process_captured(db, order, cap[0]["payment_id"], int(link.get("amount_paid", 0)),
                                str(link.get("currency", "INR")).upper(), "reconcile")
    if st in ("expired", "cancelled"):
        return process_terminal_state(db, order, st)
    return "still_pending"
