"""PDF rendering (reportlab). Letters render only from the frozen `data` stored at issuance."""
import io
from datetime import datetime
from xml.sax.saxutils import escape

from reportlab.graphics import renderPDF
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph

NAVY = colors.HexColor("#0b1220")
TEAL = colors.HexColor("#14b8a6")


def _qr(c: canvas.Canvas, text: str, x: float, y: float, size: float):
    w = QrCodeWidget(text)
    b = w.getBounds()
    d = Drawing(size, size, transform=[size / (b[2] - b[0]), 0, 0, size / (b[3] - b[1]), 0, 0])
    d.add(w)
    renderPDF.draw(d, c, x, y)


def _para(c, text, x, y, width, style):
    p = Paragraph(text, style)
    _, h = p.wrap(width, 1000)
    p.drawOn(c, x, y - h)
    return y - h


def render_letter_pdf(data: dict, status: str, verify_url: str) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4, invariant=1)
    W, H = A4
    c.setTitle(f"{data['internship_title']} - {data['certificate_number']}")
    c.setAuthor(data["org_name"])
    # header band
    c.setFillColor(NAVY)
    c.rect(0, H - 48 * mm, W, 48 * mm, stroke=0, fill=1)
    c.setFillColor(TEAL)
    c.rect(0, H - 50 * mm, W, 2 * mm, stroke=0, fill=1)
    # placeholder logo (replace by configuring a logo asset)
    c.setFillColor(TEAL)
    pts = [(18, 30), (30, 18), (30, 25), (42, 25), (42, 35), (30, 35), (30, 42)]   # arrow mark (placeholder logo)
    path = c.beginPath()
    path.moveTo(pts[0][0] * mm, H - pts[0][1] * mm)
    for x, y in pts[1:]:
        path.lineTo(x * mm, H - y * mm)
    path.close()
    c.drawPath(path, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50 * mm, H - 26 * mm, data["org_name"])
    c.setFont("Helvetica", 11)
    c.setFillColor(colors.HexColor("#9fb3c8"))
    c.drawString(50 * mm, H - 34 * mm, "White Arrow Cyber Range")

    y = H - 70 * mm
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 17)
    c.drawString(20 * mm, y, data["internship_title"])
    c.setFont("Helvetica", 9)
    c.setFillColor(colors.HexColor("#475569"))
    c.drawString(20 * mm, y - 7 * mm, f"Certificate No. {data['certificate_number']}    |    Issued {data['issued_on']}")

    body = ParagraphStyleCache.body
    y -= 20 * mm
    text = (f"This is to certify that <b>{escape(data['holder_name'])}</b> has successfully completed the practical "
            f"cybersecurity assessment <b>&ldquo;{escape(data['scenario_title'])}&rdquo;</b> within the "
            f"<b>&ldquo;{escape(data['track_title'])}&rdquo;</b> learning track on the {escape(data['org_name'])} "
            f"Cyber Range, finishing on <b>{escape(data['completed_on'])}</b>.")
    y = _para(c, text, 20 * mm, y, W - 40 * mm, body)
    if data.get("include_score") and data.get("max_score"):
        y = _para(c, f"Assessment score: <b>{int(data['score'])} / {int(data['max_score'])}</b> "
                     f"({round(100 * data['score'] / data['max_score'])}%).", 20 * mm, y - 5 * mm, W - 40 * mm, body)
    y = _para(c, "This letter confirms completion of an online, hands-on assessment on an isolated training lab. It does not "
                 "represent employment, a paid engagement, or any period of work experience.",
              20 * mm, y - 8 * mm, W - 40 * mm, ParagraphStyleCache.small)

    # signature block
    c.setStrokeColor(colors.HexColor("#94a3b8"))
    c.line(20 * mm, 70 * mm, 80 * mm, 70 * mm)
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(20 * mm, 64 * mm, data["signatory_name"])
    c.setFont("Helvetica", 9)
    c.setFillColor(colors.HexColor("#475569"))
    c.drawString(20 * mm, 59 * mm, data["signatory_title"][:70])

    # verification block
    _qr(c, verify_url, W - 55 * mm, 40 * mm, 35 * mm)
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.HexColor("#475569"))
    c.drawString(20 * mm, 40 * mm, "Verify this letter:")
    c.setFont("Helvetica-Bold", 9)
    c.setFillColor(NAVY)
    c.drawString(20 * mm, 35 * mm, data["verification_id"])
    c.setFont("Helvetica", 7.5)
    c.setFillColor(colors.HexColor("#475569"))
    c.drawString(20 * mm, 30 * mm, verify_url)
    if status != "issued":
        c.saveState()
        c.setFillColor(colors.Color(0.8, 0.1, 0.1, alpha=0.18))
        c.setFont("Helvetica-Bold", 80)
        c.translate(W / 2, H / 2)
        c.rotate(35)
        c.drawCentredString(0, 0, status.upper())
        c.restoreState()
    c.showPage()
    c.save()
    return buf.getvalue()


def render_receipt_pdf(*, receipt_number: str, org_name: str, customer_name: str, customer_email: str, item: str,
                       amount_paise: int, currency: str, paid_at: datetime, payment_id: str) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4, invariant=1)
    W, H = A4
    c.setFillColor(NAVY)
    c.rect(0, H - 30 * mm, W, 30 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(20 * mm, H - 19 * mm, f"{org_name} - Payment Receipt")
    c.setFillColor(NAVY)
    y = H - 50 * mm
    rows = [("Receipt no.", receipt_number), ("Date (UTC)", paid_at.strftime("%d %b %Y %H:%M")),
            ("Billed to", f"{customer_name} <{customer_email}>"), ("Item", item),
            ("Amount", f"{currency} {amount_paise / 100:,.2f}"), ("Payment reference", payment_id)]
    for k, v in rows:
        c.setFont("Helvetica", 9)
        c.setFillColor(colors.HexColor("#475569"))
        c.drawString(20 * mm, y, k)
        c.setFont("Helvetica-Bold", 10)
        c.setFillColor(NAVY)
        c.drawString(60 * mm, y, v[:90])
        y -= 9 * mm
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.HexColor("#475569"))
    c.drawString(20 * mm, y - 6 * mm, "This receipt is generated by White Arrow Cyber Range and is not a tax invoice.")
    c.showPage()
    c.save()
    return buf.getvalue()


class ParagraphStyleCache:
    body = ParagraphStyle("body", fontName="Helvetica", fontSize=12, leading=18, textColor=NAVY)
    small = ParagraphStyle("small", fontName="Helvetica-Oblique", fontSize=9, leading=13, textColor=colors.HexColor("#475569"))
