"""Admin-configurable platform settings (stored in DB; secrets never live here)."""
from sqlalchemy.orm import Session

from ..config import settings as env
from ..models import Setting, utcnow

DEFAULTS = {
    "exam_fee_paise": env.default_exam_fee_paise,   # Rs 300 = 30,000 paise
    "attempts_per_entitlement": 1,
    "entitlement_validity_days": 90,
    "attempt_duration_hours": 8,
    "lab_idle_expiry_hours": 24,
    "ai_enabled": True,
    "ai_daily_limit": 30,
    "ai_per_minute_limit": 5,
    # internship letter template
    "org_name": "White Arrow Cybersecurity",
    "internship_title": "Cybersecurity Practical Internship Assessment",
    "signatory_name": "Hrushikesh Walvekar",
    "signatory_title": "CEO - Director, White Arrow Cybersecurity OPC Pvt Ltd",
    "date_format": "%d %B %Y",
    "certificate_number_format": "WA-CR-{year}-{seq:05d}",
    "include_score": True,
    "logo_path": "",
    "verify_show_full_name": False,
}

EDITABLE = set(DEFAULTS)


def get_setting(db: Session, key: str):
    row = db.get(Setting, key)
    if row is not None:
        return row.value.get("v")
    return DEFAULTS[key]


def all_settings(db: Session) -> dict:
    return {k: get_setting(db, k) for k in DEFAULTS}


def set_setting(db: Session, key: str, value, actor_id: str | None):
    if key not in EDITABLE:
        raise KeyError(key)
    default = DEFAULTS[key]
    if isinstance(default, bool):
        if not isinstance(value, bool):
            raise ValueError(f"{key} must be boolean")
    elif isinstance(default, int):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{key} must be a non-negative integer")
        if key == "exam_fee_paise" and value < 100 and value != 0:
            raise ValueError("exam_fee_paise is in paise (Rs 300 = 30000)")
    elif not isinstance(value, str):
        raise ValueError(f"{key} must be a string")
    row = db.get(Setting, key)
    if row is None:
        db.add(Setting(key=key, value={"v": value}, updated_by=actor_id, updated_at=utcnow()))
    else:
        row.value = {"v": value}
        row.updated_by = actor_id
        row.updated_at = utcnow()
