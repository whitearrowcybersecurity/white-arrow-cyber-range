"""Final-objective gating policy. Evaluated on the backend, and again at final submission."""
from dataclasses import dataclass, field


@dataclass
class PolicyResult:
    eligible: bool
    required: int
    completed: int
    total_preceding: int
    missing_mandatory: list = field(default_factory=list)

    def public(self) -> dict:
        # Do not tell students *which* mandatory questions are missing beyond counts.
        return {"eligible": self.eligible, "required": self.required, "completed": self.completed,
                "total_preceding": self.total_preceding, "mandatory_missing": len(self.missing_mandatory)}


def evaluate_policy(policy: dict, preceding_keys: list[str], completed_keys: set[str]) -> PolicyResult:
    n = len(preceding_keys)
    done = len([k for k in preceding_keys if k in completed_keys])
    mode = (policy or {}).get("mode", "all")
    if mode == "all":
        required, mandatory = n, []
    elif mode in ("percent", "percent_plus_mandatory"):
        pct = int(policy.get("percent", 100))
        if not 0 <= pct <= 100:
            raise ValueError("percent must be 0..100")
        required = -(-pct * n // 100)  # ceil without floats: 20% of 29 -> 6, of 34 -> 7
        mandatory = list(policy.get("mandatory", [])) if mode == "percent_plus_mandatory" else []
    else:
        raise ValueError(f"unknown policy mode {mode}")
    missing = [k for k in mandatory if k not in completed_keys]
    return PolicyResult(eligible=(done >= required and not missing), required=required, completed=done,
                        total_preceding=n, missing_mandatory=missing)
