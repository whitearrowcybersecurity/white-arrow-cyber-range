"""Scenario authoring: import a definition, build immutable published versions."""
import hashlib
import json
import re

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..audit import audit
from ..models import (Flag, Hint, LabTemplate, Question, QuestionPrerequisite, Scenario,
                      ScenarioVersion, Track, ValidationRule, utcnow)
from ..terminal.labs import BUILDERS
from .policy import evaluate_policy
from .validation import CUSTOM

VALID_RULE_TYPES = {"answer", "state", "command", "command_output", "custom", "flag"}
KEY_RE = re.compile(r"^[a-z][a-z0-9_]{0,38}$")


class DefinitionError(ValueError):
    pass


def lint_definition(d: dict) -> None:
    qs = d.get("questions") or []
    if not qs:
        raise DefinitionError("scenario needs at least one question")
    keys = [q["key"] for q in qs]
    if len(set(keys)) != len(keys):
        raise DefinitionError("duplicate question keys")
    for k in keys:
        if not KEY_RE.match(k):
            raise DefinitionError(f"bad question key {k!r}")
    finals = [q for q in qs if q.get("is_final")]
    if len(finals) != 1 or not qs[-1].get("is_final"):
        raise DefinitionError("exactly one final question is required and it must be last")
    flag_keys = {f["key"] for f in d.get("flags", [])}
    for q in qs:
        rule = q.get("validation") or {}
        t = rule.get("type")
        if t not in VALID_RULE_TYPES:
            raise DefinitionError(f"{q['key']}: unknown validation type {t!r}")
        if t == "command":
            re.compile(rule["pattern"])
        if t == "command_output":
            re.compile(rule["command_pattern"])
        if t == "custom" and rule.get("name") not in CUSTOM:
            raise DefinitionError(f"{q['key']}: unknown custom validator")
        if t == "flag" and rule.get("flag") not in flag_keys:
            raise DefinitionError(f"{q['key']}: flag {rule.get('flag')!r} is not defined")
        if t == "answer" and not rule.get("accepted"):
            raise DefinitionError(f"{q['key']}: answer rule needs accepted answers")
        for p in q.get("prerequisites", []):
            if p not in keys or keys.index(p) >= keys.index(q["key"]):
                raise DefinitionError(f"{q['key']}: prerequisite {p!r} must be an earlier question")
        for i, h in enumerate(q.get("hints", [])):
            if not isinstance(h, str) or not h.strip():
                raise DefinitionError(f"{q['key']}: hint {i + 1} is empty")
    lab = d.get("lab_template", {})
    if lab.get("key") not in BUILDERS:
        raise DefinitionError(f"unknown lab template {lab.get('key')!r}")
    pol = d["scenario"].get("completion_policy", {})
    evaluate_policy(pol, keys[:-1], set())  # raises on bad policy
    for m in pol.get("mandatory", []):
        if m not in keys[:-1]:
            raise DefinitionError(f"mandatory question {m!r} does not exist")


def import_definition(db: Session, d: dict, owner_id: str | None = None, *, actor=None) -> Scenario:
    lint_definition(d)
    t = d["track"]
    track = db.execute(select(Track).where(Track.slug == t["slug"])).scalar_one_or_none()
    if track is None:
        track = Track(slug=t["slug"], title=t["title"], summary=t.get("summary", ""), objectives=t.get("objectives", []),
                      difficulty=t.get("difficulty", "beginner"), sort_order=t.get("sort_order", 0), is_published=True)
        db.add(track)
        db.flush()
    lt = d["lab_template"]
    lab = db.execute(select(LabTemplate).where(LabTemplate.key == lt["key"])).scalar_one_or_none()
    if lab is None:
        lab = LabTemplate(key=lt["key"], title=lt.get("title", lt["key"]), mode=lt.get("mode", "simulated"), spec={})
        db.add(lab)
        db.flush()
    s = d["scenario"]
    if db.execute(select(Scenario).where(Scenario.slug == s["slug"])).scalar_one_or_none():
        raise DefinitionError(f"scenario slug {s['slug']!r} already exists")
    sc = Scenario(track_id=track.id, lab_template_id=lab.id, slug=s["slug"], title=s["title"],
                  public_description=s.get("public_description", ""), objectives=s.get("objectives", []),
                  difficulty=s.get("difficulty", "beginner"), duration_minutes=s.get("duration_minutes", 180),
                  eligibility_text=s.get("eligibility_text", ""), story=s.get("story", ""),
                  price_paise=s.get("price_paise"), status="draft", owner_id=owner_id,
                  completion_policy=s.get("completion_policy", {"mode": "all"}),
                  enabled_commands=d.get("enabled_commands", []))
    db.add(sc)
    db.flush()
    idmap = {}
    for pos, q in enumerate(d["questions"], 1):
        row = Question(scenario_id=sc.id, key=q["key"], position=pos, stage=q.get("stage", ""), title=q["title"],
                       narrative=q.get("narrative", ""), task=q.get("task", ""), concept_notes=q.get("concept_notes", ""),
                       explanation=q.get("explanation", ""), score=q.get("score", 10), is_final=bool(q.get("is_final")))
        db.add(row)
        db.flush()
        idmap[q["key"]] = row.id
        db.add(ValidationRule(question_id=row.id, spec=q["validation"]))
        for lvl, text in enumerate(q.get("hints", []), 1):
            db.add(Hint(question_id=row.id, level=lvl, text=text))
    for q in d["questions"]:
        for p in q.get("prerequisites", []):
            db.add(QuestionPrerequisite(question_id=idmap[q["key"]], requires_question_id=idmap[p]))
    for f in d.get("flags", []):
        db.add(Flag(scenario_id=sc.id, key=f["key"], label=f.get("label", ""), is_final=f.get("is_final", True)))
    db.flush()
    audit(db, "scenario.import", actor=actor, entity_type="scenario", entity_id=sc.id, detail={"slug": sc.slug})
    return sc


def build_snapshot(db: Session, sc: Scenario) -> dict:
    qs = db.execute(select(Question).where(Question.scenario_id == sc.id).order_by(Question.position)).scalars().all()
    by_id = {q.id: q for q in qs}
    out = []
    for q in qs:
        rule = db.execute(select(ValidationRule).where(ValidationRule.question_id == q.id)).scalar_one()
        hints = db.execute(select(Hint).where(Hint.question_id == q.id).order_by(Hint.level)).scalars().all()
        pre = db.execute(select(QuestionPrerequisite).where(QuestionPrerequisite.question_id == q.id)).scalars().all()
        out.append({"key": q.key, "position": q.position, "stage": q.stage, "title": q.title, "narrative": q.narrative,
                    "task": q.task, "concept_notes": q.concept_notes, "explanation": q.explanation, "score": q.score,
                    "is_final": q.is_final, "validation": rule.spec, "hints": [h.text for h in hints],
                    "prerequisites": [by_id[p.requires_question_id].key for p in pre]})
    flags = db.execute(select(Flag).where(Flag.scenario_id == sc.id)).scalars().all()
    lab = sc.lab_template
    return {"scenario": {"id": sc.id, "slug": sc.slug, "title": sc.title, "story": sc.story,
                         "track_title": sc.track.title, "track_slug": sc.track.slug},
            "lab": {"template_key": lab.key, "enabled_commands": sc.enabled_commands},
            "policy": sc.completion_policy,
            "questions": out,
            "flags": [{"key": f.key, "label": f.label, "is_final": f.is_final} for f in flags]}


def publish(db: Session, sc: Scenario, actor) -> ScenarioVersion:
    snap = build_snapshot(db, sc)
    qs = snap["questions"]
    if not qs or not qs[-1]["is_final"]:
        raise DefinitionError("cannot publish: the last question must be the final objective")
    evaluate_policy(snap["policy"], [q["key"] for q in qs[:-1]], set())
    digest = hashlib.sha256(json.dumps(snap, sort_keys=True).encode()).hexdigest()
    latest = db.execute(select(ScenarioVersion).where(ScenarioVersion.scenario_id == sc.id)
                        .order_by(ScenarioVersion.version.desc()).limit(1)).scalar_one_or_none()
    if latest and latest.content_hash == digest:
        ver = latest  # nothing changed - reuse
    else:
        ver = ScenarioVersion(scenario_id=sc.id, version=(latest.version + 1) if latest else 1, snapshot=snap,
                              content_hash=digest, created_by=getattr(actor, "id", None), created_at=utcnow())
        db.add(ver)
        db.flush()
    sc.published_version_id = ver.id
    sc.status = "published"
    audit(db, "scenario.publish", actor=actor, entity_type="scenario", entity_id=sc.id, detail={"version": ver.version})
    return ver


def get_version(db: Session, version_id: str) -> ScenarioVersion:
    return db.get(ScenarioVersion, version_id)


def public_preview(db: Session, sc: Scenario) -> dict:
    """What an unpaid visitor may see. Deliberately excludes story, questions, hints, validation."""
    return {"id": sc.id, "slug": sc.slug, "title": sc.title, "description": sc.public_description,
            "objectives": sc.objectives, "difficulty": sc.difficulty, "duration_minutes": sc.duration_minutes,
            "eligibility": sc.eligibility_text, "question_count": db.scalar(select(func.count()).select_from(Question).where(Question.scenario_id == sc.id)),
            "track": {"slug": sc.track.slug, "title": sc.track.title}}
