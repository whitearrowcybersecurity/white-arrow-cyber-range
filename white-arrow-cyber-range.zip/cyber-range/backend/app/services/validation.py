"""Server-side answer / state validation. Nothing here is ever serialised to students."""
import hashlib
import hmac
import re

from ..config import settings
from ..terminal.labs import night_watch_remediated


def derive_flag(lab_session_id: str, scenario_id: str, flag_key: str) -> str:
    """Per-lab-session flag: unique to the student's session, so flags cannot be shared or replayed."""
    mac = hmac.new(settings.flag_key.encode(), f"{lab_session_id}:{scenario_id}:{flag_key}".encode(), hashlib.sha256)
    return "WA{" + mac.hexdigest()[:24] + "}"


def flag_matches(submitted: str, expected: str) -> bool:
    return hmac.compare_digest(submitted.strip().encode(), expected.encode())


def flag_digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()[:16]


def norm(value: str, kind: str = "text") -> str:
    v = (value or "").strip().strip("`'\"").strip()
    v = re.sub(r"\s+", " ", v).lower()
    if kind == "path":
        v = v.rstrip("/") or "/"
    elif kind == "int":
        m = re.fullmatch(r"0*(\d+)", v)
        v = m.group(1) if m else v
    return v


def _mode(state, path):
    n = state["fs"].get(path)
    return None if n is None else n["m"] & 0o7777


def eval_condition(state: dict, c: dict) -> bool:
    op, path = c["op"], c.get("path", "")
    node = state["fs"].get(path)
    if op == "exists":
        return node is not None
    if node is None:
        return False
    if op in ("mode_eq", "mode_none", "mode_all"):
        mode = node["m"] & 0o7777
        mask = int(c.get("mask", c.get("value", "0")), 8)
        if op == "mode_eq":
            return mode == mask
        if op == "mode_none":
            return mode & mask == 0
        return mode & mask == mask
    if op == "file_has":
        return c["text"] in node.get("c", "")
    if op == "file_lacks":
        return c["text"] not in node.get("c", "")
    if op == "owner_is":
        return node["o"] == c["value"]
    raise ValueError(f"unknown condition op {op}")


def _custom_fixes_complete(state, log, answer):
    return night_watch_remediated(state)


CUSTOM = {"night_watch_remediated": _custom_fixes_complete}


def validate(rule: dict, *, answer: str = "", state: dict, log: list[dict]) -> bool:
    """log entries: {"command": str, "output": str, "exit_code": int}"""
    t = rule["type"]
    if t == "answer":
        kind = rule.get("normalize", "text")
        ok = norm(answer, kind) in {norm(a, kind) for a in rule["accepted"]}
        if ok and rule.get("and_state"):
            ok = all(eval_condition(state, c) for c in rule["and_state"])
        return ok
    if t == "state":
        return all(eval_condition(state, c) for c in rule["all"])
    if t == "command":
        rx = re.compile(rule["pattern"])
        return any(rx.fullmatch(e["command"].strip()) for e in log)
    if t == "command_output":
        rx = re.compile(rule["command_pattern"])
        return any(rx.search(e["command"]) and rule["output_contains"] in e["output"] for e in log)
    if t == "custom":
        return bool(CUSTOM[rule["name"]](state, log, answer))
    raise ValueError(f"unsupported validation type {t}")
