"""Simulated Linux shell.

This is an *interpreter over an in-memory model* (users, groups, files, modes, processes,
sockets, units). Nothing here ever touches the host OS: no subprocess, no os.* file calls,
no eval. Commands are Python methods named c_<name> that read/modify a JSON-serialisable
state dict, so lab state is persisted per student and can be validated server-side.
"""
from __future__ import annotations

import fnmatch
import math
import posixpath
import re
import shlex

MAX_OUT = 20000
MAX_CMD = 500
MAX_FILE = 10000
MAX_NODES = 600
FIXED_DATE = "Oct 14 09:30"

# where "installed" binaries live (used for sudo rules and absolute-path invocation)
COMMAND_PATHS = {
    "ls": "/bin/ls", "cat": "/bin/cat", "chmod": "/bin/chmod", "chown": "/bin/chown",
    "grep": "/bin/grep", "find": "/usr/bin/find", "sed": "/usr/bin/sed", "head": "/usr/bin/head",
    "tail": "/usr/bin/tail", "wc": "/usr/bin/wc", "sort": "/usr/bin/sort", "uniq": "/usr/bin/uniq",
    "cut": "/usr/bin/cut", "id": "/usr/bin/id", "whoami": "/usr/bin/whoami", "ps": "/bin/ps",
    "ss": "/usr/bin/ss", "systemctl": "/bin/systemctl", "stat": "/usr/bin/stat",
    "echo": "/bin/echo", "pwd": "/bin/pwd", "uname": "/bin/uname", "hostname": "/bin/hostname",
}

ALL_COMMANDS = ["pwd", "ls", "cd", "cat", "head", "tail", "wc", "grep", "find", "sort", "uniq", "cut",
                "id", "whoami", "hostname", "uname", "date", "ps", "ss", "systemctl", "stat",
                "chmod", "chown", "sed", "sudo", "echo", "crontab", "clear", "help"]

_OPS = {"|", "||", "&&", ";", ">", ">>", "&", "<", "(", ")", ";;", "&>", ">&"}
_ERR_NULL = "__ERRNULL__"
_ERR_OUT = "__ERR2OUT__"


class Lab:
    def __init__(self, state: dict, enabled: list[str] | None = None, hook=None, ctx: dict | None = None):
        self.s = state
        self.enabled = set(enabled) if enabled else None
        self.hook = hook
        self.ctx = ctx or {}
        self.euser = state["user"]

    # ------------------------------------------------------------------ public
    def prompt(self) -> str:
        user = self.s["user"]
        home = self.s["users"][user]["home"]
        cwd = self.s["cwd"]
        shown = "~" + cwd[len(home):] if cwd == home or cwd.startswith(home + "/") else cwd
        sym = "#" if user == "root" else "$"
        return f"{user}@{self.s['host']}:{shown}{sym} "

    def run(self, line: str) -> tuple[str, int]:
        line = line.strip()
        if len(line) > MAX_CMD:
            return "bash: command too long", 1
        if not line:
            return "", 0
        try:
            toks = self._tokenize(line)
            lists = self._split_lists(toks)
        except ValueError as e:
            return f"bash: syntax error: {e}", 2
        outs, code = [], 0
        for op, seg in lists:
            if op == "&&" and code != 0:
                continue
            if op == "||" and code == 0:
                continue
            text, code = self._run_pipeline(seg)
            if text:
                outs.append(text)
        text = "\n".join(outs)
        if len(text) > MAX_OUT:
            text = text[:MAX_OUT] + "\n[output truncated]"
        self.euser = self.s["user"]
        if self.hook:
            self.hook(self)
        return text, code

    # ------------------------------------------------------------------ parsing
    def _tokenize(self, line: str) -> list[str]:
        line = re.sub(r"2>\s*/dev/null", f" {_ERR_NULL} ", line)
        line = line.replace("2>&1", f" {_ERR_OUT} ")
        lex = shlex.shlex(line, posix=True, punctuation_chars=True)
        lex.whitespace_split = True
        lex.commenters = ""
        toks = list(lex)
        for t in toks:
            if t in ("(", ")", "<", "&", "&>", ">&", ";;"):
                raise ValueError(f"unsupported token '{t}'")
        return toks

    def _split_lists(self, toks):
        lists, cur, op = [], [], None
        for t in toks:
            if t in (";", "&&", "||"):
                if not cur:
                    raise ValueError(f"unexpected token '{t}'")
                lists.append((op, cur))
                cur, op = [], (None if t == ";" else t)
            else:
                cur.append(t)
        if cur:
            lists.append((op, cur))
        return lists

    def _run_pipeline(self, toks):
        stages, cur = [], []
        for t in toks:
            if t == "|":
                if not cur:
                    return "bash: syntax error near unexpected token '|'", 2
                stages.append(cur)
                cur = []
            else:
                cur.append(t)
        if not cur:
            return "bash: syntax error: unexpected end of line", 2
        stages.append(cur)
        stdin, errs, code, final_out = "", [], 0, ""
        for i, stage in enumerate(stages):
            args, redir, err_mode = [], None, None
            j = 0
            while j < len(stage):
                t = stage[j]
                if t in (">", ">>"):
                    if j + 1 >= len(stage):
                        return "bash: syntax error near unexpected token `newline'", 2
                    redir = (t, stage[j + 1])
                    j += 2
                    continue
                if t == _ERR_NULL:
                    err_mode = "null"
                elif t == _ERR_OUT:
                    err_mode = "out"
                else:
                    args.append(t)
                j += 1
            if not args:
                return "bash: syntax error: missing command", 2
            out, err, code = self._exec(args[0], [self._expand(a) for a in args[1:]], stdin)
            if err_mode == "out":
                out, err = (err + out if err else out), ""
            if err and err_mode != "null":
                errs.append(err)
            if i == len(stages) - 1 and redir:
                werr = self._redirect_write(redir[0], self._expand(redir[1]), out)
                if werr:
                    errs.append(werr)
                    code = 1
                out = ""
            stdin = out
            final_out = out
        parts = []
        if errs:
            parts.append("\n".join(e.rstrip("\n") for e in errs))
        if final_out:
            parts.append(final_out.rstrip("\n"))
        return "\n".join(parts), code

    def _expand(self, a: str) -> str:
        home = self.s["users"][self.euser]["home"]
        if a == "~":
            return home
        if a.startswith("~/"):
            a = home + a[1:]
        a = a.replace("${USER}", self.euser).replace("$USER", self.euser)
        a = a.replace("${HOME}", home).replace("$HOME", home)
        a = a.replace("${PWD}", self.s["cwd"]).replace("$PWD", self.s["cwd"])
        a = a.replace("$HOSTNAME", self.s["host"])
        return a

    # ------------------------------------------------------------------ fs helpers
    @property
    def fs(self) -> dict:
        return self.s["fs"]

    def abspath(self, p: str) -> str:
        if not p.startswith("/"):
            p = posixpath.join(self.s["cwd"], p)
        return posixpath.normpath(p) if p != "/" else "/"

    def _groups(self, user: str) -> set:
        u = self.s["users"].get(user)
        return set(u["groups"]) if u else set()

    def _allowed(self, node: dict, bit: int, user: str | None = None) -> bool:
        user = user or self.euser
        if user == "root":
            return bit != 1 or node["t"] == "d" or bool(node["m"] & 0o111)
        m = node["m"]
        if node["o"] == user:
            sh = 6
        elif node["g"] in self._groups(user):
            sh = 3
        else:
            sh = 0
        return bool((m >> sh) & bit)

    def _traverse_error(self, path: str) -> str | None:
        """Every ancestor directory needs search (x) permission."""
        if path == "/":
            return None
        parts = path.strip("/").split("/")
        cur = ""
        for part in parts[:-1]:
            cur = cur + "/" + part
            n = self.fs.get(cur)
            if n is None or n["t"] != "d":
                return "No such file or directory"
            if not self._allowed(n, 1):
                return "Permission denied"
        return None

    def lookup(self, path: str):
        """-> (node, error)"""
        path = self.abspath(path)
        err = self._traverse_error(path)
        if err:
            return None, err
        n = self.fs.get(path)
        if n is None:
            return None, "No such file or directory"
        return n, None

    def children(self, path: str) -> list[str]:
        prefix = "/" if path == "/" else path + "/"
        out = []
        for k in self.fs:
            if k != "/" and k.startswith(prefix) and "/" not in k[len(prefix):]:
                out.append(k)
        return sorted(out, key=lambda k: (posixpath.basename(k).lstrip(".").lower(), k))

    def _glob(self, arg: str) -> list[str]:
        if not any(c in arg for c in "*?["):
            return [arg]
        d, base = posixpath.split(arg)
        if any(c in d for c in "*?["):
            return [arg]
        dpath = self.abspath(d or ".")
        node, err = self.lookup(dpath)
        if err or node["t"] != "d" or not self._allowed(node, 4):
            return [arg]
        hits = [posixpath.join(d, posixpath.basename(k)) if d else posixpath.basename(k)
                for k in self.children(dpath)
                if fnmatch.fnmatchcase(posixpath.basename(k), base)
                and (base.startswith(".") or not posixpath.basename(k).startswith("."))]
        return hits or [arg]

    def _globs(self, args: list[str]) -> list[str]:
        out = []
        for a in args:
            out.extend(self._glob(a))
        return out

    def _read(self, path: str, who: str):
        """-> (content, err). err is a bare message such as 'Permission denied'."""
        n, err = self.lookup(path)
        if err:
            return None, err
        if n["t"] == "d":
            return None, "Is a directory"
        if not self._allowed(n, 4):
            return None, "Permission denied"
        return n.get("c", ""), None

    def _modestr(self, n: dict) -> str:
        m = n["m"]
        t = "d" if n["t"] == "d" else "-"
        s = ""
        for who, sh in (("u", 6), ("g", 3), ("o", 0)):
            r = "r" if (m >> sh) & 4 else "-"
            w = "w" if (m >> sh) & 2 else "-"
            x = "x" if (m >> sh) & 1 else "-"
            if who == "u" and m & 0o4000:
                x = "s" if x == "x" else "S"
            if who == "g" and m & 0o2000:
                x = "s" if x == "x" else "S"
            if who == "o" and m & 0o1000:
                x = "t" if x == "x" else "T"
            s += r + w + x
        return t + s

    def _size(self, n: dict) -> int:
        return 4096 if n["t"] == "d" else len(n.get("c", ""))

    def _redirect_write(self, mode: str, target: str, data: str) -> str | None:
        if target == "/dev/null":
            return None
        path = self.abspath(target)
        n, err = self.lookup(path)
        if err == "Permission denied":
            return f"bash: {target}: Permission denied"
        if n is None:
            parent, perr = self.lookup(posixpath.dirname(path) or "/")
            if perr or parent["t"] != "d":
                return f"bash: {target}: No such file or directory"
            if not (self._allowed(parent, 2) and self._allowed(parent, 1)):
                return f"bash: {target}: Permission denied"
            if len(self.fs) >= MAX_NODES:
                return f"bash: {target}: No space left on device"
            n = {"t": "f", "m": 0o644, "o": self.euser, "g": self.s["users"][self.euser]["groups"][0], "c": ""}
            self.fs[path] = n
        elif n["t"] == "d":
            return f"bash: {target}: Is a directory"
        elif not self._allowed(n, 2):
            return f"bash: {target}: Permission denied"
        new = (n["c"] if mode == ">>" else "") + data + ("\n" if data and not data.endswith("\n") else "")
        n["c"] = new[:MAX_FILE]
        return None

    # ------------------------------------------------------------------ exec
    def _exec(self, name: str, args: list[str], stdin: str):
        raw = name
        if "/" in name:
            base = posixpath.basename(name)
            if COMMAND_PATHS.get(base) == self.abspath(name):
                name = base
            else:
                n, err = self.lookup(name)
                if err:
                    return "", f"bash: {raw}: {err}", 126 if err == "Permission denied" else 127
                if n["t"] == "d":
                    return "", f"bash: {raw}: Is a directory", 126
                if not self._allowed(n, 1):
                    return "", f"bash: {raw}: Permission denied", 126
                return "", f"bash: {raw}: script execution is disabled in this simulated lab", 126
        fn = getattr(self, "c_" + name, None) if re.fullmatch(r"[a-z]+", name) else None
        allowed = name == "help" or self.enabled is None or name in self.enabled
        if fn is None or not allowed:
            return "", f"bash: {raw}: command not found", 127
        return fn(args, stdin)

    # ------------------------------------------------------------------ commands
    def c_help(self, a, stdin):
        cmds = sorted(self.enabled | {"help"}) if self.enabled else sorted(ALL_COMMANDS)
        return ("Simulated lab shell. Available commands:\n  " + " ".join(cmds) +
                "\nPipes (|), redirection (> >>), ; and && are supported. Nothing here touches a real system.\n"), "", 0

    def c_clear(self, a, stdin):
        return "\x1b[2J\x1b[H", "", 0

    def c_pwd(self, a, stdin):
        return self.s["cwd"] + "\n", "", 0

    def c_whoami(self, a, stdin):
        return self.euser + "\n", "", 0

    def c_hostname(self, a, stdin):
        return self.s["host"] + "\n", "", 0

    def c_uname(self, a, stdin):
        flags = "".join(x.lstrip("-") for x in a)
        if "a" in flags:
            return f"Linux {self.s['host']} 5.15.0-91-generic #101-Ubuntu SMP x86_64 GNU/Linux\n", "", 0
        if "r" in flags:
            return "5.15.0-91-generic\n", "", 0
        return "Linux\n", "", 0

    def c_date(self, a, stdin):
        return "Mon Oct 14 09:30:00 UTC 2024\n", "", 0

    def c_echo(self, a, stdin):
        nl = True
        if a and a[0] == "-n":
            nl, a = False, a[1:]
        return " ".join(a) + ("\n" if nl else ""), "", 0

    def c_id(self, a, stdin):
        user = a[0] if a else self.euser
        u = self.s["users"].get(user)
        if not u:
            return "", f"id: ‘{user}’: no such user", 1
        gids = self.s["groups"]
        groups = ",".join(f"{gids[g]}({g})" for g in u["groups"])
        primary = u["groups"][0]
        return f"uid={u['uid']}({user}) gid={gids[primary]}({primary}) groups={groups}\n", "", 0

    def c_cd(self, a, stdin):
        target = a[0] if a else self.s["users"][self.euser]["home"]
        n, err = self.lookup(target)
        if err:
            return "", f"bash: cd: {target}: {err}", 1
        if n["t"] != "d":
            return "", f"bash: cd: {target}: Not a directory", 1
        if not self._allowed(n, 1):
            return "", f"bash: cd: {target}: Permission denied", 1
        self.s["cwd"] = self.abspath(target)
        return "", "", 0

    def c_ls(self, a, stdin):
        flags, paths = "", []
        for x in a:
            if x.startswith("-") and len(x) > 1:
                flags += x[1:]
            else:
                paths.append(x)
        show_all, longf = "a" in flags, "l" in flags
        almost = "A" in flags
        paths = self._globs(paths) or ["."]
        out, errs, code = [], [], 0
        files = [p for p in paths if (self.lookup(p)[0] or {}).get("t") != "d"]
        dirs = [p for p in paths if (self.lookup(p)[0] or {}).get("t") == "d"]
        lines = []
        for p in files:
            n, err = self.lookup(p)
            if err:
                errs.append(f"ls: cannot access '{p}': {err}")
                code = 2
            else:
                lines.append(self._ls_line(p, n, longf))
        if lines:
            out.append("\n".join(lines) if longf else "  ".join(lines))
        for idx, p in enumerate(dirs):
            n, _ = self.lookup(p)
            if not self._allowed(n, 4):
                errs.append(f"ls: cannot open directory '{p}': Permission denied")
                code = 2
                continue
            ap = self.abspath(p)
            kids = self.children(ap)
            entries = []
            if show_all and not almost:
                entries.append(("." , n))
                entries.append((".." , self.fs.get(posixpath.dirname(ap) or "/", n)))
            for k in kids:
                b = posixpath.basename(k)
                if b.startswith(".") and not (show_all or almost):
                    continue
                entries.append((b, self.fs[k]))
            body = []
            if longf:
                total = sum(max(4, math.ceil(self._size(nd) / 4096) * 4) for _, nd in entries)
                body.append(f"total {total}")
                body += [self._ls_line(nm, nd, True) for nm, nd in entries]
            else:
                body = ["  ".join(nm for nm, _ in entries)] if entries else []
            head = f"{p}:\n" if len(paths) > 1 else ""
            out.append(head + "\n".join(body))
        return ("\n".join(o for o in out if o != "") + "\n" if out else ""), "\n".join(errs), code

    def _ls_line(self, name, n, longf):
        if not longf:
            return name
        links = 2 if n["t"] == "d" else 1
        return f"{self._modestr(n)} {links} {n['o']:<8} {n['g']:<8} {self._size(n):>6} {n.get('mt', FIXED_DATE)} {name}"

    def c_stat(self, a, stdin):
        out, errs, code = [], [], 0
        for p in self._globs(a):
            n, err = self.lookup(p)
            if err:
                errs.append(f"stat: cannot statx '{p}': {err}")
                code = 1
                continue
            uid = self.s["users"].get(n["o"], {}).get("uid", 0)
            gid = self.s["groups"].get(n["g"], 0)
            kind = "directory" if n["t"] == "d" else "regular file"
            out.append(f"  File: {p}\n  Size: {self._size(n)}\t{kind}\n"
                       f"Access: ({n['m'] & 0o7777:04o}/{self._modestr(n)})  Uid: ({uid:>5}/{n['o']:>8})   Gid: ({gid:>5}/{n['g']:>8})")
        return "\n".join(out) + ("\n" if out else ""), "\n".join(errs), code

    def c_cat(self, a, stdin):
        if not a:
            return stdin, "", 0
        out, errs, code = "", [], 0
        for p in self._globs(a):
            if p == "-":
                out += stdin
                continue
            c, err = self._read(p, self.euser)
            if err:
                errs.append(f"cat: {p}: {err}")
                code = 1
            else:
                out += c if c.endswith("\n") or not c else c + "\n"
        return out, "\n".join(errs), code

    def _text_inputs(self, a, stdin, cmd):
        """Shared by head/tail/wc/sort/uniq/cut: -> (list[(name,text)], errs)"""
        files = [x for x in a]
        if not files:
            return [(None, stdin)], []
        res, errs = [], []
        for p in self._globs(files):
            c, err = self._read(p, self.euser)
            if err:
                errs.append(f"{cmd}: {p}: {err}")
            else:
                res.append((p, c))
        return res, errs

    @staticmethod
    def _split_num_flag(a):
        n, rest, i = 10, [], 0
        while i < len(a):
            x = a[i]
            if x == "-n" and i + 1 < len(a) and a[i + 1].lstrip("+-").isdigit():
                n = int(a[i + 1])
                i += 2
                continue
            if re.fullmatch(r"-n\d+", x) or re.fullmatch(r"-\d+", x):
                n = int(x.lstrip("-n"))
            else:
                rest.append(x)
            i += 1
        return n, rest

    def c_head(self, a, stdin):
        n, rest = self._split_num_flag(a)
        inputs, errs = self._text_inputs(rest, stdin, "head")
        out = ""
        for name, text in inputs:
            if name and len(inputs) > 1:
                out += f"==> {name} <==\n"
            out += "".join(text.splitlines(True)[:n])
        return out, "\n".join(errs), 1 if errs else 0

    def c_tail(self, a, stdin):
        n, rest = self._split_num_flag(a)
        inputs, errs = self._text_inputs(rest, stdin, "tail")
        out = ""
        for name, text in inputs:
            if name and len(inputs) > 1:
                out += f"==> {name} <==\n"
            lines = text.splitlines(True)
            out += "".join(lines[-n:] if n else [])
        return out, "\n".join(errs), 1 if errs else 0

    def c_wc(self, a, stdin):
        flags = "".join(x[1:] for x in a if x.startswith("-") and len(x) > 1)
        files = [x for x in a if not (x.startswith("-") and len(x) > 1)]
        inputs, errs = self._text_inputs(files, stdin, "wc")
        out = ""
        for name, text in inputs:
            vals = {"l": text.count("\n"), "w": len(text.split()), "c": len(text.encode())}
            sel = [k for k in "lwc" if k in flags] or ["l", "w", "c"]
            out += " ".join(str(vals[k]) for k in sel) + (f" {name}" if name else "") + "\n"
        return out, "\n".join(errs), 1 if errs else 0

    def c_sort(self, a, stdin):
        flags = "".join(x[1:] for x in a if x.startswith("-") and len(x) > 1)
        files = [x for x in a if not (x.startswith("-") and len(x) > 1)]
        inputs, errs = self._text_inputs(files, stdin, "sort")
        lines = [ln for _, t in inputs for ln in t.splitlines()]
        if "n" in flags:
            def key(s):
                m = re.match(r"\s*(-?\d+(\.\d+)?)", s)
                return float(m.group(1)) if m else 0.0
            lines.sort(key=key)
        else:
            lines.sort()
        if "r" in flags:
            lines.reverse()
        if "u" in flags:
            seen, uniq = set(), []
            for ln in lines:
                if ln not in seen:
                    seen.add(ln)
                    uniq.append(ln)
            lines = uniq
        return "".join(ln + "\n" for ln in lines), "\n".join(errs), 1 if errs else 0

    def c_uniq(self, a, stdin):
        count = "-c" in a
        files = [x for x in a if not x.startswith("-")]
        inputs, errs = self._text_inputs(files, stdin, "uniq")
        out, prev, n = [], None, 0
        for ln in [l for _, t in inputs for l in t.splitlines()]:
            if ln == prev:
                n += 1
            else:
                if prev is not None:
                    out.append((n, prev))
                prev, n = ln, 1
        if prev is not None:
            out.append((n, prev))
        text = "".join((f"{c:>7} {ln}\n" if count else f"{ln}\n") for c, ln in out)
        return text, "\n".join(errs), 1 if errs else 0

    def c_cut(self, a, stdin):
        delim, fields, chars, files, i = "\t", None, None, [], 0
        while i < len(a):
            x = a[i]
            if x == "-d" and i + 1 < len(a):
                delim, i = a[i + 1], i + 2
                continue
            if x.startswith("-d") and len(x) > 2:
                delim = x[2:]
            elif x == "-f" and i + 1 < len(a):
                fields, i = a[i + 1], i + 2
                continue
            elif x.startswith("-f"):
                fields = x[2:]
            elif x.startswith("-c"):
                chars = x[2:] or (a[i + 1] if i + 1 < len(a) else "")
                if not x[2:]:
                    i += 1
            else:
                files.append(x)
            i += 1
        spec = fields or chars
        if not spec:
            return "", "cut: you must specify a list of bytes, characters, or fields", 1

        def idxs(spec, n):
            res = []
            for part in spec.split(","):
                if "-" in part:
                    lo, hi = part.split("-", 1)
                    lo = int(lo) if lo else 1
                    hi = int(hi) if hi else n
                    res.extend(range(lo, hi + 1))
                elif part.isdigit():
                    res.append(int(part))
            return res
        inputs, errs = self._text_inputs(files, stdin, "cut")
        out = ""
        for ln in [l for _, t in inputs for l in t.splitlines()]:
            if fields:
                parts = ln.split(delim)
                out += delim.join(parts[i - 1] for i in idxs(fields, len(parts)) if 0 < i <= len(parts)) + "\n"
            else:
                out += "".join(ln[i - 1] for i in idxs(chars, len(ln)) if 0 < i <= len(ln)) + "\n"
        return out, "\n".join(errs), 1 if errs else 0

    def c_grep(self, a, stdin):
        opts, pats, rest, i = set(), [], [], 0
        while i < len(a):
            x = a[i]
            if x == "-e" and i + 1 < len(a):
                pats.append(a[i + 1])
                i += 2
                continue
            if x.startswith("-") and len(x) > 1 and not rest and not (pats == [] and x == "-"):
                opts.update(x[1:])
            else:
                rest.append(x)
            i += 1
        if not pats:
            if not rest:
                return "", "Usage: grep [OPTION]... PATTERNS [FILE]...", 2
            pats, rest = [rest[0]], rest[1:]
        flags = re.I if "i" in opts else 0
        try:
            regs = [re.compile(re.escape(p) if "F" in opts else p, flags) for p in pats]
        except re.error:
            return "", "grep: Invalid regular expression", 2
        recursive = "r" in opts or "R" in opts
        targets = []  # (display_name, text)
        errs = []
        files = self._globs(rest)
        if not files:
            targets.append((None, stdin)) if not recursive else files.append(".")
        for p in files:
            n, err = self.lookup(p)
            if err:
                errs.append(f"grep: {p}: {err}")
                continue
            if n["t"] == "d":
                if not recursive:
                    errs.append(f"grep: {p}: Is a directory")
                    continue
                base = self.abspath(p)
                for k in sorted(self.fs):
                    if k.startswith(base.rstrip("/") + "/") and self.fs[k]["t"] == "f":
                        c, e = self._read(k, self.euser)
                        if e:
                            errs.append(f"grep: {k}: {e}")
                        else:
                            targets.append((k if p.startswith("/") else posixpath.relpath(k, self.s["cwd"]), c))
            else:
                c, e = self._read(p, self.euser)
                if e:
                    errs.append(f"grep: {p}: {e}")
                else:
                    targets.append((p, c))
        multi = len(targets) > 1 or recursive
        out, matched_any = [], False
        for name, text in targets:
            cnt = 0
            for no, ln in enumerate(text.splitlines(), 1):
                hit = any(r.search(ln) for r in regs)
                if "v" in opts:
                    hit = not hit
                if not hit:
                    continue
                cnt += 1
                matched_any = True
                if "c" in opts or "l" in opts:
                    continue
                pre = (f"{name}:" if multi and name else "") + (f"{no}:" if "n" in opts else "")
                if "o" in opts and "v" not in opts:
                    for r in regs:
                        for m in r.finditer(ln):
                            out.append(pre + m.group(0))
                else:
                    out.append(pre + ln)
            if "c" in opts:
                out.append((f"{name}:" if multi and name else "") + str(cnt))
            elif "l" in opts and cnt:
                out.append(name or "(standard input)")
        code = 0 if matched_any or ("c" in opts and not errs) else 1
        if errs and not matched_any:
            code = 2
        return "".join(l + "\n" for l in out), "\n".join(errs), code

    def c_find(self, a, stdin):
        roots, preds, i = [], {}, 0
        while i < len(a) and not a[i].startswith("-"):
            roots.append(a[i])
            i += 1
        roots = roots or ["."]
        while i < len(a):
            k = a[i]
            v = a[i + 1] if i + 1 < len(a) else None
            if k in ("-name", "-iname", "-type", "-perm", "-user", "-group", "-maxdepth", "-mindepth") and v is not None:
                preds[k] = v
                i += 2
            elif k in ("-print",):
                i += 1
            else:
                return "", f"find: unknown predicate `{k}'", 1
        try:
            maxd = int(preds["-maxdepth"]) if "-maxdepth" in preds else 99
            mind = int(preds["-mindepth"]) if "-mindepth" in preds else 0
        except ValueError:
            return "", "find: invalid depth", 1
        perm = preds.get("-perm")
        pmode = pkind = None
        if perm:
            pkind = "exact"
            if perm.startswith("-"):
                pkind, perm = "all", perm[1:]
            elif perm.startswith("/"):
                pkind, perm = "any", perm[1:]
            try:
                pmode = int(perm, 8)
            except ValueError:
                return "", f"find: invalid mode ‘{preds['-perm']}’", 1

        def matches(path, n):
            base = posixpath.basename(path) or "/"
            if "-name" in preds and not fnmatch.fnmatchcase(base, preds["-name"]):
                return False
            if "-iname" in preds and not fnmatch.fnmatchcase(base.lower(), preds["-iname"].lower()):
                return False
            if "-type" in preds and {"f": "f", "d": "d"}.get(preds["-type"]) != n["t"]:
                return False
            if "-user" in preds and n["o"] != preds["-user"]:
                return False
            if "-group" in preds and n["g"] != preds["-group"]:
                return False
            if pmode is not None:
                m = n["m"] & 0o7777
                if pkind == "exact" and m != pmode:
                    return False
                if pkind == "all" and (m & pmode) != pmode:
                    return False
                if pkind == "any" and not (m & pmode):
                    return False
            return True

        out, errs, code = [], [], 0
        for r in roots:
            n, err = self.lookup(r)
            if err:
                errs.append(f"find: ‘{r}’: {err}")
                code = 1
                continue
            base = self.abspath(r)
            shown_root = r
            blocked = []
            cand = [base] + sorted((k for k in self.fs if k != base and k.startswith(base.rstrip("/") + "/")),
                                   key=lambda p: p.split("/"))
            for path in cand:
                if any(path.startswith(b + "/") for b in blocked):
                    continue
                node = self.fs[path]
                depth = 0 if path == base else path[len(base.rstrip("/")):].count("/")
                if depth > maxd:
                    continue
                disp = shown_root if path == base else shown_root.rstrip("/") + path[len(base.rstrip("/")):]
                if depth >= mind and matches(path, node):
                    out.append(disp)
                if node["t"] == "d" and not (self._allowed(node, 4) and self._allowed(node, 1)) and path != base:
                    errs.append(f"find: ‘{disp}’: Permission denied")
                    code = 1
                    blocked.append(path)
        return "".join(o + "\n" for o in out), "\n".join(errs), code

    def c_ps(self, a, stdin):
        flags = "".join(x.lstrip("-") for x in a)
        procs = self.s["procs"]
        if not flags:
            mine = [p for p in procs if p["user"] == self.euser and p.get("tty")]
            lines = ["    PID TTY          TIME CMD"]
            lines += [f"{p['pid']:>7} {p['tty']:<8} 00:00:00 {p['cmd'].split()[0].split('/')[-1]}" for p in mine]
            return "\n".join(lines) + "\n", "", 0
        if "e" in flags and "f" in flags:
            lines = ["UID          PID    PPID  C STIME TTY          TIME CMD"]
            lines += [f"{p['user'][:8]:<8} {p['pid']:>7} {p.get('ppid', 1):>7}  0 08:00 {p.get('tty', '?'):<8} 00:00:00 {p['cmd']}" for p in procs]
            return "\n".join(lines) + "\n", "", 0
        lines = ["USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND"]
        lines += [f"{p['user'][:12]:<12} {p['pid']:>5} {p.get('cpu', 0.0):>4} {p.get('mem', 0.1):>4} {p.get('vsz', 10000):>6} {p.get('rss', 2000):>5} "
                  f"{p.get('tty', '?'):<8} Ss   08:00   0:00 {p['cmd']}" for p in procs]
        return "\n".join(lines) + "\n", "", 0

    def c_ss(self, a, stdin):
        flags = "".join(x.lstrip("-") for x in a)
        hdr = "Netid State  Recv-Q Send-Q  Local Address:Port   Peer Address:Port Process"
        lines = self.s["sockets"]["listen"] if "l" in flags else self.s["sockets"]["established"]
        return "\n".join([hdr] + lines) + "\n", "", 0

    def c_systemctl(self, a, stdin):
        units = self.s["units"]
        args = [x for x in a if not x.startswith("--no-")]
        if not args:
            args = ["list-units"]
        sub = args[0]
        if sub in ("list-units", "--failed"):
            state = None
            for x in args:
                if x.startswith("--state="):
                    state = x.split("=", 1)[1]
                if x == "--failed" or sub == "--failed":
                    state = "failed"
            rows = [u for u in units if state is None or u["active"] == state]
            lines = ["  UNIT                 LOAD   ACTIVE SUB     DESCRIPTION"]
            lines += [f"{'● ' if u['active'] == 'failed' else '  '}{u['name']:<20} {u['load']:<6} {u['active']:<6} {u['sub']:<7} {u['desc']}" for u in rows]
            lines.append(f"\n{len(rows)} loaded units listed.")
            return "\n".join(lines) + "\n", "", 0
        if sub in ("status", "is-active") and len(args) > 1:
            nm = args[1] if args[1].endswith(".service") else args[1] + ".service"
            u = next((x for x in units if x["name"] == nm), None)
            if not u:
                return "", f"Unit {nm} could not be found.", 4
            if sub == "is-active":
                return u["active"] + "\n", "", 0 if u["active"] == "active" else 3
            return (f"● {u['name']} - {u['desc']}\n     Loaded: {u['load']}\n"
                    f"     Active: {u['active']} ({u['sub']})\n"), "", 0 if u["active"] == "active" else 3
        return "", "systemctl: this simulated lab only supports status, is-active and list-units", 1

    def c_crontab(self, a, stdin):
        if "-l" in a:
            return "", f"no crontab for {self.euser}", 1
        return "", "crontab: usage: crontab -l", 1

    # ---- mutating commands
    def c_chmod(self, a, stdin):
        recursive = False
        args = []
        for x in a:
            if x in ("-R", "-r") and not args:
                recursive = True
            else:
                args.append(x)
        if len(args) < 2:
            return "", "chmod: missing operand", 1
        mode, paths = args[0], self._globs(args[1:])
        errs, code = [], 0
        for p in paths:
            n, err = self.lookup(p)
            if err:
                errs.append(f"chmod: cannot access '{p}': {err}")
                code = 1
                continue
            targets = [n]
            if recursive and n["t"] == "d":
                base = self.abspath(p).rstrip("/") + "/"
                targets += [v for k, v in self.fs.items() if k.startswith(base)]
            for t in targets:
                if self.euser != "root" and t["o"] != self.euser:
                    errs.append(f"chmod: changing permissions of '{p}': Operation not permitted")
                    code = 1
                    break
                new = self._apply_mode(mode, t)
                if new is None:
                    return "", f"chmod: invalid mode: ‘{mode}’", 1
                t["m"] = new
        return "", "\n".join(errs), code

    def _apply_mode(self, spec: str, n: dict) -> int | None:
        cur = n["m"]
        if re.fullmatch(r"[0-7]{1,4}", spec):
            return int(spec, 8)
        for clause in spec.split(","):
            m = re.fullmatch(r"([ugoa]*)([-+=])([rwxXst]*)", clause)
            if not m:
                return None
            who, op, perms = m.groups()
            who = who or "a"
            if "a" in who:
                who = "ugo"
            bits = 0
            for w in who:
                sh = {"u": 6, "g": 3, "o": 0}[w]
                if "r" in perms:
                    bits |= 4 << sh
                if "w" in perms:
                    bits |= 2 << sh
                if "x" in perms or ("X" in perms and (n["t"] == "d" or cur & 0o111)):
                    bits |= 1 << sh
                if "s" in perms and w == "u":
                    bits |= 0o4000
                if "s" in perms and w == "g":
                    bits |= 0o2000
                if "t" in perms:
                    bits |= 0o1000
            if op == "+":
                cur |= bits
            elif op == "-":
                cur &= ~bits
            else:
                mask = 0
                for w in who:
                    mask |= 7 << {"u": 6, "g": 3, "o": 0}[w]
                cur = (cur & ~mask) | bits
        return cur & 0o7777

    def c_chown(self, a, stdin):
        if self.euser != "root":
            return "", "chown: changing ownership: Operation not permitted", 1
        if len(a) < 2:
            return "", "chown: missing operand", 1
        owner, _, group = a[0].partition(":")
        errs, code = [], 0
        for p in self._globs(a[1:]):
            n, err = self.lookup(p)
            if err:
                errs.append(f"chown: cannot access '{p}': {err}")
                code = 1
                continue
            if owner:
                if owner not in self.s["users"]:
                    return "", f"chown: invalid user: ‘{owner}’", 1
                n["o"] = owner
            if group:
                if group not in self.s["groups"]:
                    return "", f"chown: invalid group: ‘{group}’", 1
                n["g"] = group
        return "", "\n".join(errs), code

    def c_sed(self, a, stdin):
        inplace = quiet = False
        script, files = None, []
        for x in a:
            if x == "-i":
                inplace = True
            elif x == "-n":
                quiet = True
            elif script is None and not x.startswith("-"):
                script = x
            else:
                files.append(x)
        if script is None:
            return "", "Usage: sed [OPTION]... {script} [input-file]...", 1
        m = re.fullmatch(r"s(.)(.*?)(?<!\\)\1(.*?)(?<!\\)\1([gI]*)", script)
        if not m:
            return "", "sed: only s/regex/replacement/[g] is supported in this lab", 1
        _, pat, rep, fl = m.groups()
        try:
            rx = re.compile(pat, re.I if "I" in fl else 0)
        except re.error:
            return "", "sed: invalid regular expression", 1
        rep = re.sub(r"\\(\d)", r"\\g<\1>", rep.replace("&", r"\g<0>"))
        count = 0 if "g" in fl else 1

        def sub(text):
            return "".join(rx.sub(rep, ln, count=count) for ln in text.splitlines(True))
        if not files:
            return sub(stdin), "", 0
        out, errs, code = "", [], 0
        for p in self._globs(files):
            c, err = self._read(p, self.euser)
            if err:
                errs.append(f"sed: can't read {p}: {err}")
                code = 2
                continue
            new = sub(c)
            if inplace:
                n, _ = self.lookup(p)
                if not self._allowed(n, 2):
                    errs.append(f"sed: couldn't open temporary file {posixpath.dirname(self.abspath(p))}/sedXXXXXX: Permission denied")
                    code = 4
                    continue
                n["c"] = new[:MAX_FILE]
            elif not quiet:
                out += new
        return out, "\n".join(errs), code

    def c_sudo(self, a, stdin):
        user = self.s["user"]
        args = list(a)
        while args and args[0] in ("-n", "-S", "-E"):
            args.pop(0)
        rules = self.s.get("sudo", {}).get(user, [])
        if args and args[0] == "-l":
            if not rules:
                return "", f"Sorry, user {user} may not run sudo on {self.s['host']}.", 1
            listing = ", ".join(rules)
            return (f"Matching Defaults entries for {user} on {self.s['host']}:\n"
                    "    env_reset, mail_badpass, secure_path=/usr/local/sbin\\:/usr/local/bin\\:/usr/sbin\\:/usr/bin\\:/sbin\\:/bin\n\n"
                    f"User {user} may run the following commands on {self.s['host']}:\n"
                    f"    (root) NOPASSWD: {listing}\n"), "", 0
        if not args:
            return "", "usage: sudo -l | sudo command", 1
        cmd = args[0]
        path = COMMAND_PATHS.get(cmd, cmd)
        if self.euser == "root" or path in rules:
            prev, self.euser = self.euser, "root"
            try:
                return self._exec(cmd, [self._expand(x) for x in args[1:]], stdin)
            finally:
                self.euser = prev
        shown = " ".join([path] + args[1:])
        return "", f"Sorry, user {user} is not allowed to execute '{shown}' as root on {self.s['host']}.", 1
