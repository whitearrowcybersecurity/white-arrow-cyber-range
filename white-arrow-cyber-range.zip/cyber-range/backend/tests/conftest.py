import os
import tempfile

import pytest

# configure BEFORE importing the app
_tmp = tempfile.mkdtemp()
os.environ.update({
    "APP_ENV": "test", "DATABASE_URL": os.environ.get("TEST_DATABASE_URL", f"sqlite:///{_tmp}/test.db"), "PAYMENT_PROVIDER": "mock",
    "SECRET_KEY": "test-secret-key-that-is-long-enough-123456", "FLAG_KEY": "test-flag-key-that-is-long-enough-123456",
    "AUTO_CREATE_TABLES": "false", "FRONTEND_URL": "http://localhost:3000", "BACKEND_URL": "http://localhost:8000",
    "CORS_ORIGINS": "http://localhost:3000",
})

from fastapi.testclient import TestClient  # noqa: E402

from app import db as dbmod  # noqa: E402
from app.config import settings  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Base, Scenario, User  # noqa: E402
from app.ratelimit import limiter  # noqa: E402
from app.security import hash_password  # noqa: E402
from app.seed.seed import seed  # noqa: E402
from app.services import payments as pay  # noqa: E402
from sqlalchemy import select  # noqa: E402

settings.razorpay_key_secret = "test-key-secret"
settings.razorpay_webhook_secret = "test-webhook-secret"

ORIGIN = "http://localhost:3000"
PW = "CorrectHorse!9"


class Api:
    """Test client that behaves like the browser app: keeps cookies, echoes the CSRF cookie as a header."""

    def __init__(self, tc: TestClient):
        self.tc = tc

    def _h(self, extra=None):
        h = {"Origin": ORIGIN}
        c = self.tc.cookies.get("wa_csrf")
        if c:
            h["X-CSRF-Token"] = c
        h.update(extra or {})
        return h

    def get(self, url, **kw):
        return self.tc.get(url, headers=self._h(kw.pop("headers", None)), **kw)

    def post(self, url, json=None, **kw):
        return self.tc.post(url, json=json, headers=self._h(kw.pop("headers", None)), **kw)

    def put(self, url, json=None, **kw):
        return self.tc.put(url, json=json, headers=self._h(), **kw)

    def patch(self, url, json=None, **kw):
        return self.tc.patch(url, json=json, headers=self._h(), **kw)

    def delete(self, url, **kw):
        return self.tc.delete(url, headers=self._h(), **kw)


@pytest.fixture(autouse=True)
def fresh_db():
    dbmod.configure(os.environ["DATABASE_URL"])
    Base.metadata.drop_all(dbmod.engine)
    Base.metadata.create_all(dbmod.engine)
    limiter.reset()
    pay.set_provider(pay.MockProvider())
    s = dbmod.session()
    s.add(User(email="admin@test.dev", display_name="Root Admin", password_hash=hash_password(PW), role="super_admin"))
    s.add(User(email="instr@test.dev", display_name="Ina Instructor", password_hash=hash_password(PW), role="instructor"))
    s.commit()
    seed(s)
    s.close()
    yield


@pytest.fixture()
def db():
    s = dbmod.session()
    yield s
    s.close()


@pytest.fixture()
def scenario(db):
    return db.execute(select(Scenario)).scalars().first()


def new_client() -> Api:
    return Api(TestClient(app, base_url="http://localhost:8000"))


@pytest.fixture()
def anon():
    return new_client()


def login(email, password=PW) -> Api:
    a = new_client()
    r = a.post("/api/auth/login", {"email": email, "password": password})
    assert r.status_code == 200, r.text
    return a


@pytest.fixture()
def admin():
    return login("admin@test.dev")


@pytest.fixture()
def instructor():
    return login("instr@test.dev")


@pytest.fixture()
def make_student():
    n = {"i": 0}

    def _make(name="Priya Sharma") -> Api:
        n["i"] += 1
        a = new_client()
        r = a.post("/api/auth/register", {"email": f"stu{n['i']}@test.dev", "password": PW, "display_name": name})
        assert r.status_code == 201, r.text
        return a
    return _make


@pytest.fixture()
def student(make_student):
    return make_student()


def pay_for(api: Api, scenario_id: str, outcome="paid"):
    """Go through the full (mock) checkout like a browser would."""
    r = api.post(f"/api/exams/{scenario_id}/orders")
    assert r.status_code == 201, r.text
    order = r.json()
    link_id = order["checkout_url"].rsplit("/", 1)[1]
    r2 = api.tc.post(f"/api/dev/mock-pay/{link_id}/complete", data={"outcome": outcome}, follow_redirects=False)
    assert r2.status_code == 303, r2.text
    cb = api.tc.get(r2.headers["location"].replace("http://localhost:8000", ""), follow_redirects=False)
    assert cb.status_code == 303
    return order, cb.headers["location"]


def start_exam(api: Api, scenario_id: str) -> str:
    pay_for(api, scenario_id)
    r = api.post(f"/api/exams/{scenario_id}/start")
    assert r.status_code == 200, r.text
    return r.json()["attempt_id"]
