import json

from app.config import settings
from app.seed.night_watch import DEFINITION
from app.services import payments as pay


def webhook(api, body: dict, *, secret=None, event_id=None, sign=True):
    raw = json.dumps(body).encode()
    headers = {"Content-Type": "application/json"}
    if sign:
        headers["X-Razorpay-Signature"] = pay.webhook_signature(secret or settings.razorpay_webhook_secret, raw)
    if event_id:
        headers["X-Razorpay-Event-Id"] = event_id
    return api.tc.post("/api/payments/webhook", content=raw, headers=headers)


def paid_event(order, link_id, payment_id, amount=None, currency="INR"):
    return {"event": "payment_link.paid", "payload": {
        "payment_link": {"entity": {"id": link_id, "reference_id": order["id"], "status": "paid"}},
        "payment": {"entity": {"id": payment_id, "amount": order["amount_paise"] if amount is None else amount,
                               "currency": currency, "status": "captured", "method": "upi"}}}}


def refund_event(payment_id, amount, refund_id="rfnd_1"):
    return {"event": "refund.processed", "payload": {"refund": {"entity": {"id": refund_id, "payment_id": payment_id, "amount": amount}}}}


def solve_all(api, attempt_id):
    base = f"/api/attempts/{attempt_id}"
    for q in DEFINITION["questions"][:-1]:
        for c in q["solution"]["commands"]:
            assert api.post(f"{base}/terminal", {"command": c}).status_code == 200
        r = api.post(f"{base}/questions/{q['key']}/answer", {"answer": q["solution"].get("answer", "")})
        assert r.json()["correct"], q["key"]


def get_flag(api, attempt_id) -> str:
    out = api.post(f"/api/attempts/{attempt_id}/terminal", {"command": "cat /var/secure/clearance.txt"}).json()["output"]
    return out.split("Clearance proof: ")[1].strip()
