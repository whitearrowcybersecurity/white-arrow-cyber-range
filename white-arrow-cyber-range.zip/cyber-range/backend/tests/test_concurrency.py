"""Race test: many simultaneous deliveries of the same payment must grant exactly one entitlement.
Runs only on PostgreSQL (SQLite serialises writers, so it can't exercise the race)."""
import json
import threading

import pytest
from sqlalchemy import select

from app import db as dbmod
from app.models import Entitlement, ExamOrder, Payment
from app.services import payments as pay
from conftest import new_client
from helpers import paid_event


@pytest.mark.skipif(not __import__("os").environ["DATABASE_URL"].startswith("postgresql"), reason="needs PostgreSQL")
def test_parallel_duplicate_payment_grants_once(student, scenario):
    order = student.post(f"/api/exams/{scenario.id}/orders").json()
    link = order["checkout_url"].rsplit("/", 1)[1]
    results, barrier = [], threading.Barrier(8)

    def worker(i):
        s = dbmod.session()
        try:
            raw = json.dumps(paid_event(order, link, "pay_race")).encode()
            from app.config import settings
            sig = pay.webhook_signature(settings.razorpay_webhook_secret, raw)
            barrier.wait()
            results.append(pay.handle_webhook(s, raw, sig, f"evt_race_{i}")["status"])
            s.commit()
        except Exception as e:           # a losing racer may hit the unique constraint at commit time
            s.rollback()
            results.append("error:" + e.__class__.__name__)
        finally:
            s.close()

    ts = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    s = dbmod.session()
    assert s.query(Entitlement).count() == 1
    assert s.query(Payment).count() == 1
    assert s.get(ExamOrder, order["id"]).status == "paid"
    assert results.count("granted") == 1
    s.close()
