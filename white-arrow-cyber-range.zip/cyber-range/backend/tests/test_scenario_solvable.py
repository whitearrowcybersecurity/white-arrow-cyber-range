"""Proves the sample scenario is solvable end-to-end using only the public student API,
and that nothing sensitive leaks before it should."""
import json

from app.seed.night_watch import DEFINITION
from app.terminal.engine import Lab
from app.terminal.labs import NIGHT_WATCH_COMMANDS, build_night_watch, hook_for

from conftest import start_exam


def test_definition_shape():
    qs = DEFINITION["questions"]
    assert len(qs) == 30
    assert sum(q["is_final"] for q in qs) == 1 and qs[-1]["is_final"]
    keys = [q["key"] for q in qs]
    assert len(set(keys)) == 30


def test_every_question_solvable_with_reference_solution():
    """Offline: run each question's reference commands in a fresh shared lab and validate with the real validator."""
    from app.services.validation import validate
    state = build_night_watch()
    lab = Lab(state, NIGHT_WATCH_COMMANDS, hook_for("night_watch"), {"flag": lambda: "WA{x}"})
    log = []
    for q in DEFINITION["questions"][:-1]:
        # a question must NOT already be satisfied before its solution is run (for state checks)
        rule = q["validation"]
        if rule["type"] == "state":
            assert not validate(rule, state=state, log=log), f"{q['key']} already satisfied at start"
        for c in q["solution"]["commands"]:
            out, code = lab.run(c)
            log.append({"command": c, "output": out, "exit_code": code})
        ans = q["solution"].get("answer", "")
        assert validate(rule, answer=ans, state=state, log=log), f"{q['key']} not solvable with its reference solution"
    assert "/var/secure/clearance.txt" in state["fs"]          # hardening produced the clearance record


def test_wrong_answers_rejected_for_every_answer_question():
    from app.services.validation import validate
    state = build_night_watch()
    for q in DEFINITION["questions"][:-1]:
        if q["validation"]["type"] == "answer":
            assert not validate(q["validation"], answer="definitely-wrong-zzz", state=state, log=[])


def test_full_playthrough_via_api(student, scenario):
    sid = scenario.id
    attempt = start_exam(student, sid)
    base = f"/api/attempts/{attempt}"
    # final is gated at the start
    assert student.get(f"{base}/questions/q30").status_code == 403
    r = student.post(f"{base}/final", {"flag": "WA{guess}"})
    assert r.status_code == 403 and r.json()["code"] == "not_eligible"

    for q in DEFINITION["questions"][:-1]:
        for c in q["solution"]["commands"]:
            tr = student.post(f"{base}/terminal", {"command": c})
            assert tr.status_code == 200, tr.text
        r = student.post(f"{base}/questions/{q['key']}/answer", {"answer": q["solution"].get("answer", "")})
        assert r.status_code == 200, (q["key"], r.text)
        assert r.json()["correct"], (q["key"], r.text)

    ov = student.get(base).json()
    assert ov["final_gate"]["eligible"] is True and ov["completed"] == 29
    assert student.get(f"{base}/questions/q30").status_code == 200
    out = student.post(f"{base}/terminal", {"command": "cat /var/secure/clearance.txt"}).json()["output"]
    flag = out.split("Clearance proof: ")[1].strip()
    assert flag.startswith("WA{")
    res = student.post(f"{base}/final", {"flag": flag}).json()
    assert res["correct"] is True and res["letter_id"]
    pdf = student.get(f"/api/letters/{res['letter_id']}/pdf")
    assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF"
