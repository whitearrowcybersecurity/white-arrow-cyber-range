import re

import pytest
from sqlalchemy import select

from app.models import (CompletionRecord, Entitlement, ExamAttempt, ExamOrder, InternshipLetter, Payment, PaymentEvent)
from app.services.validation import derive_flag
from conftest import login, pay_for, start_exam
from helpers import get_flag, paid_event, refund_event, solve_all, webhook


# ------------------------------------------------------------------ Workflow A
def test_A_paid_exam_access_only_after_verified_payment(student, scenario, db):
    r = student.post(f"/api/exams/{scenario.id}/orders")
    assert r.status_code == 201
    order = r.json()
    assert order["amount_paise"] == 30000 and order["status"] == "pending"          # Rs 300 in paise
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 402        # created but unpaid
    # forged redirect (bad signature) must not grant anything
    link_id = order["checkout_url"].rsplit("/", 1)[1]
    forged = student.tc.get("/api/payments/callback", params={
        "razorpay_payment_id": "pay_fake1", "razorpay_payment_link_id": link_id,
        "razorpay_payment_link_reference_id": order["id"], "razorpay_payment_link_status": "paid",
        "razorpay_signature": "0" * 64}, follow_redirects=False)
    assert "r=invalid" in forged.headers["location"]
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 402
    # real checkout
    r = student.tc.post(f"/api/dev/mock-pay/{link_id}/complete", data={"outcome": "paid"}, follow_redirects=False)
    cb = student.tc.get(r.headers["location"].replace("http://localhost:8000", ""), follow_redirects=False)
    assert "r=paid" in cb.headers["location"]
    assert student.get(f"/api/orders/{order['id']}").json()["status"] == "paid"
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 200
    ent = db.execute(select(Entitlement)).scalars().all()
    assert len(ent) == 1 and ent[0].order_id == order["id"]
    # receipt
    rc = student.get(f"/api/orders/{order['id']}/receipt.pdf")
    assert rc.status_code == 200 and rc.content[:4] == b"%PDF"


def test_A_webhook_alone_grants_access_even_if_browser_never_returns(student, scenario):
    order = student.post(f"/api/exams/{scenario.id}/orders").json()
    link_id = order["checkout_url"].rsplit("/", 1)[1]
    r = webhook(student, paid_event(order, link_id, "pay_w1"), event_id="evt_1")
    assert r.status_code == 200 and r.json()["status"] == "granted"
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 200


def test_A_order_reused_not_duplicated_and_cannot_rebuy_when_entitled(student, scenario, db):
    a = student.post(f"/api/exams/{scenario.id}/orders").json()
    b = student.post(f"/api/exams/{scenario.id}/orders").json()
    assert a["id"] == b["id"]
    link_id = a["checkout_url"].rsplit("/", 1)[1]
    webhook(student, paid_event(a, link_id, "pay_r1"), event_id="evt_r1")
    assert student.post(f"/api/exams/{scenario.id}/orders").status_code == 409


# ------------------------------------------------------------------ Workflow B
def test_B_locked_for_unpaid_student_including_direct_api(student, make_student, scenario, anon):
    # public preview leaks nothing protected
    tracks = anon.get("/api/tracks").json()
    blob = str(tracks) + str(anon.get(f"/api/scenarios/{scenario.slug}").json())
    for secret in ("q01", "clearance", "Quiver", "validation", "accepted", "mission_brief", "WA{", "toor", "sudo -l"):
        assert secret not in blob, secret
    assert tracks[0]["scenarios"][0]["price_paise"] == 30000
    # no entitlement -> cannot start, cannot reach attempt routes
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 402
    assert student.get("/api/attempts/does-not-exist").status_code == 404
    # a paid student's attempt is invisible to an unpaid one (404, not 403)
    other = make_student("Other Person")
    att = start_exam(other, scenario.id)
    for path in (f"/api/attempts/{att}", f"/api/attempts/{att}/questions/q01"):
        assert student.get(path).status_code == 404
    assert student.post(f"/api/attempts/{att}/terminal", {"command": "ls"}).status_code == 404
    assert student.post(f"/api/attempts/{att}/final", {"flag": "WA{x}"}).status_code == 404
    # anonymous
    assert anon.get(f"/api/attempts/{att}").status_code == 401


# ------------------------------------------------------------------ Workflow C
def test_C_practical_challenge_progress_persists(student, scenario):
    att = start_exam(student, scenario.id)
    base = f"/api/attempts/{att}"
    out = student.post(f"{base}/terminal", {"command": "pwd"}).json()
    assert out["output"] == "/home/intern" and out["prompt"].startswith("intern@mfs-gateway-01:~$")
    assert student.post(f"{base}/questions/q01/answer", {"answer": "/etc"}).json()["correct"] is False
    r = student.post(f"{base}/questions/q01/answer", {"answer": "/home/intern"}).json()
    assert r["correct"] and r["score_awarded"] == 10
    # idempotent: no double score
    assert student.post(f"{base}/questions/q01/answer", {"answer": "/home/intern"}).json()["score_awarded"] == 0
    # state-based question fails until the lab state really changes
    student.post(f"{base}/terminal", {"command": "cat /etc/crontab"})
    student.post(f"{base}/terminal", {"command": "find / -perm -002 -type f 2>/dev/null"})
    assert student.post(f"{base}/questions/q22/answer", {"answer": "/opt/backup/backup.sh"}).json()["correct"]
    r = student.post(f"{base}/questions/q25/answer", {}).json()
    assert r["correct"] is False
    student.post(f"{base}/terminal", {"command": "sudo chmod 750 /opt/backup/backup.sh"})
    assert student.post(f"{base}/questions/q25/answer", {}).json()["correct"] is True
    # state persisted across 'sessions'
    again = start_exam_resume(student, scenario.id)
    assert again == att
    ov = student.get(base).json()
    assert ov["completed"] == 3 and ov["score"] == 30
    assert student.post(f"{base}/terminal", {"command": "ls -l /opt/backup"}).json()["output"].count("rwxr-x---") == 1
    # prerequisites enforced
    assert student.get(f"{base}/questions/q29").status_code == 403
    # hints are server-metered
    h = student.post(f"{base}/questions/q02/hint").json()
    assert h["level"] == 1 and h["hints_total"] == 3
    assert len(student.get(f"{base}/questions/q02").json()["hints"]) == 1


def start_exam_resume(api, sid):
    r = api.post(f"/api/exams/{sid}/start")
    assert r.status_code == 200
    return r.json()["attempt_id"]


# ------------------------------------------------------------------ Workflow D
def test_D_final_flag_rules(student, make_student, scenario, db):
    att = start_exam(student, scenario.id)
    base = f"/api/attempts/{att}"
    assert student.post(f"{base}/final", {"flag": "WA{nope}"}).json()["code"] == "not_eligible"
    solve_all(student, att)
    assert not re.search(r"WA\{[0-9a-f]{24}\}", str(student.get(base).json()) + str(student.get(f"{base}/questions/q30").json()))
    assert student.post(f"{base}/final", {"flag": "WA{wrong}"}).json()["correct"] is False
    assert student.post(f"{base}/final", {"flag": ""}).json()["correct"] is False
    # another student's genuine flag does not work here (flags are per lab session)
    other = make_student("Rahul Verma")
    att2 = start_exam(other, scenario.id)
    solve_all(other, att2)
    other_flag = get_flag(other, att2)
    assert student.post(f"{base}/final", {"flag": other_flag}).json()["correct"] is False
    assert db.execute(select(CompletionRecord)).first() is None
    good = get_flag(student, att)
    res = student.post(f"{base}/final", {"flag": good}).json()
    assert res["correct"] and res["score"] == res["max_score"] == 340
    rec = db.execute(select(CompletionRecord)).scalars().one()
    assert rec.user_id and rec.record_hash
    # terminal is closed after completion
    assert student.post(f"{base}/terminal", {"command": "ls"}).status_code == 409


def test_D_flag_with_state_no_longer_hardened_is_rejected(student, scenario, db):
    att = start_exam(student, scenario.id)
    solve_all(student, att)
    flag = get_flag(student, att)
    student.post(f"/api/attempts/{att}/terminal", {"command": "sudo chmod 777 /opt/backup/backup.sh"})   # undo a fix
    r = student.post(f"/api/attempts/{att}/final", {"flag": flag}).json()
    assert r["correct"] is False
    student.post(f"/api/attempts/{att}/terminal", {"command": "sudo chmod 750 /opt/backup/backup.sh"})
    assert student.post(f"/api/attempts/{att}/final", {"flag": flag}).json()["correct"] is True


# ------------------------------------------------------------------ Workflow E
def test_E_letter_only_after_real_completion_and_verifiable(student, scenario, anon, admin, db):
    att = start_exam(student, scenario.id)
    assert student.get("/api/me/letters").json() == []
    solve_all(student, att)
    assert student.get("/api/me/letters").json() == []          # solved questions alone: still no letter
    flag = get_flag(student, att)
    res = student.post(f"/api/attempts/{att}/final", {"flag": flag}).json()
    letters = student.get("/api/me/letters").json()
    assert len(letters) == 1 and letters[0]["id"] == res["letter_id"]
    # resubmitting does not issue a second letter
    assert student.post(f"/api/attempts/{att}/final", {"flag": flag}).json()["already_completed"] is True
    assert db.query(InternshipLetter).count() == 1
    pdf = student.get(f"/api/letters/{letters[0]['id']}/pdf")
    assert pdf.status_code == 200 and pdf.headers["content-type"] == "application/pdf"
    # public verification: minimum disclosure
    v = anon.get(f"/api/verify/{letters[0]['verification_id']}").json()
    assert v["valid"] is True and v["holder"] == "P**** S*****"
    assert "email" not in v and "score" not in v
    assert anon.get("/api/verify/WA-AAAA-BBBB-CCCC").json() == {"valid": False}
    assert anon.get("/api/verify/%27%20OR%201=1--").json() == {"valid": False}
    # another student cannot download it
    from conftest import new_client
    other = new_client()
    other.post("/api/auth/register", {"email": "x@test.dev", "password": "CorrectHorse!9", "display_name": "Mallory Z"})
    assert other.get(f"/api/letters/{letters[0]['id']}/pdf").status_code == 404
    # admin reissue supersedes; old id stops verifying as valid
    new = admin.post(f"/api/admin/letters/{letters[0]['id']}/reissue", {"reason": "name correction"}).json()
    assert anon.get(f"/api/verify/{letters[0]['verification_id']}").json()["valid"] is False
    assert anon.get(f"/api/verify/{new['verification_id']}").json()["valid"] is True
    # revoke
    admin.post(f"/api/admin/letters/{db.query(InternshipLetter).filter_by(verification_id=new['verification_id']).one().id}/revoke", {"reason": "test revoke"})
    v2 = anon.get(f"/api/verify/{new['verification_id']}").json()
    assert v2["valid"] is False and v2["status"] == "revoked"


# ------------------------------------------------------------------ Workflow F
def _order_and_link(student, scenario):
    order = student.post(f"/api/exams/{scenario.id}/orders").json()
    return order, order["checkout_url"].rsplit("/", 1)[1]


def test_F_forged_webhook_rejected(student, scenario, db):
    order, link = _order_and_link(student, scenario)
    r = webhook(student, paid_event(order, link, "pay_forged"), sign=False)
    assert r.status_code == 400
    r = webhook(student, paid_event(order, link, "pay_forged"), secret="wrong-secret")
    assert r.status_code == 400
    assert db.query(Entitlement).count() == 0 and db.query(Payment).count() == 0
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 402


def test_F_duplicate_webhooks_and_replayed_payment_are_idempotent(student, scenario, db):
    order, link = _order_and_link(student, scenario)
    ev = paid_event(order, link, "pay_dup")
    assert webhook(student, ev, event_id="evt_A").json()["status"] == "granted"
    assert webhook(student, ev, event_id="evt_A").json()["status"] == "duplicate"        # same delivery id
    assert webhook(student, ev, event_id="evt_B").json()["status"] == "duplicate"        # same payment, new event id
    assert webhook(student, ev).json()["status"] in ("duplicate", "granted")               # no event id header
    assert db.query(Entitlement).count() == 1 and db.query(Payment).count() == 1


def test_F_payment_cannot_be_replayed_on_another_students_order(student, make_student, scenario, db):
    order, link = _order_and_link(student, scenario)
    webhook(student, paid_event(order, link, "pay_shared"), event_id="e1")
    other = make_student("Another Student")
    o2, l2 = _order_and_link(other, scenario)
    r = webhook(other, paid_event(o2, l2, "pay_shared"), event_id="e2")
    assert r.json()["status"] == "duplicate"
    assert other.post(f"/api/exams/{scenario.id}/start").status_code == 402


def test_F_amount_mismatch_and_wrong_currency_do_not_grant(student, scenario, db):
    order, link = _order_and_link(student, scenario)
    r = webhook(student, paid_event(order, link, "pay_low", amount=100), event_id="e1").json()
    assert r["status"] == "amount_mismatch"
    r = webhook(student, paid_event(order, link, "pay_usd", currency="USD"), event_id="e2").json()
    assert r["status"] == "amount_mismatch"
    assert db.get(ExamOrder, order["id"]).status == "review"
    assert db.query(Entitlement).count() == 0
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 402


def test_F_failed_payment_grants_nothing_and_can_retry(student, scenario, db):
    order, link = _order_and_link(student, scenario)
    pay_failed = {"event": "payment.failed", "payload": {"payment": {"entity": {
        "id": "pay_bad", "amount": 30000, "currency": "INR", "notes": {"order_id": order["id"]}, "error_description": "bank declined"}}}}
    assert webhook(student, pay_failed, event_id="ef").json()["status"] == "recorded"
    assert student.get(f"/api/orders/{order['id']}").json()["status"] == "failed"
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 402
    # customer retries successfully on the same link
    assert webhook(student, paid_event(order, link, "pay_ok"), event_id="eo").json()["status"] == "granted"
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 200


def test_F_full_refund_before_completion_revokes_access(student, scenario, db):
    order, link = _order_and_link(student, scenario)
    webhook(student, paid_event(order, link, "pay_ref"), event_id="e1")
    att = student.post(f"/api/exams/{scenario.id}/start").json()["attempt_id"]
    assert student.post(f"/api/attempts/{att}/terminal", {"command": "pwd"}).status_code == 200
    assert webhook(student, refund_event("pay_ref", 30000), event_id="e2").json()["status"] == "refunded"
    assert student.post(f"/api/attempts/{att}/terminal", {"command": "pwd"}).status_code == 402
    assert student.get(f"/api/attempts/{att}/questions/q01").status_code == 402
    assert student.post(f"/api/exams/{scenario.id}/start").status_code in (402, 409, 403)
    assert db.query(Entitlement).one().status == "revoked"


def test_F_partial_refund_flags_for_review_but_keeps_access(student, scenario, admin, db):
    order, link = _order_and_link(student, scenario)
    webhook(student, paid_event(order, link, "pay_part"), event_id="e1")
    assert webhook(student, refund_event("pay_part", 5000), event_id="e2").json()["status"] == "partially_refunded"
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 200
    actions = [r["action"] for r in admin.get("/api/admin/audit?size=200").json()["items"]]
    assert "payment.partially_refunded" in actions


def test_F_refund_after_completion_does_not_delete_record(student, scenario, admin, db):
    order, link = _order_and_link(student, scenario)
    webhook(student, paid_event(order, link, "pay_done"), event_id="e1")
    att = student.post(f"/api/exams/{scenario.id}/start").json()["attempt_id"]
    solve_all(student, att)
    student.post(f"/api/attempts/{att}/final", {"flag": get_flag(student, att)})
    webhook(student, refund_event("pay_done", 30000), event_id="e2")
    assert db.query(CompletionRecord).count() == 1
    assert "refund.after_completion" in [r["action"] for r in admin.get("/api/admin/audit?size=200").json()["items"]]


def test_F_callback_without_provider_confirmation_is_not_enough(student, scenario, db):
    """A validly-signed redirect whose link the provider doesn't report as paid must not grant access."""
    from app.config import settings
    from app.services import payments as pay
    order, link = _order_and_link(student, scenario)
    sig = pay.callback_signature(settings.razorpay_key_secret, link, order["id"], "paid", "pay_unconfirmed")
    r = student.tc.get("/api/payments/callback", params={
        "razorpay_payment_id": "pay_unconfirmed", "razorpay_payment_link_id": link,
        "razorpay_payment_link_reference_id": order["id"], "razorpay_payment_link_status": "paid", "razorpay_signature": sig},
        follow_redirects=False)
    assert "r=pending" in r.headers["location"]
    assert db.query(Entitlement).count() == 0


def test_F_callback_for_other_students_order_cannot_hijack_access(student, make_student, scenario, db):
    """The PHP reference granted access to whoever was logged in. Here the order owner is the only beneficiary."""
    victim = make_student("Victim One")
    order, link = _order_and_link(victim, scenario)
    from conftest import new_client
    attacker_sees = student
    r = victim.tc.post(f"/api/dev/mock-pay/{link}/complete", data={"outcome": "paid"}, follow_redirects=False)
    # attacker replays the victim's signed callback URL from their own browser session
    attacker_sees.tc.get(r.headers["location"].replace("http://localhost:8000", ""), follow_redirects=False)
    ents = db.query(Entitlement).all()
    assert len(ents) == 1 and ents[0].user_id == db.get(ExamOrder, order["id"]).user_id
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 402


def test_F_reconcile_picks_up_missed_webhook(student, scenario, admin, db):
    from app.services import payments as pay
    order, link = _order_and_link(student, scenario)
    pay.get_provider().simulate(link, "paid")                                   # money moved, no webhook/redirect arrived
    db.get(ExamOrder, order["id"]).created_at -= __import__("datetime").timedelta(minutes=10)
    db.commit()
    res = admin.post("/api/admin/payments/reconcile").json()
    assert res[order["id"]] == "granted"
    assert student.post(f"/api/exams/{scenario.id}/start").status_code == 200


# ------------------------------------------------------------------ Workflow G
def test_G_role_security(student, instructor, admin, scenario, make_student):
    for path in ("/api/admin/overview", "/api/admin/users", "/api/admin/scenarios", "/api/admin/payments", "/api/admin/audit", "/api/admin/settings"):
        assert student.get(path).status_code == 403, path
    # instructor: allowed staff routes vs super-admin-only routes
    assert instructor.get("/api/admin/overview").status_code == 200
    for path in ("/api/admin/payments", "/api/admin/audit", "/api/admin/settings"):
        assert instructor.get(path).status_code == 403, path
    assert instructor.post("/api/admin/users", {"email": "a@b.cc", "display_name": "AA", "password": "CorrectHorse!9", "role": "student"}).status_code == 403
    assert instructor.post(f"/api/admin/scenarios/{scenario.id}/publish").status_code == 403
    assert instructor.patch(f"/api/admin/scenarios/{scenario.id}", {"price_paise": 100}).status_code in (403, 404)
    # students cannot self-complete or tamper
    att = start_exam(student, scenario.id)
    assert student.post(f"/api/attempts/{att}/questions/q30/answer", {"answer": "x"}).status_code == 400
    assert student.post(f"/api/attempts/{att}/questions/q99/answer", {"answer": "x"}).status_code == 404
    # student responses never carry validation data or answers
    blob = str(student.get(f"/api/attempts/{att}").json()) + str(student.get(f"/api/attempts/{att}/questions/q10").json())
    for leak in ("accepted", "validation", "toor", "and_state"):
        assert leak not in blob, leak
    # unauthenticated
    from conftest import new_client
    assert new_client().get("/api/admin/overview").status_code == 401


def test_G_instructor_scoped_to_assigned_scenarios_and_students(student, instructor, admin, scenario, db):
    att = start_exam(student, scenario.id)
    assert instructor.get("/api/admin/progress").json()["total"] == 0                 # nothing assigned
    assert instructor.get(f"/api/admin/scenarios/{scenario.id}").status_code == 404
    from app.models import User
    ins = db.query(User).filter_by(email="instr@test.dev").one()
    assert admin.post("/api/admin/assignments", {"instructor_id": ins.id, "scenario_id": scenario.id}).status_code == 201
    assert instructor.get("/api/admin/progress").json()["total"] == 1
    detail = instructor.get(f"/api/admin/scenarios/{scenario.id}")
    assert detail.status_code == 200 and "validation" in str(detail.json())            # instructors do see rules
    assert instructor.post(f"/api/admin/attempts/{att}/reset-lab").status_code == 200
    users = instructor.get("/api/admin/users").json()
    assert {u["email"] for u in users["items"]} == {"stu1@test.dev"}                    # only their cohort, no admins


def test_G_suspended_user_loses_access_immediately(student, admin, scenario, db):
    att = start_exam(student, scenario.id)
    from app.models import User
    uid = db.query(User).filter_by(email="stu1@test.dev").one().id
    assert admin.patch(f"/api/admin/users/{uid}", {"status": "suspended"}).status_code == 200
    assert student.post(f"/api/attempts/{att}/terminal", {"command": "ls"}).status_code == 401
