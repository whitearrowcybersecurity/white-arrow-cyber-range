import pytest
from starlette.websockets import WebSocketDisconnect

from conftest import new_client, start_exam
from helpers import paid_event, refund_event, webhook

ORIGIN = {"origin": "http://localhost:3000"}


def H(api):
    """Browsers attach cookies to the WebSocket handshake; Starlette's TestClient doesn't, so do it explicitly."""
    return {**ORIGIN, "cookie": "; ".join(f"{k}={v}" for k, v in api.tc.cookies.items())}


def test_ws_terminal_roundtrip_and_authz(student, make_student, scenario, anon):
    att = start_exam(student, scenario.id)
    url = f"/ws/attempts/{att}/terminal"
    with student.tc.websocket_connect(url, headers=H(student)) as ws:
        ready = ws.receive_json()
        assert ready["type"] == "ready" and ready["prompt"].startswith("intern@")
        ws.send_json({"cmd": "whoami"})
        assert ws.receive_json()["output"] == "intern"
        ws.send_json({"cmd": "cd /var/log"})
        assert ws.receive_json()["prompt"].startswith("intern@mfs-gateway-01:/var/log$")
        ws.send_text("not json")
        assert ws.receive_json()["code"] == "bad_message"
    # state written over WS is the same state REST sees
    assert student.post(f"/api/attempts/{att}/terminal", {"command": "pwd"}).json()["output"] == "/var/log"
    # no cookie -> refused
    with pytest.raises(WebSocketDisconnect):
        with anon.tc.websocket_connect(url, headers=ORIGIN):
            pass
    # someone else's attempt -> refused
    other = make_student("Not Mine")
    with pytest.raises(WebSocketDisconnect):
        with other.tc.websocket_connect(url, headers=H(other)):
            pass
    # cross-site WebSocket hijack attempt (evil origin) -> refused even with valid cookies
    with pytest.raises(WebSocketDisconnect):
        with student.tc.websocket_connect(url, headers={**H(student), "origin": "https://evil.example"}):
            pass
    with pytest.raises(WebSocketDisconnect):
        with student.tc.websocket_connect(url, headers={"cookie": H(student)["cookie"]}):   # no Origin header at all
            pass


def test_ws_stops_when_payment_is_refunded_mid_session(student, scenario):
    order = student.post(f"/api/exams/{scenario.id}/orders").json()
    link = order["checkout_url"].rsplit("/", 1)[1]
    webhook(student, paid_event(order, link, "pay_ws"), event_id="e1")
    att = student.post(f"/api/exams/{scenario.id}/start").json()["attempt_id"]
    with student.tc.websocket_connect(f"/ws/attempts/{att}/terminal", headers=H(student)) as ws:
        ws.receive_json()
        ws.send_json({"cmd": "pwd"})
        assert ws.receive_json()["output"] == "/home/intern"
        webhook(student, refund_event("pay_ws", 30000), event_id="e2")
        ws.send_json({"cmd": "pwd"})
        msg = ws.receive_json()
        assert msg["type"] == "error" and msg["code"] == "payment_required"
