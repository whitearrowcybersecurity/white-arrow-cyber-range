# API

Full machine-readable spec: [`openapi.json`](openapi.json) (also live at `/docs`). 51 paths.
Mutating requests need the `wa_session` cookie plus `X-CSRF-Token` (value of `wa_csrf`, from `GET /api/auth/csrf`).

Groups: `/api/auth/*`, `/api/tracks`, `/api/scenarios/{slug}`, `/api/exams/{scenario}/orders|start`, `/api/orders/*`,
`/api/payments/callback|webhook`, `/api/attempts/{id}/...` (questions, answer, hint, ai, terminal, final, history),
WebSocket `/ws/attempts/{id}/terminal`, `/api/me/exams|letters`, `/api/letters/{id}/pdf`, public `/api/verify/{id}`,
and `/api/admin/*` (overview, users, assignments, scenarios, payments, progress, completions, letters, audit, settings).
`/api/dev/*` and `/mock-pay/*` exist only with the mock provider.
