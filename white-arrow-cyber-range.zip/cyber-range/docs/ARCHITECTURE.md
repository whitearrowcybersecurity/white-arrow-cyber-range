# Architecture

```mermaid
flowchart LR
  B[Browser: Next.js + xterm.js] -- REST + cookies + CSRF --> API[FastAPI]
  B -- WebSocket /ws/attempts/id/terminal --> API
  API --> DB[(Postgres)]
  API -- create link / fetch link --> RZ[Razorpay Payment Links]
  RZ -- webhook, signed --> API
  API --> SIM[Simulated shell: in-memory FS per lab session]
  API --> AI[AI tutor: local or anthropic]
```

## Layers (backend/app)
- `routers/` HTTP/WS only; `services/` business rules; `terminal/` shell simulator; `models.py` schema; `audit.py` hash-chained log.
- **Gating**: exam start requires a live entitlement (created only by a verified payment). Questions unlock by prerequisites; the final question needs the completion policy (`all`, `percent`, `percent_plus_mandatory`) AND the per-session flag, which only exists in the lab once the system is actually hardened.
- **Flags** are per lab session: `WA{HMAC(FLAG_KEY, session:scenario:key)[:24]}`, so a shared flag is useless.
- **Immutability**: completion records and audit rows reject UPDATE/DELETE via ORM listeners; letters reference them and can be revoked/reissued without altering history.
- **Scenario versions**: publishing snapshots the scenario; attempts stay pinned to their version.
- **Simulated terminal** never executes host commands. It interprets a command subset (pipes, redirects, `&&`/`||`, find/grep/sed/chmod/sudo rules) over an in-memory filesystem.

## Milestones
1. Done: auth/RBAC, schema+migrations, payments, exam flow, terminal, flag, letters, verify, AI hints, admin, tests, Docker.
2. Next: real container labs, more scenarios, student assignment, Redis rate limiting, live Razorpay test.
