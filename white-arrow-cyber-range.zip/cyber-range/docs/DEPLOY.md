# Deploy

1. Postgres 16, managed if possible, with backups. Run a single API instance for now (in-process rate limiter).
2. Env: `APP_ENV=production`, strong `SECRET_KEY`/`FLAG_KEY` (startup fails otherwise), `COOKIE_SECURE=true`, `PAYMENT_PROVIDER=razorpay`, Razorpay keys, `FRONTEND_URL`/`BACKEND_URL`/`CORS_ORIGINS` as the real https origins. Do not seed demo users; set `BOOTSTRAP_ADMIN_*` and run `python -m app.seed.seed` once.
3. Put both behind HTTPS (reverse proxy), proxying `/ws/` with Upgrade headers. Serve web and API on the same site so SameSite cookies work.
4. Migrate: `alembic upgrade head` before starting a new version.
5. Razorpay Dashboard: add webhook `https://<api>/api/payments/webhook` with events `payment_link.paid`, `payment.captured`, `refund.processed`; secret = `RAZORPAY_WEBHOOK_SECRET`.
6. Pre-launch: one real test-mode payment, a refund, check admin audit "Verify chain", and use `POST /api/admin/payments/reconcile` as a safety net.

## Hosting the code on GitHub
GitHub Pages cannot run this app (it needs the API, database and WebSocket). Use GitHub for source and CI, and deploy the containers elsewhere.
1. Create a **private** repo, then: `git init && git add . && git commit -m "Initial import" && git branch -M main && git remote add origin <url> && git push -u origin main`. `.env` and `*.db` are git-ignored; never commit real keys.
2. `.github/workflows/ci.yml` runs backend tests (SQLite and Postgres) and builds the frontend and both Docker images on every push.
3. Deploy the `backend/` and `frontend/` Dockerfiles to a VPS or a container host (Render, Railway, Fly.io) with managed Postgres. Store all secrets in the host's secret manager or GitHub Actions secrets, not in the repo.
4. Keep web and API on the same registrable domain (e.g. `range.example.com` and `api.example.com`) so the session cookie and CSRF scheme work.
