# Payments (Razorpay Payment Links)

Modelled on the PHP reference site's Payment Links flow, with these hardening changes.

| PHP reference | Here |
|---|---|
| Keys in a PHP include in the web root | Env vars, server-side only; nothing in frontend or git |
| Access granted from the browser redirect | Redirect is verified (signature) and the link is re-fetched from Razorpay (amount, currency, status). Webhook is the primary confirmation |
| No dedupe | `X-Razorpay-Event-Id` stored; unique `provider_payment_id` and one entitlement per order, so replays are no-ops (race-tested on Postgres) |
| Amount from client | Amount fixed server-side from settings (₹300 = 30000 paise); mismatch sets order to `review`, no access |
| No refunds | Full refund revokes entitlement and active attempts; refund after completion keeps the immutable record and flags the audit log; partial refund keeps access and is flagged |

Order is bound to the student; `reference_id` = order id. Admin can list payments and reconcile pending orders. Receipt PDF per paid order.

**Action required:** the PHP site's `includes/razorpay-config.php` appears to contain real keys. It was deliberately not opened or copied. Rotate those keys in the Razorpay Dashboard.

**Caveat:** live Razorpay calls are unverified (no keys/network here); only the mock provider and signature logic are tested.
