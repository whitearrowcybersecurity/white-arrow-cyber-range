# Security notes

- Passwords: argon2. Session: JWT in HttpOnly, SameSite cookie. CSRF: double-submit token plus Origin check. WebSocket Origin allow-list.
- RBAC: student / instructor / super_admin; instructors only see students assigned to them. Admin CSV export neutralises formula injection.
- Rate limits on auth, answers, terminal, AI; AI has daily quotas.
- Anti-cheat: flags are per session; answers and solutions are never sent to the client; AI context uses public fields only and output is scrubbed for flag patterns and accepted answers.
- Terminal is simulated; no host exec, no network. Idle labs expire (janitor task).
- Audit log is hash-chained and append-only; `/api/admin/audit/verify` checks integrity.
- Production start-up refuses weak secrets, insecure cookies or mock payments.
- Secrets: only via env; rotate the PHP site's Razorpay keys (see PAYMENTS.md).
- Known limits: in-process rate limiter (single instance); no MFA; no email verification/password reset yet.
