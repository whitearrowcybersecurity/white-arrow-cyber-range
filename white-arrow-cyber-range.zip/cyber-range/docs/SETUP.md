# Setup

## Docker (recommended)
```bash
cp .env.example .env     # set SECRET_KEY and FLAG_KEY: openssl rand -hex 32
docker compose up --build
```
API runs `alembic upgrade head`, `seed --demo`, then uvicorn. Web: :3000, API: :8000, docs at :8000/docs.

## Local dev
```bash
cd backend && pip install -r requirements-dev.txt
export DATABASE_URL=sqlite:///./dev.db SECRET_KEY=$(openssl rand -hex 32) FLAG_KEY=$(openssl rand -hex 32)
alembic upgrade head && python -m app.seed.seed --demo
uvicorn app.main:app --reload
cd ../frontend && npm ci && npm run dev
```
## Tests
`cd backend && pytest -q`. Set `TEST_DATABASE_URL=postgresql+psycopg://...` to run on Postgres, which also enables the concurrency race test (use a throwaway database).

## Mock payments
With `PAYMENT_PROVIDER=mock` the checkout is a local page ("Simulate successful payment") that sends a signed webhook internally. Mock mode is refused when `APP_ENV=production`.
