"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, API, inr } from "@/lib/api";
import { useMe } from "@/lib/useMe";

type Tab = "overview" | "students" | "progress" | "scenarios" | "completions" | "payments" | "audit" | "settings";

function useList<T = any>(path: string, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [err, setErr] = useState("");
  const reload = useCallback(() => { api<T>(path).then((d) => { setData(d); setErr(""); }).catch((e) => setErr(e.message)); }, [path]);
  useEffect(reload, [reload, ...deps]);
  return { data, err, reload };
}

function Table({ cols, rows }: { cols: string[]; rows: (string | number | null | JSX.Element)[][] }) {
  return (
    <div className="card overflow-x-auto p-0">
      <table className="w-full">
        <thead><tr>{cols.map((c) => <th key={c}>{c}</th>)}</tr></thead>
        <tbody>{rows.length ? rows.map((r, i) => <tr key={i} className="border-t border-line">{r.map((c, j) => <td key={j}>{c}</td>)}</tr>) : <tr><td colSpan={cols.length} className="text-mute">Nothing here yet.</td></tr>}</tbody>
      </table>
    </div>
  );
}

export default function Admin() {
  const { me, loading } = useMe();
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("overview");
  useEffect(() => { if (!loading && (!me || me.role === "student")) router.push(me ? "/dashboard" : "/login"); }, [me, loading]);
  if (!me || me.role === "student") return null;
  const isAdmin = me.role === "super_admin";
  const tabs: [Tab, string, boolean][] = [["overview", "Overview", true], ["students", "Students", true], ["progress", "Progress", true], ["scenarios", "Scenarios", true],
    ["completions", "Completions", true], ["payments", "Payments", isAdmin], ["audit", "Audit log", isAdmin], ["settings", "Settings", isAdmin]];
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-semibold">{isAdmin ? "Administrator" : "Instructor"} workspace</h1><span className="chip">{me.role}</span></div>
      <div className="flex flex-wrap gap-2" role="tablist">
        {tabs.filter((t) => t[2]).map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={tab === k ? "btn-primary" : "btn-ghost"}>{l}</button>)}
      </div>
      {tab === "overview" && <Overview />}
      {tab === "students" && <Students />}
      {tab === "progress" && <Progress />}
      {tab === "scenarios" && <Scenarios isAdmin={isAdmin} />}
      {tab === "completions" && <Completions isAdmin={isAdmin} />}
      {tab === "payments" && isAdmin && <Payments />}
      {tab === "audit" && isAdmin && <Audit />}
      {tab === "settings" && isAdmin && <SettingsTab />}
    </div>
  );
}

function Overview() {
  const { data, err } = useList<Record<string, number>>("/api/admin/overview");
  if (err) return <p className="text-red-300">{err}</p>;
  const label: Record<string, string> = { students: "Students", active_attempts: "Active attempts", completions: "Completions", paid_orders: "Paid orders", revenue_paise: "Net revenue", review_orders: "Orders in review", ai_requests_24h: "AI requests (24h)" };
  return <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{data && Object.entries(data).map(([k, v]) => <div key={k} className="card"><p className="text-xs uppercase tracking-wide text-mute">{label[k] || k}</p><p className="mt-1 text-2xl font-bold">{k === "revenue_paise" ? inr(v) : v}</p></div>)}</div>;
}

function Pager({ page, total, size, set }: { page: number; total: number; size: number; set: (n: number) => void }) {
  return <div className="flex items-center gap-2 text-sm text-mute"><button className="btn-ghost" disabled={page <= 1} onClick={() => set(page - 1)}>Prev</button><span>Page {page} · {total} total</span><button className="btn-ghost" disabled={page * size >= total} onClick={() => set(page + 1)}>Next</button></div>;
}

function Students() {
  const [q, setQ] = useState(""); const [page, setPage] = useState(1);
  const { data, err, reload } = useList<any>(`/api/admin/users?q=${encodeURIComponent(q)}&page=${page}`);
  const { me } = useMe();
  const toggle = async (u: any) => { await api(`/api/admin/users/${u.id}`, { method: "PATCH", body: { status: u.status === "active" ? "suspended" : "active" } }); reload(); };
  return (
    <div className="space-y-3">
      <input className="input max-w-sm" placeholder="Search name or email" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
      {err && <p className="text-red-300">{err}</p>}
      <Table cols={["Name", "Email", "Role", "Status", "Last login", ""]} rows={(data?.items || []).map((u: any) => [u.display_name, u.email, u.role, u.status, u.last_login_at?.slice(0, 16).replace("T", " ") || "—",
        me?.role === "super_admin" && u.id !== me.id ? <button className="btn-ghost" onClick={() => toggle(u)}>{u.status === "active" ? "Suspend" : "Reactivate"}</button> : ""])} />
      {data && <Pager page={page} total={data.total} size={25} set={setPage} />}
    </div>
  );
}

function Progress() {
  const [q, setQ] = useState(""); const [page, setPage] = useState(1);
  const { data, err, reload } = useList<any>(`/api/admin/progress?q=${encodeURIComponent(q)}&page=${page}`);
  const reset = async (id: string) => { if (confirm("Reset this student's lab to its initial state? Their answered questions are kept.")) { await api(`/api/admin/attempts/${id}/reset-lab`, { body: {} }); reload(); } };
  return (
    <div className="space-y-3">
      <input className="input max-w-sm" placeholder="Search student" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
      {err && <p className="text-red-300">{err}</p>}
      <Table cols={["Student", "Exam", "Status", "Tasks done", "Score", "Started", ""]} rows={(data?.items || []).map((r: any) => [r.student, r.scenario, r.status, r.completed_questions, r.score, r.started_at.slice(0, 16).replace("T", " "),
        r.status === "active" ? <button className="btn-ghost" onClick={() => reset(r.attempt_id)}>Reset lab</button> : ""])} />
      {data && <Pager page={page} total={data.total} size={25} set={setPage} />}
    </div>
  );
}

function Scenarios({ isAdmin }: { isAdmin: boolean }) {
  const { data, err, reload } = useList<any[]>("/api/admin/scenarios");
  const [note, setNote] = useState("");
  const act = async (id: string, what: "publish" | "unpublish") => { try { const r = await api<any>(`/api/admin/scenarios/${id}/${what}`, { body: {} }); setNote(`${what}: ${JSON.stringify(r)}`); reload(); } catch (e: any) { setNote(e.message); } };
  const policy = async (s: any) => {
    const pct = prompt("Percent of preceding tasks required before the final objective (0-100):", String(s.completion_policy?.percent ?? 100));
    if (pct === null) return;
    try { await api(`/api/admin/scenarios/${s.id}`, { method: "PATCH", body: { completion_policy: { ...s.completion_policy, mode: s.completion_policy?.mandatory?.length ? "percent_plus_mandatory" : "percent", percent: Number(pct) } } }); setNote("Policy saved. Republish for new attempts to use it."); reload(); } catch (e: any) { setNote(e.message); }
  };
  return (
    <div className="space-y-3">
      {(err || note) && <p className="text-sm text-amber-200">{err || note}</p>}
      <Table cols={["Scenario", "Track", "Status", "Price", "Completion policy", ""]} rows={(data || []).map((s) => [s.title, s.track, s.status, s.price_paise ? inr(s.price_paise) : "default",
        <code key="p" className="text-xs">{JSON.stringify(s.completion_policy)}</code>,
        <div key="a" className="flex gap-2"><button className="btn-ghost" onClick={() => policy(s)}>Edit policy</button>
          {isAdmin && (s.status === "published" ? <button className="btn-danger" onClick={() => act(s.id, "unpublish")}>Unpublish</button> : <button className="btn-primary" onClick={() => act(s.id, "publish")}>Publish</button>)}
          {isAdmin && s.status === "published" && <button className="btn-ghost" onClick={() => act(s.id, "publish")}>Republish</button>}</div>])} />
      <p className="text-xs text-mute">Question text, hints and validation rules are edited via the API (PUT /api/admin/scenarios/&lt;id&gt;/questions/&lt;key&gt;) or by importing a definition (POST /api/admin/scenarios/import). Edits apply to new attempts after republishing; running attempts stay pinned to their version.</p>
    </div>
  );
}

function Completions({ isAdmin }: { isAdmin: boolean }) {
  const [page, setPage] = useState(1);
  const { data, err, reload } = useList<any>(`/api/admin/completions?page=${page}`);
  const revoke = async (id: string) => { const reason = prompt("Reason for revoking this letter?"); if (reason) { await api(`/api/admin/letters/${id}/revoke`, { body: { reason } }); reload(); } };
  const reissue = async (id: string) => { const reason = prompt("Reason for reissuing?"); if (reason) { await api(`/api/admin/letters/${id}/reissue`, { body: { reason } }); reload(); } };
  return (
    <div className="space-y-3">
      <a className="btn-ghost no-underline" href={`${API}/api/admin/completions?fmt=csv`}>Export CSV</a>
      {err && <p className="text-red-300">{err}</p>}
      <Table cols={["Student", "Exam", "Score", "Completed", "Letter", ""]} rows={(data?.items || []).map((c: any) => [c.student, c.exam, `${c.score}/${c.max_score}`, c.completed_at.slice(0, 16).replace("T", " "), `${c.certificate_number || "—"} (${c.letter_status || "none"})`,
        isAdmin && c.letter_id ? <div key="x" className="flex gap-2"><button className="btn-ghost" onClick={() => reissue(c.letter_id)}>Reissue</button><button className="btn-danger" onClick={() => revoke(c.letter_id)}>Revoke</button></div> : ""])} />
      {data && <Pager page={page} total={data.total} size={25} set={setPage} />}
    </div>
  );
}

function Payments() {
  const [status, setStatus] = useState(""); const [page, setPage] = useState(1); const [note, setNote] = useState("");
  const { data, err, reload } = useList<any>(`/api/admin/payments?page=${page}${status ? `&status=${status}` : ""}`);
  const rec = async () => { const r = await api<any>("/api/admin/payments/reconcile", { body: {} }); setNote(`Reconciled ${Object.keys(r).length} order(s): ${JSON.stringify(r)}`); reload(); };
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <select className="input w-auto" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All statuses</option>{["pending", "paid", "failed", "cancelled", "expired", "refunded", "partially_refunded", "review"].map((s) => <option key={s}>{s}</option>)}
        </select>
        <button className="btn-ghost" onClick={rec}>Reconcile pending with provider</button>
        <a className="btn-ghost no-underline" href={`${API}/api/admin/payments?fmt=csv`}>Export CSV</a>
      </div>
      {(err || note) && <p className="text-sm text-amber-200">{err || note}</p>}
      <Table cols={["Student", "Exam", "Status", "Amount", "Receipt", "Note"]} rows={(data?.items || []).map((o: any) => [o.student, o.exam, o.status, inr(o.amount_paise), o.receipt || "—", o.reason || ""])} />
      {data && <Pager page={page} total={data.total} size={25} set={setPage} />}
    </div>
  );
}

function Audit() {
  const [page, setPage] = useState(1); const [chain, setChain] = useState("");
  const { data, err } = useList<any>(`/api/admin/audit?page=${page}`);
  return (
    <div className="space-y-3">
      <button className="btn-ghost" onClick={async () => { const r = await api<any>("/api/admin/audit/verify"); setChain(r.ok ? `Chain intact (${r.checked} entries)` : `TAMPERING DETECTED at entry ${r.broken_at}`); }}>Verify audit chain</button>
      {chain && <span className={`ml-3 text-sm ${chain.startsWith("TAMPER") ? "text-red-300" : "text-teal"}`}>{chain}</span>}
      {err && <p className="text-red-300">{err}</p>}
      <Table cols={["When", "Action", "Actor", "Entity", "Detail"]} rows={(data?.items || []).map((r: any) => [r.at.slice(0, 19).replace("T", " "), r.action, r.role || "system", r.entity, <code key="d" className="text-xs">{JSON.stringify(r.detail).slice(0, 120)}</code>])} />
      {data && <Pager page={page} total={data.total} size={50} set={setPage} />}
    </div>
  );
}

function SettingsTab() {
  const { data, err, reload } = useList<Record<string, any>>("/api/admin/settings");
  const [draft, setDraft] = useState<Record<string, any>>({}); const [note, setNote] = useState("");
  useEffect(() => { if (data) setDraft(data); }, [data]);
  const save = async () => {
    const changed = Object.fromEntries(Object.entries(draft).filter(([k, v]) => data && data[k] !== v));
    try { await api("/api/admin/settings", { method: "PUT", body: changed }); setNote("Saved."); reload(); } catch (e: any) { setNote(e.message); }
  };
  if (!data) return <p className="text-mute">{err || "Loading…"}</p>;
  return (
    <div className="card space-y-3">
      <p className="text-xs text-mute">Exam fee is stored in paise (₹300 = 30000). Payment provider keys are environment secrets and cannot be edited here.</p>
      <div className="grid gap-3 md:grid-cols-2">
        {Object.entries(draft).map(([k, v]) => (
          <div key={k}>
            <label className="label" htmlFor={k}>{k}{k === "exam_fee_paise" ? ` (${inr(Number(v) || 0)})` : ""}</label>
            {typeof v === "boolean" ? <input id={k} type="checkbox" checked={v} onChange={(e) => setDraft({ ...draft, [k]: e.target.checked })} />
              : <input id={k} className="input" value={v as any} onChange={(e) => setDraft({ ...draft, [k]: typeof data[k] === "number" ? Number(e.target.value) : e.target.value })} />}
          </div>
        ))}
      </div>
      <div className="flex items-center gap-3"><button className="btn-primary" onClick={save}>Save settings</button>{note && <span className="text-sm text-amber-200">{note}</span>}</div>
    </div>
  );
}
