"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, API, inr } from "@/lib/api";
import { useMe } from "@/lib/useMe";

type Row = {
  scenario: { id: string; slug: string; title: string; description: string; price_paise: number; question_count: number };
  state: "locked" | "payment_pending" | "paid" | "in_progress" | "completed" | "letter_issued";
  order_id?: string | null; order_status?: string | null; checkout_url?: string; attempt_id?: string;
  score?: number; max_score?: number; letter_id?: string; verification_id?: string;
};

const STATE_LABEL: Record<Row["state"], string> = {
  locked: "Locked", payment_pending: "Payment pending", paid: "Paid · ready to start",
  in_progress: "In progress", completed: "Completed", letter_issued: "Letter issued",
};

export default function Dashboard() {
  const { me, loading } = useMe();
  const router = useRouter();
  const [rows, setRows] = useState<Row[] | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState("");
  const load = () => api<Row[]>("/api/me/exams").then(setRows).catch((e) => setErr(e.message));
  useEffect(() => { if (!loading && !me) router.push("/login"); else if (me) { if (me.role !== "student") router.push("/admin"); else load(); } }, [me, loading]);

  async function pay(r: Row) {
    setBusy(r.scenario.id); setErr("");
    try {
      const o = await api<{ checkout_url: string }>(`/api/exams/${r.scenario.id}/orders`, { method: "POST", body: {} });
      window.location.assign(o.checkout_url);
    } catch (e: any) { setErr(e.message); setBusy(""); }
  }
  async function start(r: Row) {
    setBusy(r.scenario.id); setErr("");
    try {
      const a = await api<{ attempt_id: string }>(`/api/exams/${r.scenario.id}/start`, { method: "POST", body: {} });
      router.push(`/exam/${a.attempt_id}`);
    } catch (e: any) { setErr(e.message); setBusy(""); }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">My exams</h1>
        <p className="text-sm text-mute">Payment is verified by our server (not by the page you return to). Access unlocks as soon as your payment is confirmed.</p>
      </div>
      {err && <p role="alert" className="text-red-300">{err}</p>}
      {!rows && !err && <p className="text-mute">Loading…</p>}
      {rows?.map((r) => (
        <div key={r.scenario.id} className="card flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold">{r.scenario.title}</h2>
              <span className={`chip ${r.state === "locked" ? "" : "border-teal/50 text-teal"}`}>{STATE_LABEL[r.state]}</span>
            </div>
            <p className="mt-1 max-w-2xl text-sm text-mute">{r.scenario.description}</p>
            {r.score !== undefined && <p className="mt-1 text-sm">Score: <b>{r.score}/{r.max_score}</b></p>}
            {r.order_status === "failed" && r.state === "locked" && <p className="mt-1 text-sm text-amber-300">Your last payment attempt did not go through. You have not been charged for an exam you can't access — try again.</p>}
            {r.order_status === "review" && <p className="mt-1 text-sm text-amber-300">Your payment is under review by an administrator.</p>}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {(r.state === "locked" || r.state === "payment_pending") && (
              <button className="btn-primary" disabled={busy === r.scenario.id} onClick={() => pay(r)}>
                {busy === r.scenario.id ? "Opening checkout…" : `Pay ${inr(r.scenario.price_paise)} & unlock`}
              </button>
            )}
            {r.state === "paid" && <button className="btn-primary" disabled={busy === r.scenario.id} onClick={() => start(r)}>Start exam</button>}
            {r.state === "in_progress" && <Link className="btn-primary no-underline" href={`/exam/${r.attempt_id}`}>Resume</Link>}
            {r.state === "letter_issued" && (
              <>
                <a className="btn-primary no-underline" href={`${API}/api/letters/${r.letter_id}/pdf`}>Download letter (PDF)</a>
                <Link className="btn-ghost no-underline" href={`/verify/${r.verification_id}`}>Verification page</Link>
              </>
            )}
            {r.order_id && ["paid"].includes(r.order_status || "") && (
              <a className="btn-ghost no-underline" href={`${API}/api/orders/${r.order_id}/receipt.pdf`}>Receipt</a>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
