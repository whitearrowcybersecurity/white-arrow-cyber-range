"use client";
import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api, API, ApiError } from "@/lib/api";
import { useMe } from "@/lib/useMe";
import Terminal from "@/components/Terminal";

type QS = { key: string; position: number; stage: string; title: string; score: number; is_final: boolean; status: "locked" | "available" | "completed" };
type Overview = { attempt_id: string; status: string; scenario: string; story: string; expires_at: string; score: number; max_score: number; completed: number; total: number;
  final_gate: { eligible: boolean; required: number; completed: number; total_preceding: number; mandatory_missing: number }; questions: QS[] };
type QD = { key: string; stage: string; title: string; narrative: string; task: string; concept_notes: string; score: number; is_final: boolean; status: string;
  hints: string[]; hints_total: number; hints_used: number; input: "answer" | "check" | "flag"; explanation?: string };

export default function Exam() {
  const { attemptId } = useParams<{ attemptId: string }>();
  const router = useRouter();
  const { me, loading } = useMe();
  const [ov, setOv] = useState<Overview | null>(null);
  const [cur, setCur] = useState<string>("q01");
  const [q, setQ] = useState<QD | null>(null);
  const [answer, setAnswer] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [err, setErr] = useState("");
  const [ai, setAi] = useState({ ask: "", reply: "" });
  const [done, setDone] = useState<{ letter_id?: string } | null>(null);
  const [showStory, setShowStory] = useState(true);

  const fatal = (e: any) => {
    if (e instanceof ApiError && [401, 402, 403, 404, 409].includes(e.status)) {
      setErr(e.status === 402 ? "Your access to this exam is no longer active (payment required)." : e.status === 401 ? "Please log in again." : e.detail);
    } else setErr(e.message);
  };
  const loadOv = useCallback(() => api<Overview>(`/api/attempts/${attemptId}`).then(setOv).catch(fatal), [attemptId]);
  const loadQ = useCallback((k: string) => api<QD>(`/api/attempts/${attemptId}/questions/${k}`).then((d) => { setQ(d); setMsg(null); setAnswer(""); setAi({ ask: "", reply: "" }); }).catch((e) => { setQ(null); fatal(e); }), [attemptId]);

  useEffect(() => { if (!loading && !me) router.push("/login"); }, [me, loading]);
  useEffect(() => { loadOv(); }, [loadOv]);
  useEffect(() => { if (ov) loadQ(cur); }, [cur, ov?.attempt_id]);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); if (!q) return; setErr("");
    try {
      if (q.is_final) {
        const r = await api<any>(`/api/attempts/${attemptId}/final`, { body: { flag: answer } });
        if (r.correct) { setDone({ letter_id: r.letter_id }); setMsg({ ok: true, text: "Flag accepted — exam complete!" }); loadOv(); }
        else setMsg({ ok: false, text: r.feedback || "Incorrect flag." });
      } else {
        const r = await api<any>(`/api/attempts/${attemptId}/questions/${q.key}/answer`, { body: { answer } });
        setMsg({ ok: r.correct, text: r.correct ? `Correct! +${r.score_awarded} pts. ${r.explanation || ""}` : r.feedback });
        if (r.overview) setOv(r.overview);
        if (r.correct) loadQ(q.key).then(() => setMsg({ ok: true, text: `Correct! +${r.score_awarded} pts. ${r.explanation || ""}` }));
      }
    } catch (e: any) {
      if (e.data?.gate) setMsg({ ok: false, text: `Not yet: ${e.data.gate.completed}/${e.data.gate.required} required tasks done${e.data.gate.mandatory_missing ? ` and ${e.data.gate.mandatory_missing} mandatory task(s) outstanding` : ""}.` });
      else fatal(e);
    }
  }
  async function hint() {
    if (!q) return;
    try { await api(`/api/attempts/${attemptId}/questions/${q.key}/hint`, { body: {} }); loadQ(q.key); } catch (e: any) { fatal(e); }
  }
  async function askAi(e: React.FormEvent) {
    e.preventDefault(); if (!q || !ai.ask.trim()) return;
    try { const r = await api<any>(`/api/attempts/${attemptId}/questions/${q.key}/ai`, { body: { message: ai.ask } }); setAi({ ask: "", reply: r.reply }); }
    catch (e: any) { setAi((a) => ({ ...a, reply: e.message })); }
  }

  if (err && !ov) return <div className="card mx-auto max-w-lg text-center"><p role="alert" className="text-red-300">{err}</p><Link className="btn-primary mt-4 no-underline" href="/dashboard">Back to my exams</Link></div>;
  if (!ov) return <p className="text-mute">Loading exam…</p>;
  const finished = ov.status !== "active";
  const stages = Array.from(new Set(ov.questions.map((x) => x.stage)));
  const pct = Math.round((100 * ov.completed) / ov.total);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">{ov.scenario}</h1>
          <p className="text-xs text-mute">Score {ov.score}/{ov.max_score} · {ov.completed}/{ov.total} tasks · attempt ends {new Date(ov.expires_at).toLocaleString()}</p>
        </div>
        <div className="h-2 w-48 overflow-hidden rounded-full bg-line"><div className="h-full bg-teal" style={{ width: `${pct}%` }} /></div>
      </div>
      {err && <p role="alert" className="text-red-300">{err}</p>}
      {finished && ov.status === "completed" && (
        <div className="card border-teal/50">
          <p className="font-semibold text-teal">Exam complete 🎉</p>
          <Link className="btn-primary mt-2 no-underline" href="/dashboard">Go to my letter</Link>
        </div>
      )}
      {finished && ov.status !== "completed" && <p className="text-amber-300">This attempt is {ov.status}. The terminal is closed.</p>}
      {showStory && ov.story && (
        <div className="card text-sm text-slate-300">
          <div className="flex justify-between"><b>Mission briefing</b><button className="text-mute" onClick={() => setShowStory(false)}>hide</button></div>
          <p className="mt-1">{ov.story}</p>
        </div>
      )}
      <div className="grid gap-4 lg:grid-cols-[16rem_minmax(0,1fr)_minmax(0,1.2fr)]">
        <aside className="card max-h-[75vh] space-y-3 overflow-y-auto p-3" aria-label="Tasks">
          {stages.map((s) => (
            <div key={s}>
              <p className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-mute">{s}</p>
              {ov.questions.filter((x) => x.stage === s).map((x) => (
                <button key={x.key} onClick={() => setCur(x.key)} disabled={x.status === "locked" && !x.is_final}
                  className={`mb-1 flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm ${cur === x.key ? "bg-panel2 ring-1 ring-teal/60" : "hover:bg-panel2"} disabled:opacity-40`}>
                  <span aria-hidden>{x.status === "completed" ? "✅" : x.status === "locked" ? "🔒" : "▫️"}</span>
                  <span className="truncate">{x.position}. {x.title}</span>
                </button>
              ))}
            </div>
          ))}
          <p className="border-t border-line pt-2 text-xs text-mute">Final objective: {ov.final_gate.completed}/{ov.final_gate.required} required tasks{ov.final_gate.mandatory_missing ? `, ${ov.final_gate.mandatory_missing} mandatory left` : ""}{ov.final_gate.eligible ? " — unlocked" : ""}</p>
        </aside>

        <section className="card space-y-3">
          {!q ? <p className="text-mute">This task is locked. Finish its prerequisites first.</p> : (
            <>
              <div className="flex items-center justify-between"><span className="chip">{q.stage}</span><span className="chip">{q.score} pts</span></div>
              <h2 className="text-lg font-semibold">{q.title}</h2>
              <p className="text-sm text-slate-300">{q.narrative}</p>
              <div className="rounded-lg border border-line bg-ink p-3 text-sm"><b className="text-teal">Task:</b> {q.task}</div>
              {q.concept_notes && <p className="text-xs text-mute">💡 {q.concept_notes}</p>}
              {q.status !== "completed" && !finished && (
                <form onSubmit={submit} className="space-y-2">
                  {q.input !== "check" && <input className="input font-mono" placeholder={q.input === "flag" ? "WA{…}" : "Your answer"} value={answer} onChange={(e) => setAnswer(e.target.value)} maxLength={200} />}
                  <button className="btn-primary w-full">{q.input === "check" ? "Check my work" : q.input === "flag" ? "Submit flag" : "Submit answer"}</button>
                </form>
              )}
              {msg && <p role="status" className={`rounded-lg p-2 text-sm ${msg.ok ? "bg-teal/10 text-teal" : "bg-red-500/10 text-red-300"}`}>{msg.text}</p>}
              {q.status === "completed" && q.explanation && <p className="rounded-lg bg-teal/10 p-2 text-sm text-teal">✔ Completed. {q.explanation}</p>}
              <div className="space-y-2 border-t border-line pt-3">
                {q.hints.map((h, i) => <p key={i} className="text-sm text-amber-200">Hint {i + 1}: {h}</p>)}
                {q.hints_used < q.hints_total && q.status !== "completed" && <button className="btn-ghost" onClick={hint}>Reveal hint ({q.hints_used}/{q.hints_total})</button>}
              </div>
              {!finished && (
                <form onSubmit={askAi} className="space-y-2 border-t border-line pt-3">
                  <label className="label" htmlFor="ai">Ask the AI tutor (explains concepts — won't give answers)</label>
                  <div className="flex gap-2"><input id="ai" className="input" value={ai.ask} onChange={(e) => setAi({ ...ai, ask: e.target.value })} placeholder="e.g. what does -rw-r----- mean?" maxLength={1500} /><button className="btn-ghost">Ask</button></div>
                  {ai.reply && <p className="whitespace-pre-wrap rounded-lg bg-panel2 p-3 text-sm">{ai.reply}<span className="mt-2 block text-xs text-mute">AI suggestions are advice only — they don't validate your answer.</span></p>}
                </form>
              )}
            </>
          )}
        </section>

        <section className="min-h-[420px]" aria-label="Terminal">
          {!finished ? <Terminal attemptId={attemptId} onCommand={() => {}} /> : <div className="card text-mute">Terminal closed.</div>}
        </section>
      </div>
    </div>
  );
}
