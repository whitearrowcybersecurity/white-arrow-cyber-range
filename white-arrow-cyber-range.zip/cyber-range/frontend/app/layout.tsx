import "./globals.css";
import type { Metadata } from "next";
import Nav from "@/components/Nav";

export const metadata: Metadata = {
  title: "White Arrow Cyber Range",
  description: "Hands-on cybersecurity internship assessments by White Arrow Cybersecurity.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Nav />
        <main className="mx-auto max-w-7xl px-4 py-8">{children}</main>
        <footer className="mx-auto max-w-7xl px-4 pb-10 pt-4 text-xs text-mute">
          © White Arrow Cybersecurity. All lab environments are fictional and isolated; nothing here touches a real system.
        </footer>
      </body>
    </html>
  );
}
