"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { api, inr } from "@/lib/api";

type Scn = { id: string; slug: string; title: string; description: string; objectives: string[]; difficulty: string; duration_minutes: number; eligibility: string; question_count: number; price_paise: number };
type Track = { slug: string; title: string; summary: string; objectives: string[]; difficulty: string; scenarios: Scn[] };

export default function Home() {
  const [tracks, setTracks] = useState<Track[] | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => { api<Track[]>("/api/tracks").then(setTracks).catch((e) => setErr(e.message)); }, []);
  return (
    <div className="space-y-10">
      <section className="rounded-2xl border border-line bg-gradient-to-br from-panel to-ink p-8">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-teal">Cybersecurity internship assessments</p>
        <h1 className="mt-2 max-w-2xl text-4xl font-bold leading-tight">Prove your skills in a live Linux lab, then get a verifiable completion letter.</h1>
        <p className="mt-3 max-w-2xl text-mute">Work through connected missions in a sandboxed terminal, get AI-assisted hints without spoilers, and finish with a proof-of-completion flag.</p>
      </section>
      {err && <p className="text-red-300">Could not load programs: {err}</p>}
      {!tracks && !err && <p className="text-mute">Loading programs…</p>}
      {tracks?.map((t) => (
        <section key={t.slug} className="space-y-4">
          <div>
            <h2 className="text-xl font-semibold">{t.title}</h2>
            <p className="text-sm text-mute">{t.summary}</p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {t.scenarios.map((s) => (
              <article key={s.id} className="card flex flex-col gap-3">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-lg font-semibold">{s.title}</h3>
                  <span className="rounded-lg bg-teal/15 px-3 py-1 text-sm font-bold text-teal">{inr(s.price_paise)}</span>
                </div>
                <p className="text-sm text-slate-300">{s.description}</p>
                <ul className="list-disc space-y-1 pl-5 text-sm text-mute">{s.objectives.map((o) => <li key={o}>{o}</li>)}</ul>
                <div className="flex flex-wrap gap-2 text-xs">
                  <span className="chip">{s.difficulty}</span><span className="chip">{s.question_count} tasks</span>
                  <span className="chip">~{Math.round(s.duration_minutes / 60)} h</span>
                </div>
                <p className="text-xs text-mute">{s.eligibility}</p>
                <Link href="/dashboard" className="btn-primary mt-auto no-underline">Unlock exam · {inr(s.price_paise)}</Link>
              </article>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
