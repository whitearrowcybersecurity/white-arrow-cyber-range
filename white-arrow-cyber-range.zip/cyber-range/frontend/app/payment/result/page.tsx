"use client";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/api";

function Inner() {
  const q = useSearchParams();
  const orderId = q.get("order") || "";
  const [status, setStatus] = useState("checking");
  const [tries, setTries] = useState(0);
  // The URL parameter 'r' is only a hint. The ONLY source of truth is the server's order status.
  useEffect(() => {
    if (!orderId) { setStatus("unknown"); return; }
    let stop = false;
    const tick = async (n: number) => {
      try {
        const o = await api<{ status: string }>(`/api/orders/${orderId}`);
        if (stop) return;
        setStatus(o.status);
        if (["pending", "created"].includes(o.status) && n < 20) setTimeout(() => { setTries(n + 1); tick(n + 1); }, 2000);
      } catch { if (!stop) setStatus("login"); }
    };
    tick(0);
    return () => { stop = true; };
  }, [orderId]);

  const msg: Record<string, [string, string]> = {
    checking: ["Confirming your payment…", "Hang tight — we're waiting for confirmation from the payment provider."],
    pending: [tries >= 20 ? "Still waiting for confirmation" : "Confirming your payment…", tries >= 20 ? "If money was debited, access will unlock automatically once the provider confirms. You can safely close this page." : "Hang tight — this normally takes a few seconds."],
    created: ["Payment not completed", "No payment was received for this order."],
    paid: ["Payment verified", "Your exam is unlocked."],
    failed: ["Payment failed", "Your payment did not go through. You can try again from your dashboard."],
    cancelled: ["Payment cancelled", "You can try again from your dashboard."],
    expired: ["Checkout expired", "You can start a new checkout from your dashboard."],
    review: ["Payment under review", "The amount received didn't match the order. An administrator will review it."],
    refunded: ["Payment refunded", "This payment was refunded, so access is not active."],
    login: ["Please log in", "Log in to see your payment status."],
    unknown: ["Nothing to show", "We couldn't find that order."],
  };
  const [title, body] = msg[status] || msg.unknown;
  return (
    <div className="card mx-auto mt-10 max-w-lg text-center">
      <h1 className={`text-xl font-semibold ${status === "paid" ? "text-teal" : ""}`}>{title}</h1>
      <p className="mt-2 text-sm text-mute">{body}</p>
      <Link href={status === "login" ? "/login" : "/dashboard"} className="btn-primary mt-5 no-underline">{status === "login" ? "Log in" : "Go to my exams"}</Link>
    </div>
  );
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
