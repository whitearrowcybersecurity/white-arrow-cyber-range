"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { api } from "@/lib/api";

type V = { valid: boolean; status?: string; holder?: string; organization?: string; track?: string; scenario?: string; completed_on?: string; issued_on?: string };

export default function Verify() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [v, setV] = useState<V | null>(null);
  const [input, setInput] = useState("");
  const lookup = id === "lookup";
  useEffect(() => { if (!lookup) api<V>(`/api/verify/${encodeURIComponent(id)}`).then(setV).catch(() => setV({ valid: false })); }, [id]);
  if (lookup) {
    return (
      <form className="card mx-auto mt-8 max-w-md space-y-3" onSubmit={(e) => { e.preventDefault(); router.push(`/verify/${encodeURIComponent(input.trim())}`); }}>
        <h1 className="text-xl font-semibold">Verify a letter</h1>
        <label className="label" htmlFor="vid">Verification ID</label>
        <input id="vid" className="input font-mono" placeholder="WA-XXXX-XXXX-XXXX" value={input} onChange={(e) => setInput(e.target.value)} required />
        <button className="btn-primary w-full">Verify</button>
      </form>
    );
  }
  if (!v) return <p className="text-mute">Checking…</p>;
  return (
    <div className="card mx-auto mt-8 max-w-lg space-y-3">
      <p className={`text-sm font-bold uppercase tracking-widest ${v.valid ? "text-teal" : "text-red-300"}`}>{v.valid ? "Valid letter" : v.status === "revoked" ? "Revoked" : v.status === "superseded" ? "Superseded by a newer letter" : "Not found"}</p>
      <p className="font-mono text-sm text-mute">{id}</p>
      {v.holder && (
        <dl className="grid grid-cols-[8rem_1fr] gap-y-2 text-sm">
          <dt className="text-mute">Holder</dt><dd>{v.holder}</dd>
          <dt className="text-mute">Issued by</dt><dd>{v.organization}</dd>
          <dt className="text-mute">Track</dt><dd>{v.track}</dd>
          <dt className="text-mute">Assessment</dt><dd>{v.scenario}</dd>
          <dt className="text-mute">Completed</dt><dd>{v.completed_on}</dd>
          <dt className="text-mute">Issued</dt><dd>{v.issued_on}</dd>
        </dl>
      )}
      {!v.holder && <p className="text-sm text-mute">No letter matches this ID. Check for typos.</p>}
    </div>
  );
}
