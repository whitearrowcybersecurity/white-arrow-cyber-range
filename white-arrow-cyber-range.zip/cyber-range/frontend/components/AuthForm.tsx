"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api, Me } from "@/lib/api";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      const me = await api<Me>(`/api/auth/${mode}`, { body: mode === "login" ? { email, password } : { email, password, display_name: name } });
      window.location.assign(me.role === "student" ? "/dashboard" : "/admin");
    } catch (e: any) { setErr(e.message); setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="card mx-auto mt-8 max-w-md space-y-4">
      <h1 className="text-xl font-semibold">{mode === "login" ? "Log in" : "Create your student account"}</h1>
      {mode === "register" && (
        <div>
          <label className="label" htmlFor="name">Full name (as it should appear on your letter)</label>
          <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} maxLength={120} autoComplete="name" />
        </div>
      )}
      <div>
        <label className="label" htmlFor="email">Email</label>
        <input id="email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
      </div>
      <div>
        <label className="label" htmlFor="pw">Password {mode === "register" && "(10+ characters)"}</label>
        <input id="pw" type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={mode === "register" ? 10 : 1} autoComplete={mode === "login" ? "current-password" : "new-password"} />
      </div>
      {err && <p role="alert" className="text-sm text-red-300">{err}</p>}
      <button className="btn-primary w-full" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Log in" : "Register"}</button>
      <p className="text-sm text-mute">
        {mode === "login" ? <>New here? <Link href="/register">Create an account</Link></> : <>Already registered? <Link href="/login">Log in</Link></>}
      </p>
    </form>
  );
}
