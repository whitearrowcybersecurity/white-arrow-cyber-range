"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { useMe } from "@/lib/useMe";

export default function Nav() {
  const { me } = useMe();
  const router = useRouter();
  async function logout() {
    await api("/api/auth/logout", { method: "POST", body: {} }).catch(() => {});
    router.push("/");
    router.refresh();
    setTimeout(() => window.location.assign("/"), 50);
  }
  return (
    <header className="border-b border-line bg-panel/80 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2 font-semibold text-white no-underline">
          <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden><path d="M3 12 12 3v5h9v8h-9v5z" fill="#14b8a6" /></svg>
          White Arrow <span className="text-teal">Cyber Range</span>
        </Link>
        <nav className="flex items-center gap-4 text-sm">
          <Link href="/" className="text-slate-300">Programs</Link>
          <Link href="/verify/lookup" className="text-slate-300">Verify letter</Link>
          {me ? (
            <>
              {me.role === "student" ? <Link href="/dashboard">My exams</Link> : <Link href="/admin">Admin</Link>}
              <span className="chip">{me.display_name}</span>
              <button className="btn-ghost" onClick={logout}>Log out</button>
            </>
          ) : (
            <>
              <Link href="/login">Log in</Link>
              <Link href="/register" className="btn-primary no-underline">Register</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
