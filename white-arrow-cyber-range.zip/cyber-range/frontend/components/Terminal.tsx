"use client";
import { useEffect, useRef } from "react";
import { API } from "@/lib/api";

/** xterm.js terminal that talks to the backend simulated shell over an authenticated WebSocket.
 *  Line editing is done locally; every submitted line is executed (and authorised) server-side. */
export default function Terminal({ attemptId, onCommand, disabled }: { attemptId: string; onCommand?: () => void; disabled?: boolean }) {
  const host = useRef<HTMLDivElement>(null);
  const cb = useRef(onCommand);
  cb.current = onCommand;

  useEffect(() => {
    if (!host.current) return;
    let disposed = false;
    let ws: WebSocket | null = null;
    let term: any;
    let fit: any;
    (async () => {
      const { Terminal: XTerm } = await import("@xterm/xterm");
      const { FitAddon } = await import("@xterm/addon-fit");
      if (disposed || !host.current) return;
      term = new XTerm({ fontFamily: "ui-monospace, Menlo, Consolas, monospace", fontSize: 13, cursorBlink: true, convertEol: true, screenReaderMode: true,
        theme: { background: "#070d18", foreground: "#d6e2f0", cursor: "#14b8a6", selectionBackground: "#1f2f4a" } });
      fit = new FitAddon();
      term.loadAddon(fit);
      term.open(host.current);
      fit.fit();
      let prompt = "$ ", buf = "", cursor = 0, busy = true;
      const hist: string[] = []; let hi = 0;
      const redraw = () => { term.write("\r\x1b[2K" + prompt + buf); if (cursor < buf.length) term.write(`\x1b[${buf.length - cursor}D`); };
      const url = API.replace(/^http/, "ws") + `/ws/attempts/${attemptId}/terminal`;
      ws = new WebSocket(url);
      ws.onopen = () => term.writeln("\x1b[2mConnecting to the lab…\x1b[0m");
      ws.onmessage = (ev) => {
        const m = JSON.parse(ev.data);
        if (m.type === "ready") { prompt = m.prompt; busy = false; term.writeln("\x1b[32mLab ready.\x1b[0m Type \x1b[1mhelp\x1b[0m for commands.\r\n"); redraw(); }
        else if (m.type === "result") {
          if (m.output.includes("\x1b[2J")) term.clear(); else if (m.output) term.writeln(m.output);
          prompt = m.prompt; busy = false; redraw(); cb.current?.();
        } else if (m.type === "error") {
          term.writeln(`\r\n\x1b[31m${m.message || m.code}\x1b[0m`);
          busy = m.code === "rate_limited" ? false : true;
          if (!busy) redraw();
        }
      };
      ws.onclose = (ev) => { busy = true; term.writeln(`\r\n\x1b[33mDisconnected${ev.reason ? " (" + ev.reason + ")" : ""}. Reload the page to reconnect.\x1b[0m`); };
      term.onData((d: string) => {
        if (busy || disabled) return;
        if (d === "\r") {
          term.write("\r\n");
          const line = buf.trim();
          if (line) { hist.push(line); hi = hist.length; }
          buf = ""; cursor = 0;
          if (!line) { redraw(); return; }
          busy = true; ws?.send(JSON.stringify({ cmd: line }));
        } else if (d === "\x7f") { if (cursor > 0) { buf = buf.slice(0, cursor - 1) + buf.slice(cursor); cursor--; redraw(); } }
        else if (d === "\x1b[A") { if (hi > 0) { hi--; buf = hist[hi]; cursor = buf.length; redraw(); } }
        else if (d === "\x1b[B") { if (hi < hist.length) { hi++; buf = hist[hi] ?? ""; cursor = buf.length; redraw(); } }
        else if (d === "\x1b[D") { if (cursor > 0) { cursor--; term.write("\x1b[D"); } }
        else if (d === "\x1b[C") { if (cursor < buf.length) { cursor++; term.write("\x1b[C"); } }
        else if (d === "\x03") { buf = ""; cursor = 0; term.write("^C\r\n"); redraw(); }
        else if (d >= " " && !d.startsWith("\x1b")) { buf = buf.slice(0, cursor) + d + buf.slice(cursor); cursor += d.length; redraw(); }
      });
    })();
    const onResize = () => { try { fit?.fit(); } catch {} };
    window.addEventListener("resize", onResize);
    return () => { disposed = true; window.removeEventListener("resize", onResize); ws?.close(); term?.dispose(); };
  }, [attemptId, disabled]);

  return <div ref={host} className="h-full min-h-[320px] w-full overflow-hidden rounded-lg border border-line bg-[#070d18] p-2" aria-label="Lab terminal" />;
}
