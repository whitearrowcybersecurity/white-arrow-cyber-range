import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0b1220", panel: "#111b2e", panel2: "#16233b", line: "#1f2f4a",
        mute: "#8fa3bd", teal: { DEFAULT: "#14b8a6", dim: "#0f8f81" },
      },
      fontFamily: { mono: ["ui-monospace", "SFMono-Regular", "Menlo", "Consolas", "monospace"] },
    },
  },
  plugins: [],
};
export default config;
